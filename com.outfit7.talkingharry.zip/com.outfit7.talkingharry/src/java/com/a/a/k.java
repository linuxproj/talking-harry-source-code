package com.a.a;

import android.os.Bundle;
import android.graphics.Bitmap;
import android.util.Log;
import android.webkit.WebView;
import android.webkit.WebViewClient;

final class k extends WebViewClient
{
    private i a;
    
    private k(final i a, final byte b) {
        this.a = a;
    }
    
    public final void onPageFinished(final WebView webView, final String s) {
        super.onPageFinished(webView, s);
        final String title = this.a.h.getTitle();
        if (title != null && title.length() > 0) {
            this.a.j.setText((CharSequence)title);
        }
        try {
            this.a.g.dismiss();
        }
        catch (final RuntimeException ex) {
            Log.w(i.a, ex.getLocalizedMessage(), (Throwable)ex);
        }
    }
    
    public final void onPageStarted(final WebView webView, final String s, final Bitmap bitmap) {
        Log.d("Facebook-WebView", "Webview loading URL: " + s);
        super.onPageStarted(webView, s, bitmap);
        try {
            this.a.g.show();
        }
        catch (final RuntimeException ex) {
            Log.w(i.a, ex.getLocalizedMessage(), (Throwable)ex);
        }
    }
    
    public final void onReceivedError(final WebView webView, final int n, final String s, final String s2) {
        super.onReceivedError(webView, n, s, s2);
        this.a.f.a(new d(s));
        try {
            this.a.dismiss();
        }
        catch (final RuntimeException ex) {
            Log.w(i.a, ex.getLocalizedMessage(), (Throwable)ex);
        }
    }
    
    public final boolean shouldOverrideUrlLoading(final WebView webView, final String s) {
        Log.d("Facebook-WebView", "Redirect URL: " + s);
        boolean b;
        if (s.startsWith("fbconnect://success")) {
            final Bundle a = com.a.a.a.a(s);
            final String string = a.getString("error_reason");
            if (string == null) {
                this.a.f.a(a);
            }
            else {
                this.a.f.a(new h(string, (byte)0));
            }
            this.a.dismiss();
            b = true;
        }
        else {
            if (s.startsWith("fbconnect:cancel")) {
                this.a.f.a();
                try {
                    this.a.dismiss();
                    b = true;
                    return b;
                }
                catch (final RuntimeException ex) {
                    Log.w(i.a, ex.getLocalizedMessage(), (Throwable)ex);
                    return true;
                }
            }
            if (s.contains((CharSequence)"touch")) {
                b = false;
            }
            else {
                Log.d("Facebook-WebView", "Ignoring non-dialog URL: " + s);
                b = true;
            }
        }
        return b;
    }
}
