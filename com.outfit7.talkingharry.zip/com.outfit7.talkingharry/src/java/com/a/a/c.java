package com.a.a;

import java.net.MalformedURLException;
import java.io.IOException;
import java.io.FileNotFoundException;

public interface c
{
    void a(final FileNotFoundException p0);
    
    void a(final IOException p0);
    
    void a(final String p0);
    
    void a(final MalformedURLException p0);
}
