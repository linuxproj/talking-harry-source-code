package com.a.a;

import android.view.Display;
import android.view.ViewGroup$LayoutParams;
import android.webkit.WebViewClient;
import android.view.View;
import android.graphics.drawable.Drawable;
import android.graphics.Typeface;
import android.os.Bundle;
import android.content.DialogInterface$OnCancelListener;
import android.content.Context;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.webkit.WebView;
import android.app.ProgressDialog;
import android.widget.FrameLayout$LayoutParams;
import android.app.Dialog;

public class i extends Dialog
{
    private static final String a;
    private static float[] b;
    private static float[] c;
    private static FrameLayout$LayoutParams d;
    private String e;
    private g f;
    private ProgressDialog g;
    private WebView h;
    private LinearLayout i;
    private TextView j;
    
    static {
        a = i.class.getName();
        i.b = new float[] { 460.0f, 260.0f };
        i.c = new float[] { 280.0f, 420.0f };
        i.d = new FrameLayout$LayoutParams(-1, -1);
    }
    
    public i(final Context context, final String e, final g f) {
        super(context);
        this.e = e;
        this.f = f;
        this.setCancelable(true);
        this.setOnCancelListener((DialogInterface$OnCancelListener)new j(f));
    }
    
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        (this.g = new ProgressDialog(this.getContext())).requestWindowFeature(1);
        this.g.setMessage((CharSequence)"Loading...");
        (this.i = new LinearLayout(this.getContext())).setOrientation(1);
        this.requestWindowFeature(1);
        final Drawable drawable = this.getContext().getResources().getDrawable(2130837525);
        (this.j = new TextView(this.getContext())).setText((CharSequence)"Facebook");
        this.j.setTextColor(-1);
        this.j.setTypeface(Typeface.DEFAULT_BOLD);
        this.j.setBackgroundColor(-9599820);
        this.j.setPadding(6, 4, 4, 4);
        this.j.setCompoundDrawablePadding(6);
        this.j.setCompoundDrawablesWithIntrinsicBounds(drawable, (Drawable)null, (Drawable)null, (Drawable)null);
        this.i.addView((View)this.j);
        (this.h = new WebView(this.getContext())).setVerticalScrollBarEnabled(false);
        this.h.setHorizontalScrollBarEnabled(false);
        this.h.setWebViewClient((WebViewClient)new k(this));
        this.h.getSettings().setJavaScriptEnabled(true);
        this.h.loadUrl(this.e);
        this.h.setLayoutParams((ViewGroup$LayoutParams)com.a.a.i.d);
        this.i.addView((View)this.h);
        final Display defaultDisplay = this.getWindow().getWindowManager().getDefaultDisplay();
        final float density = this.getContext().getResources().getDisplayMetrics().density;
        float[] array;
        if (defaultDisplay.getWidth() < defaultDisplay.getHeight()) {
            array = com.a.a.i.c;
        }
        else {
            array = com.a.a.i.b;
        }
        this.addContentView((View)this.i, (ViewGroup$LayoutParams)new FrameLayout$LayoutParams((int)(array[0] * density + 0.5f), (int)(array[1] * density + 0.5f)));
    }
}
