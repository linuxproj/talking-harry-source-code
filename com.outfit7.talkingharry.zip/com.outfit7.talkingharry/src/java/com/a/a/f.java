package com.a.a;

import android.webkit.CookieSyncManager;
import android.os.Bundle;
import android.util.Log;

final class f implements g
{
    private g a;
    private e b;
    
    f(final e b, final g a) {
        this.b = b;
        this.a = a;
    }
    
    @Override
    public final void a() {
        Log.d("Facebook-authorize", "Login cancelled");
        this.a.a();
    }
    
    @Override
    public final void a(final Bundle bundle) {
        CookieSyncManager.getInstance().sync();
        this.b.a(bundle.getString("access_token"));
        this.b.b(bundle.getString("expires_in"));
        if (this.b.a()) {
            Log.d("Facebook-authorize", "Login Success! access_token=" + this.b.b() + " expires=" + this.b.c());
            this.a.a(bundle);
        }
        else {
            this.a(new h("failed to receive access_token", (byte)0));
        }
    }
    
    @Override
    public final void a(final d d) {
        Log.d("Facebook-authorize", "Login failed: " + (Object)d);
        this.a.a(d);
    }
    
    @Override
    public final void a(final h h) {
        Log.d("Facebook-authorize", "Login failed: " + (Object)h);
        this.a.a(h);
    }
}
