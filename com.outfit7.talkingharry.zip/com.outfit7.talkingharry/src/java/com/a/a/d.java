package com.a.a;

public final class d extends Throwable
{
    public d(final String s) {
        super(s);
    }
}
