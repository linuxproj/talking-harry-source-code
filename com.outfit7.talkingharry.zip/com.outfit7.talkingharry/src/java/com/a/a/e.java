package com.a.a;

import android.text.TextUtils;
import android.util.Log;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.content.Context;

public class e
{
    private static final String a;
    private static String b;
    private static String c;
    private static String d;
    private static String e;
    private String f;
    private long g;
    
    static {
        a = e.class.getName();
        com.a.a.e.b = "https://graph.facebook.com/oauth/authorize";
        com.a.a.e.c = "https://www.facebook.com/connect/uiserver.php";
        com.a.a.e.d = "https://graph.facebook.com/";
        com.a.a.e.e = "https://api.facebook.com/restserver.php";
    }
    
    public e() {
        this.f = null;
        this.g = 0L;
    }
    
    public final String a(final Context context) {
        CookieSyncManager.createInstance(context);
        CookieManager.getInstance().removeAllCookie();
        final Bundle bundle = new Bundle();
        bundle.putString("method", "auth.expireSession");
        if (!bundle.containsKey("method")) {
            throw new IllegalArgumentException("API method must be specified. (parameters must contain key \"method\" and value). See http://developers.facebook.com/docs/reference/rest/");
        }
        final String a = this.a(null, bundle, "GET");
        this.f = null;
        this.g = 0L;
        return a;
    }
    
    public final String a(String s, final Bundle bundle, final String s2) {
        bundle.putString("format", "json");
        if (this.a()) {
            bundle.putString("access_token", this.f);
        }
        if (s != null) {
            s = com.a.a.e.d + s;
        }
        else {
            s = com.a.a.e.e;
        }
        return com.a.a.a.a(s, s2, bundle);
    }
    
    public final void a(final long g) {
        this.g = g;
    }
    
    public final void a(final Context context, String s, final Bundle bundle, final g g) {
        if (s.equals((Object)"login")) {
            s = com.a.a.e.b;
            bundle.putString("type", "user_agent");
            bundle.putString("redirect_uri", "fbconnect://success");
        }
        else {
            final String c = com.a.a.e.c;
            bundle.putString("method", s);
            bundle.putString("next", "fbconnect://success");
            s = c;
        }
        bundle.putString("display", "touch");
        if (this.a()) {
            bundle.putString("access_token", this.f);
        }
        s = s + "?" + com.a.a.a.a(bundle);
        if (context.checkCallingOrSelfPermission("android.permission.INTERNET") != 0) {
            com.a.a.a.a(context, "Error", "Application requires permission to access the Internet");
        }
        else {
            try {
                new i(context, s, g).show();
            }
            catch (final RuntimeException ex) {
                Log.w(com.a.a.e.a, ex.getLocalizedMessage(), (Throwable)ex);
            }
        }
    }
    
    public final void a(final Context context, final String s, final String[] array, final g g) {
        final Bundle bundle = new Bundle();
        bundle.putString("client_id", s);
        if (array.length > 0) {
            bundle.putString("scope", TextUtils.join((CharSequence)",", (Object[])array));
        }
        CookieSyncManager.createInstance(context);
        this.a(context, "login", bundle, new f(this, g));
    }
    
    public final void a(final String f) {
        this.f = f;
    }
    
    public final boolean a() {
        return this.f != null && (this.g == 0L || System.currentTimeMillis() < this.g);
    }
    
    public final String b() {
        return this.f;
    }
    
    public final void b(final Context context, String s, final Bundle bundle, final g g) {
        bundle.putString("next", "fbconnect://success");
        bundle.putString("display", "touch");
        if (this.a()) {
            bundle.putString("access_token", this.f);
        }
        final StringBuilder sb = new StringBuilder();
        sb.append(s);
        if (s.indexOf("?") == -1) {
            s = "?";
        }
        else {
            s = "&";
        }
        sb.append(s);
        sb.append(com.a.a.a.a(bundle));
        if (context.checkCallingOrSelfPermission("android.permission.INTERNET") != 0) {
            com.a.a.a.a(context, "Error", "Application requires permission to access the Internet");
        }
        else {
            new i(context, sb.toString(), g).show();
        }
    }
    
    public final void b(final String s) {
        if (s != null && !s.equals((Object)"0")) {
            this.g = System.currentTimeMillis() + Integer.parseInt(s) * 1000;
        }
    }
    
    public final long c() {
        return this.g;
    }
}
