package com.a.a;

import android.content.DialogInterface;
import android.content.DialogInterface$OnCancelListener;

final class j implements DialogInterface$OnCancelListener
{
    private g a;
    
    j(final g a) {
        this.a = a;
    }
    
    public final void onCancel(final DialogInterface dialogInterface) {
        this.a.a();
    }
}
