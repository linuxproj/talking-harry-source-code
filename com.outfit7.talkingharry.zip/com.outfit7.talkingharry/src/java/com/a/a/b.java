package com.a.a;

import java.io.IOException;
import java.net.MalformedURLException;
import java.io.FileNotFoundException;
import android.os.Bundle;

final class b extends Thread
{
    private String a;
    private Bundle b;
    private String c;
    private c d;
    private a e;
    
    b(final a e, final String s, final Bundle b, final String c, final c d) {
        this.e = e;
        this.a = null;
        this.b = b;
        this.c = c;
        this.d = d;
    }
    
    public final void run() {
        try {
            this.d.a(this.e.a.a(this.a, this.b, this.c));
        }
        catch (final FileNotFoundException ex) {
            this.d.a(ex);
        }
        catch (final MalformedURLException ex2) {
            this.d.a(ex2);
        }
        catch (final IOException ex3) {
            this.d.a(ex3);
        }
    }
}
