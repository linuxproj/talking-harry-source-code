package com.a.a;

public final class h extends Throwable
{
    public h(final String s) {
        super(s);
    }
    
    public h(final String s, final byte b) {
        super(s);
    }
}
