package com.a.a;

import android.os.Bundle;

public interface g
{
    void a();
    
    void a(final Bundle p0);
    
    void a(final d p0);
    
    void a(final h p0);
}
