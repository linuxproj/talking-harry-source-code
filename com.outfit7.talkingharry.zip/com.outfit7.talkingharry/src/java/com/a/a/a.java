package com.a.a;

import org.json.JSONObject;
import android.app.AlertDialog$Builder;
import android.content.Context;
import java.io.FileNotFoundException;
import java.net.HttpURLConnection;
import android.util.Log;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.InputStream;
import java.util.Iterator;
import java.net.MalformedURLException;
import java.net.URL;
import android.os.Bundle;

public final class a
{
    e a;
    
    public a() {
    }
    
    public a(final e a) {
        this.a = a;
    }
    
    public static Bundle a(String replace) {
        replace = replace.replace((CharSequence)"fbconnect", (CharSequence)"http");
        try {
            final URL url = new URL(replace);
            final Bundle c = c(url.getQuery());
            c.putAll(c(url.getRef()));
            return c;
        }
        catch (final MalformedURLException ex) {
            return new Bundle();
        }
    }
    
    public static String a(final Bundle bundle) {
        String string;
        if (bundle == null) {
            string = "";
        }
        else {
            final StringBuilder sb = new StringBuilder();
            final Iterator iterator = bundle.keySet().iterator();
            int n = 1;
            while (iterator.hasNext()) {
                final String s = (String)iterator.next();
                if (n != 0) {
                    n = 0;
                }
                else {
                    sb.append("&");
                }
                sb.append(s + "=" + bundle.getString(s));
            }
            string = sb.toString();
        }
        return string;
    }
    
    private static String a(final InputStream inputStream) {
        final StringBuilder sb = new StringBuilder();
        final BufferedReader bufferedReader = new BufferedReader((Reader)new InputStreamReader(inputStream), 1000);
        for (String s = bufferedReader.readLine(); s != null; s = bufferedReader.readLine()) {
            sb.append(s);
        }
        inputStream.close();
        return sb.toString();
    }
    
    public static String a(String s, final String s2, final Bundle bundle) {
        if (s2.equals((Object)"GET")) {
            s = s + "?" + a(bundle);
        }
        while (true) {
            Log.d("Facebook-Util", s2 + " URL: " + s);
            final HttpURLConnection httpURLConnection = (HttpURLConnection)new URL(s).openConnection();
            httpURLConnection.setRequestProperty("User-Agent", System.getProperties().getProperty("http.agent") + " FacebookAndroidSDK");
            if (!s2.equals((Object)"GET")) {
                bundle.putString("method", s2);
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.getOutputStream().write(a(bundle).getBytes("UTF-8"));
            }
            try {
                s = a(httpURLConnection.getInputStream());
                return s;
            }
            catch (final FileNotFoundException ex) {
                s = a(httpURLConnection.getErrorStream());
                return s;
            }
            continue;
        }
    }
    
    public static void a(final Context context, final String title, final String message) {
        final AlertDialog$Builder alertDialog$Builder = new AlertDialog$Builder(context);
        alertDialog$Builder.setTitle((CharSequence)title);
        alertDialog$Builder.setMessage((CharSequence)message);
        alertDialog$Builder.create().show();
    }
    
    public static JSONObject b(String s) {
        if (s.equals((Object)"false")) {
            throw new h("request failed", (byte)0);
        }
        if (s.equals((Object)"true")) {
            s = "{value : true}";
        }
        final JSONObject jsonObject = new JSONObject(s);
        if (jsonObject.has("error")) {
            final JSONObject jsonObject2 = jsonObject.getJSONObject("error");
            final String string = jsonObject2.getString("message");
            jsonObject2.getString("type");
            throw new h(string);
        }
        if (jsonObject.has("error_code") && jsonObject.has("error_msg")) {
            final String string2 = jsonObject.getString("error_msg");
            jsonObject.getString("error_code");
            throw new h(string2);
        }
        if (jsonObject.has("error_code")) {
            jsonObject.getString("error_code");
            throw new h("request failed");
        }
        if (jsonObject.has("error_msg")) {
            throw new h(jsonObject.getString("error_msg"), (byte)0);
        }
        if (jsonObject.has("error_reason")) {
            throw new h(jsonObject.getString("error_reason"), (byte)0);
        }
        return jsonObject;
    }
    
    private static Bundle c(final String s) {
        final Bundle bundle = new Bundle();
        if (s != null) {
            final String[] split = s.split("&");
            for (int length = split.length, i = 0; i < length; ++i) {
                final String[] split2 = split[i].split("=");
                bundle.putString(split2[0], split2[1]);
            }
        }
        return bundle;
    }
    
    public final void a(final Bundle bundle, final c c) {
        new b(this, null, bundle, "GET", c).start();
    }
}
