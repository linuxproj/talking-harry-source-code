package com.outfit7.b;

import java.io.IOException;

public final class b extends IOException
{
    private int a;
    
    public b(final String s, final int a) {
        super(s);
        this.a = a;
    }
    
    public final int a() {
        return this.a;
    }
}
