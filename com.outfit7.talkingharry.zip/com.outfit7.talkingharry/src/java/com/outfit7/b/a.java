package com.outfit7.b;

import org.apache.http.client.HttpClient;
import org.apache.http.StatusLine;
import org.apache.http.HttpResponse;
import java.io.IOException;
import org.apache.http.entity.mime.content.FileBody;
import java.io.File;
import org.apache.http.entity.mime.content.ContentBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.commons.lang.StringEscapeUtils;
import com.outfit7.a.d;
import java.nio.charset.Charset;
import org.apache.http.entity.mime.HttpMultipartMode;
import android.util.Log;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.HttpEntity;
import org.apache.http.entity.StringEntity;
import java.net.URLEncoder;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.InputStream;
import com.outfit7.a.b;

public class a
{
    private static final String a;
    private volatile boolean b;
    private b c;
    
    static {
        a = a.class.getName();
    }
    
    private static String a(final InputStream inputStream) {
        final StringBuilder sb = new StringBuilder();
        final BufferedReader bufferedReader = new BufferedReader((Reader)new InputStreamReader(inputStream), 1000);
        for (String s = bufferedReader.readLine(); s != null; s = bufferedReader.readLine()) {
            sb.append(s);
        }
        inputStream.close();
        return sb.toString();
    }
    
    public final String a(String string, String s, final String s2, final String s3, final String s4, final String s5, final String s6, final String s7, final com.outfit7.a.a a) {
        final DefaultHttpClient defaultHttpClient = new DefaultHttpClient();
        final HttpPost httpPost = new HttpPost("https://www.google.com/youtube/accounts/ClientLogin");
        httpPost.addHeader("Content-Type", "application/x-www-form-urlencoded");
        final StringBuilder sb = new StringBuilder();
        sb.append("Email=").append(URLEncoder.encode(string, "UTF-8")).append("&").append("Passwd=").append(URLEncoder.encode(s, "UTF-8")).append("&").append("service=youtube").append("&").append("source=").append(URLEncoder.encode(s2, "UTF-8"));
        httpPost.setEntity((HttpEntity)new StringEntity(sb.toString()));
        final HttpResponse execute = ((HttpClient)defaultHttpClient).execute((HttpUriRequest)httpPost);
        final StatusLine statusLine = execute.getStatusLine();
        final int statusCode = statusLine.getStatusCode();
        if (statusLine.getStatusCode() < 200 || statusLine.getStatusCode() >= 300) {
            s = a(execute.getEntity().getContent());
            Log.d(a.a, "YT login: statusCode: " + statusCode);
            Log.d(a.a, "YT login: reasonPhrase: " + statusLine.getReasonPhrase());
            Log.d(a.a, "YT login: content: " + s);
            string = "Error, reason = " + statusLine.getReasonPhrase();
            if (s.contains((CharSequence)"Captcha")) {
                throw new com.outfit7.b.b(string, 1);
            }
            if (s.contains((CharSequence)"BadAuthentication")) {
                throw new com.outfit7.b.b(string, 2);
            }
            throw new com.outfit7.b.b(string, 3);
        }
        else {
            final InputStream content = execute.getEntity().getContent();
            final StringBuilder sb2 = new StringBuilder();
            while (true) {
                final int read = content.read();
                if (read == -1) {
                    break;
                }
                sb2.append((char)read);
            }
            s = sb2.toString().split("\n")[0].split("=")[1];
            final HttpPost httpPost2 = new HttpPost("http://uploads.gdata.youtube.com/feeds/api/users/default/uploads");
            httpPost2.addHeader("Authorization", "GoogleLogin auth=" + s);
            httpPost2.addHeader("GData-Version", "2");
            httpPost2.addHeader("X-GData-Key", "key=AI39si7ehD7ustsItYL52TD_jJ54m5V32xBLZH2cweZF8DMuwpiYjNpWJSpLSsUCfTCfkCUuhokFxvFLBq3muyND7OX-urWa2w");
            httpPost2.addHeader("Slug", "video");
            s = "ABoundary" + System.currentTimeMillis();
            httpPost2.addHeader("Content-Type", "multipart/related; boundary=" + s);
            this.c = new b(HttpMultipartMode.STRICT, s, Charset.forName("UTF-8"), a);
            if (this.b) {
                throw new d();
            }
            final StringBuilder sb3 = new StringBuilder();
            sb3.append("<?xml version=\"1.0\"?>").append(" ").append("<entry xmlns=\"http://www.w3.org/2005/Atom\"").append(" ").append("xmlns:media=\"http://search.yahoo.com/mrss/\"").append(" ").append("xmlns:yt=\"http://gdata.youtube.com/schemas/2007\">").append(" ").append("<media:group>").append(" ").append("<media:title type=\"plain\">").append(StringEscapeUtils.escapeXml(s3)).append("</media:title>").append(" ").append("<media:description type=\"plain\">").append(" ").append(StringEscapeUtils.escapeXml(s4)).append(" ").append("</media:description>").append(" ").append("<media:category scheme=\"http://gdata.youtube.com/schemas/2007/categories.cat\">").append(" ").append("People").append(" ").append("</media:category>").append(" ").append("<media:keywords>").append(StringEscapeUtils.escapeXml(s5)).append("</media:keywords>").append(" ").append("</media:group>").append(" ").append("</entry>");
            this.c.addPart("001", (ContentBody)new StringBody(sb3.toString(), "application/atom+xml", Charset.forName("UTF-8")));
            this.c.addPart("002", (ContentBody)new FileBody(new File(s6), s7));
            httpPost2.setEntity((HttpEntity)this.c);
            final HttpResponse execute2 = ((HttpClient)defaultHttpClient).execute((HttpUriRequest)httpPost2);
            final StatusLine statusLine2 = execute2.getStatusLine();
            if (statusLine2.getStatusCode() < 200 || statusLine2.getStatusCode() >= 300) {
                throw new IOException("Error, reason = " + statusLine2.getReasonPhrase());
            }
            return a(execute2.getEntity().getContent());
        }
    }
    
    public final void a() {
        this.b = true;
        if (this.c != null) {
            this.c.a();
        }
    }
}
