package com.outfit7.soundtouch;

public class FIFOSamplePipe
{
    protected boolean swigCMemOwn;
    private long swigCPtr;
    
    public FIFOSamplePipe(final long swigCPtr, final boolean swigCMemOwn) {
        this.swigCMemOwn = swigCMemOwn;
        this.swigCPtr = swigCPtr;
    }
    
    public static long getCPtr(final FIFOSamplePipe fifoSamplePipe) {
        long swigCPtr;
        if (fifoSamplePipe == null) {
            swigCPtr = 0L;
        }
        else {
            swigCPtr = fifoSamplePipe.swigCPtr;
        }
        return swigCPtr;
    }
    
    public void clear() {
        JSoundTouchJNI.FIFOSamplePipe_clear(this.swigCPtr, this);
    }
    
    public void delete() {
        synchronized (this) {
            if (this.swigCPtr != 0L) {
                if (this.swigCMemOwn) {
                    this.swigCMemOwn = false;
                    JSoundTouchJNI.delete_FIFOSamplePipe(this.swigCPtr);
                }
                this.swigCPtr = 0L;
            }
        }
    }
    
    @Override
    protected void finalize() {
        this.delete();
    }
    
    public int isEmpty() {
        return JSoundTouchJNI.FIFOSamplePipe_isEmpty(this.swigCPtr, this);
    }
    
    public void moveSamples(final FIFOSamplePipe fifoSamplePipe) {
        JSoundTouchJNI.FIFOSamplePipe_moveSamples(this.swigCPtr, this, getCPtr(fifoSamplePipe), fifoSamplePipe);
    }
    
    public long numSamples() {
        return JSoundTouchJNI.FIFOSamplePipe_numSamples(this.swigCPtr, this);
    }
    
    public void putSamples(final SWIGTYPE_p_short swigtype_p_short, final long n) {
        JSoundTouchJNI.FIFOSamplePipe_putSamples(this.swigCPtr, this, SWIGTYPE_p_short.getCPtr(swigtype_p_short), n);
    }
    
    public long receiveSamples(final long n) {
        return JSoundTouchJNI.FIFOSamplePipe_receiveSamples__SWIG_1(this.swigCPtr, this, n);
    }
    
    public long receiveSamples(final SWIGTYPE_p_short swigtype_p_short, final long n) {
        return JSoundTouchJNI.FIFOSamplePipe_receiveSamples__SWIG_0(this.swigCPtr, this, SWIGTYPE_p_short.getCPtr(swigtype_p_short), n);
    }
}
