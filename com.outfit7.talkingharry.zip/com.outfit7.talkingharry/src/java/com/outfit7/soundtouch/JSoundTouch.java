package com.outfit7.soundtouch;

public class JSoundTouch implements JSoundTouchConstants
{
    public static void init() {
        JSoundTouchJNI.init();
    }
}
