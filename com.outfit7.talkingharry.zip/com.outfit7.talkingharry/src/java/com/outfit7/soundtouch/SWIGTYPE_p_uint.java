package com.outfit7.soundtouch;

public class SWIGTYPE_p_uint
{
    private long swigCPtr;
    
    protected SWIGTYPE_p_uint() {
        this.swigCPtr = 0L;
    }
    
    protected SWIGTYPE_p_uint(final long swigCPtr, final boolean b) {
        this.swigCPtr = swigCPtr;
    }
    
    protected static long getCPtr(final SWIGTYPE_p_uint swigtype_p_uint) {
        long swigCPtr;
        if (swigtype_p_uint == null) {
            swigCPtr = 0L;
        }
        else {
            swigCPtr = swigtype_p_uint.swigCPtr;
        }
        return swigCPtr;
    }
}
