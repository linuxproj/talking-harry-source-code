package com.outfit7.soundtouch;

public interface JSoundTouchConstants
{
    public static final int ALLOW_NONEXACT_SIMD_OPTIMIZATION = JSoundTouchJNI.ALLOW_NONEXACT_SIMD_OPTIMIZATION_get();
    public static final int FALSE = JSoundTouchJNI.FALSE_get();
    public static final int INTEGER_SAMPLES = JSoundTouchJNI.INTEGER_SAMPLES_get();
    public static final int SETTING_AA_FILTER_LENGTH = JSoundTouchJNI.SETTING_AA_FILTER_LENGTH_get();
    public static final int SETTING_OVERLAP_MS = JSoundTouchJNI.SETTING_OVERLAP_MS_get();
    public static final int SETTING_SEEKWINDOW_MS = JSoundTouchJNI.SETTING_SEEKWINDOW_MS_get();
    public static final int SETTING_SEQUENCE_MS = JSoundTouchJNI.SETTING_SEQUENCE_MS_get();
    public static final int SETTING_USE_AA_FILTER = JSoundTouchJNI.SETTING_USE_AA_FILTER_get();
    public static final int SETTING_USE_QUICKSEEK = JSoundTouchJNI.SETTING_USE_QUICKSEEK_get();
    public static final String SOUNDTOUCH_VERSION = JSoundTouchJNI.SOUNDTOUCH_VERSION_get();
    public static final int SOUNDTOUCH_VERSION_ID = JSoundTouchJNI.SOUNDTOUCH_VERSION_ID_get();
    public static final int TRUE = JSoundTouchJNI.TRUE_get();
}
