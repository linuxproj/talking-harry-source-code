package com.outfit7.soundtouch;

public class ShortArray
{
    protected boolean swigCMemOwn;
    private long swigCPtr;
    
    public ShortArray(final int n) {
        this(JSoundTouchJNI.new_ShortArray(n), true);
    }
    
    public ShortArray(final long swigCPtr, final boolean swigCMemOwn) {
        this.swigCMemOwn = swigCMemOwn;
        this.swigCPtr = swigCPtr;
    }
    
    public static ShortArray frompointer(final SWIGTYPE_p_short swigtype_p_short) {
        final long shortArray_frompointer = JSoundTouchJNI.ShortArray_frompointer(SWIGTYPE_p_short.getCPtr(swigtype_p_short));
        ShortArray shortArray;
        if (shortArray_frompointer == 0L) {
            shortArray = null;
        }
        else {
            shortArray = new ShortArray(shortArray_frompointer, false);
        }
        return shortArray;
    }
    
    public static long getCPtr(final ShortArray shortArray) {
        long swigCPtr;
        if (shortArray == null) {
            swigCPtr = 0L;
        }
        else {
            swigCPtr = shortArray.swigCPtr;
        }
        return swigCPtr;
    }
    
    public SWIGTYPE_p_short cast() {
        final long shortArray_cast = JSoundTouchJNI.ShortArray_cast(this.swigCPtr, this);
        SWIGTYPE_p_short swigtype_p_short;
        if (shortArray_cast == 0L) {
            swigtype_p_short = null;
        }
        else {
            swigtype_p_short = new SWIGTYPE_p_short(shortArray_cast, false);
        }
        return swigtype_p_short;
    }
    
    public void delete() {
        synchronized (this) {
            if (this.swigCPtr != 0L) {
                if (this.swigCMemOwn) {
                    this.swigCMemOwn = false;
                    JSoundTouchJNI.delete_ShortArray(this.swigCPtr);
                }
                this.swigCPtr = 0L;
            }
        }
    }
    
    @Override
    protected void finalize() {
        this.delete();
    }
    
    public short getitem(final int n) {
        return JSoundTouchJNI.ShortArray_getitem(this.swigCPtr, this, n);
    }
    
    public void setitem(final int n, final short n2) {
        JSoundTouchJNI.ShortArray_setitem(this.swigCPtr, this, n, n2);
    }
}
