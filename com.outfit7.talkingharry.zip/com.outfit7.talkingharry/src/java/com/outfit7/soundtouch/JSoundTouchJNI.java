package com.outfit7.soundtouch;

public class JSoundTouchJNI
{
    static {
        try {
            System.loadLibrary("soundtouch");
        }
        catch (final UnsatisfiedLinkError unsatisfiedLinkError) {}
    }
    
    public static final native int ALLOW_NONEXACT_SIMD_OPTIMIZATION_get();
    
    public static final native int FALSE_get();
    
    public static final native long FIFOProcessor_SWIGUpcast(final long p0);
    
    public static final native int FIFOProcessor_isEmpty(final long p0, final FIFOProcessor p1);
    
    public static final native long FIFOProcessor_numSamples(final long p0, final FIFOProcessor p1);
    
    public static final native long FIFOProcessor_receiveSamples__SWIG_0(final long p0, final FIFOProcessor p1, final long p2, final long p3);
    
    public static final native long FIFOProcessor_receiveSamples__SWIG_1(final long p0, final FIFOProcessor p1, final long p2);
    
    public static final native void FIFOSamplePipe_clear(final long p0, final FIFOSamplePipe p1);
    
    public static final native int FIFOSamplePipe_isEmpty(final long p0, final FIFOSamplePipe p1);
    
    public static final native void FIFOSamplePipe_moveSamples(final long p0, final FIFOSamplePipe p1, final long p2, final FIFOSamplePipe p3);
    
    public static final native long FIFOSamplePipe_numSamples(final long p0, final FIFOSamplePipe p1);
    
    public static final native void FIFOSamplePipe_putSamples(final long p0, final FIFOSamplePipe p1, final long p2, final long p3);
    
    public static final native long FIFOSamplePipe_receiveSamples__SWIG_0(final long p0, final FIFOSamplePipe p1, final long p2, final long p3);
    
    public static final native long FIFOSamplePipe_receiveSamples__SWIG_1(final long p0, final FIFOSamplePipe p1, final long p2);
    
    public static final native int INTEGER_SAMPLES_get();
    
    public static final native int SETTING_AA_FILTER_LENGTH_get();
    
    public static final native int SETTING_OVERLAP_MS_get();
    
    public static final native int SETTING_SEEKWINDOW_MS_get();
    
    public static final native int SETTING_SEQUENCE_MS_get();
    
    public static final native int SETTING_USE_AA_FILTER_get();
    
    public static final native int SETTING_USE_QUICKSEEK_get();
    
    public static final native int SOUNDTOUCH_VERSION_ID_get();
    
    public static final native String SOUNDTOUCH_VERSION_get();
    
    public static final native long ShortArray_cast(final long p0, final ShortArray p1);
    
    public static final native long ShortArray_frompointer(final long p0);
    
    public static final native short ShortArray_getitem(final long p0, final ShortArray p1, final int p2);
    
    public static final native void ShortArray_setitem(final long p0, final ShortArray p1, final int p2, final short p3);
    
    public static final native long SoundTouch_SWIGUpcast(final long p0);
    
    public static final native void SoundTouch_clear(final long p0, final SoundTouch p1);
    
    public static final native void SoundTouch_flush(final long p0, final SoundTouch p1);
    
    public static final native int SoundTouch_getSetting(final long p0, final SoundTouch p1, final int p2);
    
    public static final native long SoundTouch_getVersionId();
    
    public static final native String SoundTouch_getVersionString();
    
    public static final native long SoundTouch_numUnprocessedSamples(final long p0, final SoundTouch p1);
    
    public static final native void SoundTouch_putSamples(final long p0, final SoundTouch p1, final long p2, final long p3);
    
    public static final native void SoundTouch_setChannels(final long p0, final SoundTouch p1, final long p2);
    
    public static final native void SoundTouch_setPitch(final long p0, final SoundTouch p1, final float p2);
    
    public static final native void SoundTouch_setPitchOctaves(final long p0, final SoundTouch p1, final float p2);
    
    public static final native void SoundTouch_setPitchSemiTones__SWIG_0(final long p0, final SoundTouch p1, final int p2);
    
    public static final native void SoundTouch_setPitchSemiTones__SWIG_1(final long p0, final SoundTouch p1, final float p2);
    
    public static final native void SoundTouch_setRate(final long p0, final SoundTouch p1, final float p2);
    
    public static final native void SoundTouch_setRateChange(final long p0, final SoundTouch p1, final float p2);
    
    public static final native void SoundTouch_setSampleRate(final long p0, final SoundTouch p1, final long p2);
    
    public static final native int SoundTouch_setSetting(final long p0, final SoundTouch p1, final int p2, final int p3);
    
    public static final native void SoundTouch_setTempo(final long p0, final SoundTouch p1, final float p2);
    
    public static final native void SoundTouch_setTempoChange(final long p0, final SoundTouch p1, final float p2);
    
    public static final native void SoundTouch_setup(final Object p0);
    
    public static final native int TRUE_get();
    
    public static final native void delete_FIFOSamplePipe(final long p0);
    
    public static final native void delete_ShortArray(final long p0);
    
    public static final native void delete_SoundTouch(final long p0);
    
    public static final native void init();
    
    public static final native long new_ShortArray(final int p0);
    
    public static final native long new_SoundTouch();
}
