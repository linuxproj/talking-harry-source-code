package com.outfit7.soundtouch;

public class SWIGTYPE_p_short
{
    private long swigCPtr;
    
    protected SWIGTYPE_p_short() {
        this.swigCPtr = 0L;
    }
    
    protected SWIGTYPE_p_short(final long swigCPtr, final boolean b) {
        this.swigCPtr = swigCPtr;
    }
    
    protected static long getCPtr(final SWIGTYPE_p_short swigtype_p_short) {
        long swigCPtr;
        if (swigtype_p_short == null) {
            swigCPtr = 0L;
        }
        else {
            swigCPtr = swigtype_p_short.swigCPtr;
        }
        return swigCPtr;
    }
}
