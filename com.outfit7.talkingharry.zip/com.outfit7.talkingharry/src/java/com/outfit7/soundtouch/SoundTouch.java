package com.outfit7.soundtouch;

public class SoundTouch extends FIFOProcessor
{
    private long swigCPtr;
    
    public SoundTouch() {
        this(JSoundTouchJNI.new_SoundTouch(), true);
    }
    
    public SoundTouch(final long swigCPtr, final boolean b) {
        super(JSoundTouchJNI.SoundTouch_SWIGUpcast(swigCPtr), b);
        this.swigCPtr = swigCPtr;
    }
    
    public static long getCPtr(final SoundTouch soundTouch) {
        long swigCPtr;
        if (soundTouch == null) {
            swigCPtr = 0L;
        }
        else {
            swigCPtr = soundTouch.swigCPtr;
        }
        return swigCPtr;
    }
    
    public static long getVersionId() {
        return JSoundTouchJNI.SoundTouch_getVersionId();
    }
    
    public static String getVersionString() {
        return JSoundTouchJNI.SoundTouch_getVersionString();
    }
    
    public static void setup(final Object o) {
        JSoundTouchJNI.SoundTouch_setup(o);
    }
    
    @Override
    public void clear() {
        JSoundTouchJNI.SoundTouch_clear(this.swigCPtr, this);
    }
    
    @Override
    public void delete() {
        synchronized (this) {
            if (this.swigCPtr != 0L) {
                if (this.swigCMemOwn) {
                    this.swigCMemOwn = false;
                    JSoundTouchJNI.delete_SoundTouch(this.swigCPtr);
                }
                this.swigCPtr = 0L;
            }
            super.delete();
        }
    }
    
    @Override
    protected void finalize() {
        this.delete();
    }
    
    public void flush() {
        JSoundTouchJNI.SoundTouch_flush(this.swigCPtr, this);
    }
    
    public int getSetting(final int n) {
        return JSoundTouchJNI.SoundTouch_getSetting(this.swigCPtr, this, n);
    }
    
    public long numUnprocessedSamples() {
        return JSoundTouchJNI.SoundTouch_numUnprocessedSamples(this.swigCPtr, this);
    }
    
    @Override
    public void putSamples(final SWIGTYPE_p_short swigtype_p_short, final long n) {
        JSoundTouchJNI.SoundTouch_putSamples(this.swigCPtr, this, SWIGTYPE_p_short.getCPtr(swigtype_p_short), n);
    }
    
    public void setChannels(final long n) {
        JSoundTouchJNI.SoundTouch_setChannels(this.swigCPtr, this, n);
    }
    
    public void setPitch(final float n) {
        JSoundTouchJNI.SoundTouch_setPitch(this.swigCPtr, this, n);
    }
    
    public void setPitchOctaves(final float n) {
        JSoundTouchJNI.SoundTouch_setPitchOctaves(this.swigCPtr, this, n);
    }
    
    public void setPitchSemiTones(final float n) {
        JSoundTouchJNI.SoundTouch_setPitchSemiTones__SWIG_1(this.swigCPtr, this, n);
    }
    
    public void setPitchSemiTones(final int n) {
        JSoundTouchJNI.SoundTouch_setPitchSemiTones__SWIG_0(this.swigCPtr, this, n);
    }
    
    public void setRate(final float n) {
        JSoundTouchJNI.SoundTouch_setRate(this.swigCPtr, this, n);
    }
    
    public void setRateChange(final float n) {
        JSoundTouchJNI.SoundTouch_setRateChange(this.swigCPtr, this, n);
    }
    
    public void setSampleRate(final long n) {
        JSoundTouchJNI.SoundTouch_setSampleRate(this.swigCPtr, this, n);
    }
    
    public int setSetting(final int n, final int n2) {
        return JSoundTouchJNI.SoundTouch_setSetting(this.swigCPtr, this, n, n2);
    }
    
    public void setTempo(final float n) {
        JSoundTouchJNI.SoundTouch_setTempo(this.swigCPtr, this, n);
    }
    
    public void setTempoChange(final float n) {
        JSoundTouchJNI.SoundTouch_setTempoChange(this.swigCPtr, this, n);
    }
}
