package com.outfit7.soundtouch;

public class SWIGTYPE_p_SAMPLETYPE
{
    private long swigCPtr;
    
    protected SWIGTYPE_p_SAMPLETYPE() {
        this.swigCPtr = 0L;
    }
    
    protected SWIGTYPE_p_SAMPLETYPE(final long swigCPtr, final boolean b) {
        this.swigCPtr = swigCPtr;
    }
    
    protected static long getCPtr(final SWIGTYPE_p_SAMPLETYPE swigtype_p_SAMPLETYPE) {
        long swigCPtr;
        if (swigtype_p_SAMPLETYPE == null) {
            swigCPtr = 0L;
        }
        else {
            swigCPtr = swigtype_p_SAMPLETYPE.swigCPtr;
        }
        return swigCPtr;
    }
}
