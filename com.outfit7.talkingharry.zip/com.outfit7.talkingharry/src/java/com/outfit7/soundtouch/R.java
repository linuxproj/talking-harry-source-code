package com.outfit7.soundtouch;

public final class R
{
    public static final class attr
    {
    }
    
    public static final class string
    {
        public static final int app_name = 2130837504;
    }
}
