package com.outfit7.soundtouch;

public class FIFOProcessor extends FIFOSamplePipe
{
    private long swigCPtr;
    
    public FIFOProcessor(final long swigCPtr, final boolean b) {
        super(JSoundTouchJNI.FIFOProcessor_SWIGUpcast(swigCPtr), b);
        this.swigCPtr = swigCPtr;
    }
    
    public static long getCPtr(final FIFOProcessor fifoProcessor) {
        long swigCPtr;
        if (fifoProcessor == null) {
            swigCPtr = 0L;
        }
        else {
            swigCPtr = fifoProcessor.swigCPtr;
        }
        return swigCPtr;
    }
    
    @Override
    public void delete() {
        Label_0047: {
            synchronized (this) {
                if (this.swigCPtr == 0L) {
                    break Label_0047;
                }
                if (this.swigCMemOwn) {
                    this.swigCMemOwn = false;
                    throw new UnsupportedOperationException("C++ destructor does not have public access");
                }
            }
            this.swigCPtr = 0L;
        }
        super.delete();
        monitorexit(this);
    }
    
    @Override
    public int isEmpty() {
        return JSoundTouchJNI.FIFOProcessor_isEmpty(this.swigCPtr, this);
    }
    
    @Override
    public long numSamples() {
        return JSoundTouchJNI.FIFOProcessor_numSamples(this.swigCPtr, this);
    }
    
    @Override
    public long receiveSamples(final long n) {
        return JSoundTouchJNI.FIFOProcessor_receiveSamples__SWIG_1(this.swigCPtr, this, n);
    }
    
    @Override
    public long receiveSamples(final SWIGTYPE_p_short swigtype_p_short, final long n) {
        return JSoundTouchJNI.FIFOProcessor_receiveSamples__SWIG_0(this.swigCPtr, this, SWIGTYPE_p_short.getCPtr(swigtype_p_short), n);
    }
}
