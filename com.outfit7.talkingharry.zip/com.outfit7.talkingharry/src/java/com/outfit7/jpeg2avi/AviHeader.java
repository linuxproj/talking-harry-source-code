package com.outfit7.jpeg2avi;

import java.io.IOException;
import java.io.RandomAccessFile;

class AviHeader
{
    int bufferSize;
    int dataLength;
    int dataRate;
    int dataStreams;
    int flags;
    int height;
    int initialFrames;
    int numberOfFrames;
    int playbackDataRate;
    int reserved;
    int startingTime;
    int timeDelay;
    int timeScale;
    int width;
    
    public void write(final RandomAccessFile randomAccessFile) throws IOException {
        randomAccessFile.writeBytes("avih");
        final long filePointer = randomAccessFile.getFilePointer();
        Util.writeInt(randomAccessFile, 0);
        Util.writeInt(randomAccessFile, this.timeDelay);
        Util.writeInt(randomAccessFile, this.dataRate);
        Util.writeInt(randomAccessFile, this.reserved);
        Util.writeInt(randomAccessFile, this.flags);
        Util.writeInt(randomAccessFile, this.numberOfFrames);
        Util.writeInt(randomAccessFile, this.initialFrames);
        Util.writeInt(randomAccessFile, this.dataStreams);
        Util.writeInt(randomAccessFile, this.bufferSize);
        Util.writeInt(randomAccessFile, this.width);
        Util.writeInt(randomAccessFile, this.height);
        Util.writeInt(randomAccessFile, this.timeScale);
        Util.writeInt(randomAccessFile, this.playbackDataRate);
        Util.writeInt(randomAccessFile, this.startingTime);
        Util.writeInt(randomAccessFile, this.dataLength);
        final long filePointer2 = randomAccessFile.getFilePointer();
        randomAccessFile.seek(filePointer);
        Util.writeInt(randomAccessFile, (int)(filePointer2 - filePointer - 4L));
        randomAccessFile.seek(filePointer2);
    }
}
