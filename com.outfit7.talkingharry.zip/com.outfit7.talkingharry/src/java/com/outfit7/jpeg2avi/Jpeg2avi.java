package com.outfit7.jpeg2avi;

import java.io.RandomAccessFile;
import java.io.File;

public class Jpeg2avi
{
    private static final boolean INCLUDE_SOUND = true;
    private static AviAudio audio;
    private static byte[] soundBuffer;
    
    static {
        initAudio();
    }
    
    private static AviAudio createAvdio() {
        final AviAudio aviAudio = new AviAudio();
        aviAudio.channels = 1;
        aviAudio.bits = 8;
        aviAudio.samplesPerSecond = 22050;
        return aviAudio;
    }
    
    private static byte[] generateSound() {
        final byte[] array = new byte[22050];
        for (int i = 0; i < 22050; ++i) {
            final double n = 4.0 * i / 22050.0;
            array[i] = (byte)((int)(Math.sin(i * 100 * 2 * 3.141592653589793 / 22050.0) * 256.0 / 1.0) & 0xFF);
        }
        return array;
    }
    
    private static void initAudio() {
        Jpeg2avi.audio = createAvdio();
        Jpeg2avi.soundBuffer = generateSound();
    }
    
    public static void main(final String[] array) throws Exception {
        final File[] listFiles = new File("d:/Animations/Cat_Happy/").listFiles();
        final Avi avi = new Avi("d:/out-java-audio-2.avi", 320, 480, "MJPG", 10, Jpeg2avi.audio);
        final int length = listFiles.length;
        int i = 0;
        int n = 0;
        while (i < length) {
            final File file = listFiles[i];
            System.out.println(file.getCanonicalPath());
            final RandomAccessFile randomAccessFile = new RandomAccessFile(file, "r");
            final int n2 = (int)randomAccessFile.length();
            final byte[] array2 = new byte[n2];
            randomAccessFile.read(array2);
            randomAccessFile.close();
            avi.addFrame(array2, n2);
            if (++n % 10 == 0) {
                avi.addAudio(Jpeg2avi.soundBuffer, Jpeg2avi.audio.samplesPerSecond);
            }
            ++i;
        }
        avi.close();
    }
}
