package com.outfit7.jpeg2avi;

import java.io.IOException;
import java.io.RandomAccessFile;

class AudioStreamFormat
{
    short bitsPerSample;
    short blockAlign;
    int bytesPerSecond;
    short channels;
    short formatType;
    int sampleRate;
    short size;
    
    public void write(final RandomAccessFile randomAccessFile) throws IOException {
        randomAccessFile.writeBytes("strf");
        final long filePointer = randomAccessFile.getFilePointer();
        Util.writeInt(randomAccessFile, 0);
        Util.writeShort(randomAccessFile, this.formatType);
        Util.writeShort(randomAccessFile, this.channels);
        Util.writeInt(randomAccessFile, this.sampleRate);
        Util.writeInt(randomAccessFile, this.bytesPerSecond);
        Util.writeShort(randomAccessFile, this.blockAlign);
        Util.writeShort(randomAccessFile, this.bitsPerSample);
        Util.writeShort(randomAccessFile, this.size);
        final long filePointer2 = randomAccessFile.getFilePointer();
        randomAccessFile.seek(filePointer);
        Util.writeInt(randomAccessFile, (int)(filePointer2 - filePointer - 4L));
        randomAccessFile.seek(filePointer2);
    }
}
