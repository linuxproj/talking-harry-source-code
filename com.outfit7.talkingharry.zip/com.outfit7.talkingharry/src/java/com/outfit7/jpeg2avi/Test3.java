package com.outfit7.jpeg2avi;

import java.io.BufferedInputStream;
import java.io.RandomAccessFile;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.io.FileOutputStream;
import javax.sound.sampled.AudioFileFormat$Type;
import java.io.File;
import javax.sound.sampled.AudioFormat$Encoding;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.Line$Info;
import javax.sound.sampled.DataLine$Info;
import javax.sound.sampled.SourceDataLine;
import java.io.IOException;
import java.io.PrintStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import java.io.InputStream;

public class Test3
{
    private byte[] soundBuffer;
    private InputStream soundInputStream;
    
    private static AudioInputStream convertSampleRate(final float n, final AudioInputStream audioInputStream) {
        final AudioFormat format = audioInputStream.getFormat();
        return AudioSystem.getAudioInputStream(new AudioFormat(format.getEncoding(), n, format.getSampleSizeInBits(), format.getChannels(), format.getFrameSize(), n, format.isBigEndian()), audioInputStream);
    }
    
    private void dumpAudioInputStream(final AudioInputStream audioInputStream, final PrintStream printStream, final String s) throws IOException {
        final AudioFormat format = audioInputStream.getFormat();
        if (printStream != null) {
            printStream.println("  -----  " + s + "  -----");
            printStream.println("    Available=" + audioInputStream.available());
            printStream.println("    FrameLength=" + audioInputStream.getFrameLength());
            printStream.println("    SourceFormat=" + format.toString());
            printStream.println("    Channels=" + format.getChannels());
            printStream.println("    FrameRate=" + format.getFrameRate());
            printStream.println("    FrameSize=" + format.getFrameSize());
            printStream.println("    SampleRate=" + format.getSampleRate());
            printStream.println("    SampleSizeInBits=" + format.getSampleSizeInBits());
            printStream.println("    Encoding=" + (Object)format.getEncoding());
        }
    }
    
    private SourceDataLine getLine(final AudioFormat audioFormat) throws LineUnavailableException {
        final SourceDataLine sourceDataLine = (SourceDataLine)AudioSystem.getLine((Line$Info)new DataLine$Info((Class)SourceDataLine.class, audioFormat));
        sourceDataLine.open(audioFormat);
        return sourceDataLine;
    }
    
    public static void main(final String[] array) throws Exception {
        new Test3().testX();
        System.out.println("Done!");
    }
    
    private void rawplay(final AudioFormat audioFormat, final AudioInputStream audioInputStream) throws IOException, LineUnavailableException {
        final byte[] array = new byte[4096];
        final SourceDataLine line = this.getLine(audioFormat);
        if (line != null) {
            line.start();
            int read;
            for (int i = 0; i != -1; i = read) {
                read = audioInputStream.read(array, 0, array.length);
                if ((i = read) != -1) {
                    line.write(array, 0, read);
                }
            }
            line.drain();
            line.stop();
            line.close();
            audioInputStream.close();
        }
    }
    
    private void test3() throws Exception {
        AudioSystem.write(AudioSystem.getAudioInputStream(AudioFormat$Encoding.PCM_SIGNED, AudioSystem.getAudioInputStream(new File("d:/pour_milk.wav"))), AudioFileFormat$Type.AU, (OutputStream)new FileOutputStream("d:/pcm.au"));
    }
    
    private void testX() throws Exception {
        final AviAudio aviAudio = new AviAudio(1, 16, 11025);
        final int n = aviAudio.bits / 8 * aviAudio.samplesPerSecond / 2;
        System.out.println("BufferSize: " + n);
        this.soundBuffer = new byte[n];
        (this.soundInputStream = (InputStream)new FileInputStream("d:/sounds/pour_milk.wav")).read(new byte[4096]);
        final File[] listFiles = new File("D:/Animations/Cat_Drink").listFiles();
        final Avi avi = new Avi("d:/out-001.avi", 320, 480, "MJPG", 10, aviAudio);
        for (int length = listFiles.length, i = 0, n2 = 0; i < length; ++i, ++n2) {
            final RandomAccessFile randomAccessFile = new RandomAccessFile(listFiles[i], "r");
            final int n3 = (int)randomAccessFile.length();
            final byte[] array = new byte[n3];
            randomAccessFile.read(array);
            randomAccessFile.close();
            avi.addFrame(array, n3);
            if (n2 / 2 % 10 == 0) {
                int n4;
                if ((n4 = this.soundInputStream.read(this.soundBuffer, 0, this.soundBuffer.length)) != n) {
                    this.soundInputStream.close();
                    (this.soundInputStream = (InputStream)new FileInputStream("d:/sounds/pour_milk.wav")).read(new byte[4096]);
                    n4 = this.soundInputStream.read(this.soundBuffer, 0, this.soundBuffer.length);
                }
                avi.addAudio(this.soundBuffer, n4);
            }
        }
        avi.close();
        this.soundInputStream.close();
    }
    
    public void getWavHeaderSize() throws Exception {
        final AudioInputStream audioInputStream = AudioSystem.getAudioInputStream((InputStream)new BufferedInputStream((InputStream)new FileInputStream("d:/sounds/p_drink_milk.wav")));
        this.dumpAudioInputStream(audioInputStream, System.out, "d:/sounds/p_drink_milk.wav");
        System.out.println(" ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ ");
        for (final File file : new File("d:/sounds/").listFiles()) {
            System.out.println("Header size: " + (file.length() - AudioSystem.getAudioInputStream(file).available()) + "     " + file.getCanonicalPath());
        }
        final byte[] array = new byte[22050];
        int n = 0;
        while (true) {
            final int read = audioInputStream.read(array);
            if (read == -1) {
                break;
            }
            final int n2 = ++n;
            if (read == 22050) {
                continue;
            }
            System.out.println("n: " + read);
            n = n2;
        }
        System.out.println("i: " + n);
        audioInputStream.close();
    }
    
    public void testPlay() {
        try {
            final AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new File("d:/pour_milk.wav"));
            final AudioFormat format = audioInputStream.getFormat();
            final AudioFormat audioFormat = new AudioFormat(AudioFormat$Encoding.PCM_SIGNED, format.getSampleRate(), 16, format.getChannels(), format.getChannels() * 2, format.getSampleRate(), false);
            this.rawplay(audioFormat, AudioSystem.getAudioInputStream(audioFormat, audioInputStream));
            audioInputStream.close();
        }
        catch (final Exception ex) {
            ex.printStackTrace();
        }
    }
}
