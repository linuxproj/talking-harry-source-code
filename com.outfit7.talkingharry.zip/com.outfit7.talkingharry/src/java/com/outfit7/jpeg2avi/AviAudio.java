package com.outfit7.jpeg2avi;

public class AviAudio
{
    int bits;
    int channels;
    int samplesPerSecond;
    
    public AviAudio() {
    }
    
    public AviAudio(final int channels, final int bits, final int samplesPerSecond) {
        this.channels = channels;
        this.bits = bits;
        this.samplesPerSecond = samplesPerSecond;
    }
    
    public int getBits() {
        return this.bits;
    }
    
    public int getChannels() {
        return this.channels;
    }
    
    public int getSamplesPerSecond() {
        return this.samplesPerSecond;
    }
    
    public void setBits(final int bits) {
        this.bits = bits;
    }
    
    public void setChannels(final int channels) {
        this.channels = channels;
    }
    
    public void setSamplesPerSecond(final int samplesPerSecond) {
        this.samplesPerSecond = samplesPerSecond;
    }
}
