package com.outfit7.jpeg2avi;

class AviIndex
{
    int flags;
    int id;
    int length;
    int offset;
}
