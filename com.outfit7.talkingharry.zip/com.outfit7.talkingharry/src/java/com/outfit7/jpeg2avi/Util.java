package com.outfit7.jpeg2avi;

import java.io.IOException;
import java.io.RandomAccessFile;

class Util
{
    public static void writeChars(final RandomAccessFile randomAccessFile, final String s) throws IOException {
        randomAccessFile.writeBytes(s);
    }
    
    public static void writeInt(final RandomAccessFile randomAccessFile, final int n) throws IOException {
        randomAccessFile.write((int)(byte)(n & 0xFF));
        randomAccessFile.write((int)(byte)(n >> 8 & 0xFF));
        randomAccessFile.write((int)(byte)(n >> 16 & 0xFF));
        randomAccessFile.write((int)(byte)(n >> 24 & 0xFF));
    }
    
    public static void writeShort(final RandomAccessFile randomAccessFile, final int n) throws IOException {
        randomAccessFile.write((int)(byte)(n & 0xFF));
        randomAccessFile.write((int)(byte)(n >> 8 & 0xFF));
    }
}
