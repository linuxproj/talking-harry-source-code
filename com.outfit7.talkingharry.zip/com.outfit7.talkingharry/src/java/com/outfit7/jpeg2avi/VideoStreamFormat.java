package com.outfit7.jpeg2avi;

import java.io.IOException;
import java.io.RandomAccessFile;

class VideoStreamFormat
{
    short bitsPerPixel;
    int colorsImportant;
    int colorsUsed;
    int compressionType;
    int headerSize;
    int height;
    int imageSize;
    short numPlanes;
    int[] palette;
    int paletteCount;
    int width;
    int xPelsPerMeter;
    int yPelsPerMeter;
    
    public void write(final RandomAccessFile randomAccessFile) throws IOException {
        randomAccessFile.writeBytes("strf");
        final long filePointer = randomAccessFile.getFilePointer();
        Util.writeInt(randomAccessFile, 0);
        Util.writeInt(randomAccessFile, this.headerSize);
        Util.writeInt(randomAccessFile, this.width);
        Util.writeInt(randomAccessFile, this.height);
        Util.writeShort(randomAccessFile, this.numPlanes);
        Util.writeShort(randomAccessFile, this.bitsPerPixel);
        Util.writeInt(randomAccessFile, this.compressionType);
        Util.writeInt(randomAccessFile, this.imageSize);
        Util.writeInt(randomAccessFile, this.xPelsPerMeter);
        Util.writeInt(randomAccessFile, this.yPelsPerMeter);
        Util.writeInt(randomAccessFile, this.colorsUsed);
        Util.writeInt(randomAccessFile, this.colorsImportant);
        if (this.colorsUsed != 0) {
            for (int i = 0; i < this.colorsUsed; ++i) {
                randomAccessFile.write(this.palette[i] & 0xFF);
                randomAccessFile.write(this.palette[i] >> 8 & 0xFF);
                randomAccessFile.write(this.palette[i] >> 16 & 0xFF);
                randomAccessFile.write(0);
            }
        }
        final long filePointer2 = randomAccessFile.getFilePointer();
        randomAccessFile.seek(filePointer);
        Util.writeInt(randomAccessFile, (int)(filePointer2 - filePointer - 4L));
        randomAccessFile.seek(filePointer2);
    }
}
