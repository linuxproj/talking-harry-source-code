package com.outfit7.jpeg2avi;

import java.io.IOException;
import java.io.RandomAccessFile;

public class Avi
{
    AudioStreamFormat audioStreamFormat;
    StreamHeader audioStreamHeader;
    AviHeader aviHeader;
    long marker;
    int offsetCount;
    int[] offsets;
    int offsetsLen;
    int offsetsPtr;
    long offsetsStart;
    RandomAccessFile out;
    VideoStreamFormat videoStreamFormat;
    StreamHeader videoStreamHeader;
    
    public Avi(final String s, final int n, final int n2, final String codec, final int dataRate, final AviAudio aviAudio) throws Exception {
        this.out = new RandomAccessFile(s, "rw");
        this.aviHeader = new AviHeader();
        this.aviHeader.timeDelay = 1000000 / dataRate;
        this.aviHeader.dataRate = n * n2 * 3;
        this.aviHeader.flags = 16;
        final AviHeader aviHeader = this.aviHeader;
        int dataStreams;
        if (aviAudio == null) {
            dataStreams = 1;
        }
        else {
            dataStreams = 2;
        }
        aviHeader.dataStreams = dataStreams;
        this.aviHeader.numberOfFrames = 0;
        this.aviHeader.width = n;
        this.aviHeader.height = n2;
        this.aviHeader.bufferSize = n * n2 * 3;
        this.videoStreamHeader = new StreamHeader();
        this.videoStreamHeader.dataType = "vids";
        this.videoStreamHeader.codec = codec;
        this.videoStreamHeader.timeScale = 1;
        this.videoStreamHeader.dataRate = dataRate;
        this.videoStreamHeader.bufferSize = n * n2 * 3;
        this.videoStreamHeader.dataLength = 0;
        this.videoStreamFormat = new VideoStreamFormat();
        this.videoStreamFormat.headerSize = 40;
        this.videoStreamFormat.width = n;
        this.videoStreamFormat.height = n2;
        this.videoStreamFormat.numPlanes = 1;
        this.videoStreamFormat.bitsPerPixel = 24;
        this.videoStreamFormat.compressionType = (codec.codePointAt(3) << 24) + (codec.codePointAt(2) << 16) + (codec.codePointAt(1) << 8) + codec.codePointAt(0);
        this.videoStreamFormat.imageSize = n * n2 * 3;
        this.videoStreamFormat.colorsUsed = 0;
        this.videoStreamFormat.colorsImportant = 0;
        this.videoStreamFormat.palette = null;
        this.videoStreamFormat.paletteCount = 0;
        if (this.aviHeader.dataStreams == 2) {
            this.audioStreamHeader = new StreamHeader();
            this.audioStreamHeader.dataType = "auds";
            this.audioStreamHeader.codec = "\u0001\u0000\u0000\u0000";
            this.audioStreamHeader.timeScale = 1;
            this.audioStreamHeader.dataRate = aviAudio.samplesPerSecond;
            this.audioStreamHeader.bufferSize = aviAudio.channels * (aviAudio.bits / 8) * aviAudio.samplesPerSecond;
            this.audioStreamHeader.quality = -1;
            this.audioStreamHeader.sampleSize = aviAudio.bits / 8 * aviAudio.channels;
            this.audioStreamFormat = new AudioStreamFormat();
            this.audioStreamFormat.formatType = 1;
            this.audioStreamFormat.channels = (short)aviAudio.channels;
            this.audioStreamFormat.sampleRate = aviAudio.samplesPerSecond;
            this.audioStreamFormat.bytesPerSecond = aviAudio.channels * (aviAudio.bits / 8) * aviAudio.samplesPerSecond;
            this.audioStreamFormat.blockAlign = (short)(aviAudio.channels * (aviAudio.bits / 8));
            this.audioStreamFormat.bitsPerSample = (short)aviAudio.bits;
            this.audioStreamFormat.size = 0;
        }
        this.out.writeBytes("RIFF");
        Util.writeInt(this.out, 0);
        this.out.writeBytes("AVI ");
        this.writeHeaderChunk();
        this.out.writeBytes("LIST");
        this.marker = this.out.getFilePointer();
        Util.writeInt(this.out, 0);
        this.out.writeBytes("movi");
        this.offsetsLen = 1024;
        this.offsets = new int[this.offsetsLen];
        this.offsetsPtr = 0;
    }
    
    private void writeHeaderChunk() throws IOException {
        this.out.writeBytes("LIST");
        final long filePointer = this.out.getFilePointer();
        Util.writeInt(this.out, 0);
        this.out.writeBytes("hdrl");
        this.aviHeader.write(this.out);
        this.out.writeBytes("LIST");
        final long filePointer2 = this.out.getFilePointer();
        Util.writeInt(this.out, 0);
        this.out.writeBytes("strl");
        this.videoStreamHeader.write(this.out);
        this.videoStreamFormat.write(this.out);
        final long filePointer3 = this.out.getFilePointer();
        this.out.seek(filePointer2);
        Util.writeInt(this.out, (int)(filePointer3 - filePointer2 - 4L));
        this.out.seek(filePointer3);
        if (this.aviHeader.dataStreams == 2) {
            this.out.writeBytes("LIST");
            final long filePointer4 = this.out.getFilePointer();
            Util.writeInt(this.out, 0);
            this.out.writeBytes("strl");
            this.audioStreamHeader.write(this.out);
            this.audioStreamFormat.write(this.out);
            final long filePointer5 = this.out.getFilePointer();
            this.out.seek(filePointer4);
            Util.writeInt(this.out, (int)(filePointer5 - filePointer4 - 4L));
            this.out.seek(filePointer5);
        }
        final long filePointer6 = this.out.getFilePointer();
        this.out.seek(filePointer);
        Util.writeInt(this.out, (int)(filePointer6 - filePointer - 4L));
        this.out.seek(filePointer6);
        this.writeJunkChunk();
    }
    
    private int writeIndex() throws IOException {
        int n = 4;
        int n2;
        if (this.offsets == null) {
            n2 = -1;
        }
        else {
            this.out.writeBytes("idx1");
            final long filePointer = this.out.getFilePointer();
            Util.writeInt(this.out, 0);
            for (int offsetCount = this.offsetCount, i = 0; i < offsetCount; ++i) {
                if ((this.offsets[i] & Integer.MIN_VALUE) == 0x0) {
                    Util.writeChars(this.out, "00dc");
                }
                else {
                    Util.writeChars(this.out, "01wb");
                    final int[] offsets = this.offsets;
                    offsets[i] &= Integer.MAX_VALUE;
                }
                Util.writeInt(this.out, 16);
                Util.writeInt(this.out, n);
                Util.writeInt(this.out, this.offsets[i]);
                n += this.offsets[i] + 8;
            }
            final long filePointer2 = this.out.getFilePointer();
            this.out.seek(filePointer);
            Util.writeInt(this.out, (int)(filePointer2 - filePointer - 4L));
            this.out.seek(filePointer2);
            n2 = 0;
        }
        return n2;
    }
    
    private void writeJunkChunk() throws IOException {
        this.out.writeBytes("JUNK");
        final long filePointer = this.out.getFilePointer();
        Util.writeInt(this.out, 0);
        final int n = (int)(4096L - this.out.getFilePointer());
        final int length = "JUNK IN THE CHUNK! ".length();
        int i = 0;
        int n2 = 0;
        while (i < n) {
            final RandomAccessFile out = this.out;
            final int n3 = n2 + 1;
            out.write((int)"JUNK IN THE CHUNK! ".charAt(n2));
            if ((n2 = n3) >= length) {
                n2 = 0;
            }
            ++i;
        }
        final long filePointer2 = this.out.getFilePointer();
        this.out.seek(filePointer);
        Util.writeInt(this.out, (int)(filePointer2 - filePointer - 4L));
        this.out.seek(filePointer2);
    }
    
    public void addAudio(final byte[] array, final int n) throws IOException {
        ++this.offsetCount;
        int n3;
        final int n2 = n3 = n % 4;
        if (n2 > 0) {
            n3 = 4 - n2;
        }
        if (this.offsetCount >= this.offsetsLen) {
            this.offsetsLen += 1024;
            final int[] offsets = new int[this.offsetsLen];
            System.arraycopy((Object)this.offsets, 0, (Object)offsets, 0, this.offsets.length);
            this.offsets = offsets;
        }
        this.offsets[this.offsetsPtr++] = (n + n3 | Integer.MIN_VALUE);
        this.out.writeBytes("01wb");
        Util.writeInt(this.out, n + n3);
        this.out.write(array, 0, n);
        for (int i = 0; i < n3; ++i) {
            this.out.write(0);
        }
        final StreamHeader audioStreamHeader = this.audioStreamHeader;
        audioStreamHeader.dataLength += n + n3;
    }
    
    public void addFrame(final byte[] array, int i) throws IOException {
        ++this.offsetCount;
        final StreamHeader videoStreamHeader = this.videoStreamHeader;
        ++videoStreamHeader.dataLength;
        int n2;
        final int n = n2 = i % 4;
        if (n > 0) {
            n2 = 4 - n;
        }
        if (this.offsetCount >= this.offsetsLen) {
            this.offsetsLen += 1024;
            final int[] offsets = new int[this.offsetsLen];
            System.arraycopy((Object)this.offsets, 0, (Object)offsets, 0, this.offsets.length);
            this.offsets = offsets;
        }
        this.offsets[this.offsetsPtr++] = i + n2;
        this.out.writeBytes("00dc");
        Util.writeInt(this.out, i + n2);
        this.out.write(array, 0, i);
        for (i = 0; i < n2; ++i) {
            this.out.write(0);
        }
    }
    
    public void close() throws IOException {
        final long filePointer = this.out.getFilePointer();
        this.out.seek(this.marker);
        Util.writeInt(this.out, (int)(filePointer - this.marker - 4L));
        this.out.seek(filePointer);
        this.writeIndex();
        this.offsets = null;
        this.aviHeader.numberOfFrames = this.videoStreamHeader.dataLength;
        final long filePointer2 = this.out.getFilePointer();
        this.out.seek(12L);
        this.writeHeaderChunk();
        this.out.seek(filePointer2);
        final long filePointer3 = this.out.getFilePointer();
        this.out.seek(4L);
        Util.writeInt(this.out, (int)(filePointer3 - 8L));
        this.out.seek(filePointer3);
        this.videoStreamFormat.palette = null;
        this.out.close();
    }
}
