package com.outfit7.jpeg2avi;

class AudioDecoder
{
    private static final boolean DEBUG = false;
    
    public static void main(final String[] p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: arraylength    
        //     2: iconst_2       
        //     3: if_icmpeq       9
        //     6: invokestatic    com/outfit7/jpeg2avi/AudioDecoder.printUsageAndExit:()V
        //     9: new             Ljava/io/File;
        //    12: dup            
        //    13: aload_0        
        //    14: iconst_0       
        //    15: aaload         
        //    16: invokespecial   java/io/File.<init>:(Ljava/lang/String;)V
        //    19: astore_1       
        //    20: new             Ljava/io/File;
        //    23: dup            
        //    24: aload_0        
        //    25: iconst_1       
        //    26: aaload         
        //    27: invokespecial   java/io/File.<init>:(Ljava/lang/String;)V
        //    30: astore_2       
        //    31: aconst_null    
        //    32: astore_0       
        //    33: aload_1        
        //    34: invokestatic    javax/sound/sampled/AudioSystem.getAudioInputStream:(Ljava/io/File;)Ljavax/sound/sampled/AudioInputStream;
        //    37: astore_1       
        //    38: aload_1        
        //    39: astore_0       
        //    40: aload_0        
        //    41: ifnonnull       53
        //    44: ldc             "cannot open input file"
        //    46: invokestatic    com/outfit7/jpeg2avi/AudioDecoder.out:(Ljava/lang/String;)V
        //    49: iconst_1       
        //    50: invokestatic    java/lang/System.exit:(I)V
        //    53: getstatic       javax/sound/sampled/AudioFormat$Encoding.PCM_SIGNED:Ljavax/sound/sampled/AudioFormat$Encoding;
        //    56: aload_0        
        //    57: invokestatic    javax/sound/sampled/AudioSystem.getAudioInputStream:(Ljavax/sound/sampled/AudioFormat$Encoding;Ljavax/sound/sampled/AudioInputStream;)Ljavax/sound/sampled/AudioInputStream;
        //    60: astore_0       
        //    61: getstatic       javax/sound/sampled/AudioFileFormat$Type.AU:Ljavax/sound/sampled/AudioFileFormat$Type;
        //    64: astore_1       
        //    65: aload_0        
        //    66: aload_1        
        //    67: aload_2        
        //    68: invokestatic    javax/sound/sampled/AudioSystem.write:(Ljavax/sound/sampled/AudioInputStream;Ljavax/sound/sampled/AudioFileFormat$Type;Ljava/io/File;)I
        //    71: pop            
        //    72: return         
        //    73: astore_1       
        //    74: aload_1        
        //    75: invokevirtual   java/lang/Exception.printStackTrace:()V
        //    78: goto            40
        //    81: astore_0       
        //    82: aload_0        
        //    83: invokevirtual   java/io/IOException.printStackTrace:()V
        //    86: goto            72
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  33     38     73     81     Ljava/lang/Exception;
        //  65     72     81     89     Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0072:
        //     at w5.m.a(SourceFile:20)
        //     at w5.f.o(SourceFile:122)
        //     at w5.f.r(SourceFile:571)
        //     at w5.f.q(SourceFile:3)
        //     at a6.j.j(SourceFile:32)
        //     at a6.j.i(SourceFile:28)
        //     at a6.i.n(SourceFile:7)
        //     at a6.i.m(SourceFile:174)
        //     at a6.i.c(SourceFile:67)
        //     at a6.i.r(SourceFile:328)
        //     at a6.i.s(SourceFile:17)
        //     at a6.i.q(SourceFile:29)
        //     at a6.i.b(SourceFile:33)
        //     at y5.d.e(SourceFile:6)
        //     at y5.d.b(SourceFile:1)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(SourceFile:306)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:131)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
        //     at e7.a.run(SourceFile:1)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        //     at java.lang.Thread.run(Thread.java:1012)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private static void out(final String s) {
        System.out.println(s);
    }
    
    private static void printUsageAndExit() {
        out("AudioDecoder: usage:");
        out("\tjava AudioDecoder <encodedfile> <pcmfile>");
        System.exit(1);
    }
}
