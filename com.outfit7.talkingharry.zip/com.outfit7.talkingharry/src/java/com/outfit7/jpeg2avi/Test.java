package com.outfit7.jpeg2avi;

import java.io.IOException;
import java.io.RandomAccessFile;

public class Test
{
    private static JpegMetaData getJpegMetaData(final RandomAccessFile randomAccessFile) throws IOException {
        final JpegMetaData jpegMetaData = new JpegMetaData(null);
        int read;
        do {
            read = randomAccessFile.read();
            if (read == -1) {
                return null;
            }
        } while (read != 255 || randomAccessFile.read() != 192);
        randomAccessFile.read();
        randomAccessFile.read();
        randomAccessFile.read();
        jpegMetaData.height = (randomAccessFile.read() << 8) + randomAccessFile.read();
        jpegMetaData.width = (randomAccessFile.read() << 8) + randomAccessFile.read();
        jpegMetaData.fileLength = randomAccessFile.length();
        return jpegMetaData;
    }
    
    public static void main(final String[] array) throws Exception {
        final RandomAccessFile randomAccessFile = new RandomAccessFile("d:/Animations/Cat_Angry/cat_angry0000.jpg", "r");
        final JpegMetaData jpegMetaData = getJpegMetaData(randomAccessFile);
        System.out.println((Object)jpegMetaData);
        randomAccessFile.seek(0L);
        final byte[] array2 = new byte[(int)jpegMetaData.fileLength];
        randomAccessFile.read(array2, 0, (int)jpegMetaData.fileLength);
        randomAccessFile.close();
        final byte[] array3 = new byte[22050];
        for (int i = 0; i < 22050; ++i) {
            array3[i] = (byte)(i & 0xFF);
        }
        final AviAudio aviAudio = new AviAudio();
        aviAudio.channels = 1;
        aviAudio.bits = 8;
        aviAudio.samplesPerSecond = 22050;
        final Avi avi = new Avi("d:/out.avi", jpegMetaData.width, jpegMetaData.height, "MJPG", 10, aviAudio);
        for (int j = 0; j < 300; ++j) {
            avi.addFrame(array2, (int)jpegMetaData.fileLength);
            if (j % 100 == 0) {
                System.out.println("Frames so far: " + j);
            }
        }
        final byte[] array4 = null;
        avi.close();
    }
    
    private static class JpegMetaData
    {
        long fileLength;
        int height;
        int width;
        
        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder();
            sb.append("JpegMetaData[width=").append(this.width).append(" height=").append(this.height).append(" length=").append(this.fileLength);
            return sb.toString();
        }
    }
}
