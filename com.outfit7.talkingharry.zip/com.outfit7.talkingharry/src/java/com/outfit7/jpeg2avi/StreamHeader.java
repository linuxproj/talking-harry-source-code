package com.outfit7.jpeg2avi;

import java.io.IOException;
import java.io.RandomAccessFile;

class StreamHeader
{
    int bufferSize;
    String codec;
    int dataLength;
    int dataRate;
    String dataType;
    int flags;
    int initialFrames;
    int priority;
    int quality;
    int sampleSize;
    int startTime;
    int timeScale;
    
    public void write(final RandomAccessFile randomAccessFile) throws IOException {
        randomAccessFile.writeBytes("strh");
        final long filePointer = randomAccessFile.getFilePointer();
        Util.writeInt(randomAccessFile, 0);
        randomAccessFile.writeBytes(this.dataType);
        randomAccessFile.writeBytes(this.codec);
        Util.writeInt(randomAccessFile, this.flags);
        Util.writeInt(randomAccessFile, this.priority);
        Util.writeInt(randomAccessFile, this.initialFrames);
        Util.writeInt(randomAccessFile, this.timeScale);
        Util.writeInt(randomAccessFile, this.dataRate);
        Util.writeInt(randomAccessFile, this.startTime);
        Util.writeInt(randomAccessFile, this.dataLength);
        Util.writeInt(randomAccessFile, this.bufferSize);
        Util.writeInt(randomAccessFile, this.quality);
        Util.writeInt(randomAccessFile, this.sampleSize);
        Util.writeInt(randomAccessFile, 0);
        Util.writeInt(randomAccessFile, 0);
        final long filePointer2 = randomAccessFile.getFilePointer();
        randomAccessFile.seek(filePointer);
        Util.writeInt(randomAccessFile, (int)(filePointer2 - filePointer - 4L));
        randomAccessFile.seek(filePointer2);
    }
}
