package com.outfit7.talkingtom;

import android.app.Activity;
import android.view.View;
import android.view.View$OnClickListener;

final class bo implements View$OnClickListener
{
    final Main a;
    
    bo(final Main a) {
        this.a = a;
    }
    
    public final void onClick(final View view) {
        final Engine a = this.a.c;
        a.getClass();
        final bp bp = new bp(this, a, "gozd/rdece_odtece", this.a);
        bp.b = 5;
        bp.d = true;
        bp.i();
        this.a.c.c.a().sendMessage(this.a.c.c.a().obtainMessage(0, (Object)bp));
    }
}
