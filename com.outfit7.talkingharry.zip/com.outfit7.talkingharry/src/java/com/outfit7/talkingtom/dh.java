package com.outfit7.talkingtom;

import android.view.View;
import android.widget.ProgressBar;
import android.os.Handler;

final class dh
{
    private Handler a;
    private ProgressBar b;
    private boolean c;
    private boolean d;
    private boolean e;
    private Main f;
    
    dh(final Main f) {
        this.f = f;
        this.a = new Handler();
    }
    
    final void a() {
        synchronized (this) {
            this.e = true;
        }
    }
    
    final void a(final View view, final Thread thread) {
        synchronized (this) {
            if (this.e) {
                (this.b = (ProgressBar)view).setVisibility(0);
                this.b.setProgress(100);
                new di(this, thread).start();
            }
        }
    }
    
    final void a(final boolean c) {
        this.c = c;
    }
    
    final void b() {
        synchronized (this) {
            this.e = false;
            this.f.c.b.post((Runnable)new dk(this));
        }
    }
    
    final void b(final boolean d) {
        synchronized (this) {
            this.d = d;
            this.notify();
        }
    }
}
