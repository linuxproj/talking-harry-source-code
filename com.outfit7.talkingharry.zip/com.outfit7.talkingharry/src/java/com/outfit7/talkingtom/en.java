package com.outfit7.talkingtom;

import android.os.Parcelable;
import android.content.Intent;
import android.net.Uri;
import android.app.AlertDialog;
import android.content.SharedPreferences$Editor;
import android.content.SharedPreferences;
import android.util.Log;
import android.content.DialogInterface$OnClickListener;
import android.content.Context;
import android.app.AlertDialog$Builder;
import android.app.Activity;

public class en
{
    private static final String a;
    
    static {
        a = en.class.getName();
    }
    
    public static void a(final Activity activity) {
        b.a(true, activity, new eo(activity));
    }
    
    public static boolean b(final Activity activity) {
        final SharedPreferences sharedPreferences = activity.getSharedPreferences("app_prefs", 2);
        final int int1 = sharedPreferences.getInt("rateDialogDisplayedCount", 0);
        final long long1 = sharedPreferences.getLong("rateDialogLastDisplayedTimestamp", 0L);
        final long currentTimeMillis = System.currentTimeMillis();
        boolean b;
        if (int1 >= 3 || currentTimeMillis - long1 < 57600000L) {
            b = false;
        }
        else {
            final SharedPreferences$Editor edit = sharedPreferences.edit();
            edit.putInt("rateDialogDisplayedCount", int1 + 1);
            edit.putLong("rateDialogLastDisplayedTimestamp", System.currentTimeMillis());
            edit.commit();
            final AlertDialog$Builder alertDialog$Builder = new AlertDialog$Builder((Context)activity);
            alertDialog$Builder.setTitle((CharSequence)activity.getResources().getString(2131099671));
            alertDialog$Builder.setMessage((CharSequence)activity.getResources().getString(2131099672));
            alertDialog$Builder.setCancelable(false);
            alertDialog$Builder.setPositiveButton((CharSequence)activity.getResources().getString(2131099673), (DialogInterface$OnClickListener)new eq(activity, 2));
            alertDialog$Builder.setNegativeButton((CharSequence)activity.getResources().getString(2131099674), (DialogInterface$OnClickListener)new er(activity));
            final AlertDialog create = alertDialog$Builder.create();
            while (true) {
                try {
                    create.show();
                    b = true;
                }
                catch (final RuntimeException ex) {
                    Log.w(en.a, ex.getLocalizedMessage(), (Throwable)ex);
                    continue;
                }
                break;
            }
        }
        return b;
    }
    
    public static void c(final Activity activity) {
        final TalkingTomApplication talkingTomApplication = (TalkingTomApplication)activity.getApplicationContext();
        final String string = activity.getResources().getString(2131099668);
        final Uri fromFile = Uri.fromFile(talkingTomApplication.d());
        final Intent intent = new Intent("android.intent.action.SEND");
        intent.putExtra("android.intent.extra.SUBJECT", string);
        intent.putExtra("android.intent.extra.STREAM", (Parcelable)fromFile);
        intent.setType("message/rfc2822");
        activity.startActivityForResult(intent, 1);
    }
}
