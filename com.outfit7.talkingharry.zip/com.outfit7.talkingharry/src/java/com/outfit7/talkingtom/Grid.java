package com.outfit7.talkingtom;

import android.view.KeyEvent;
import android.graphics.drawable.Drawable;
import org.json.JSONObject;
import java.net.MalformedURLException;
import org.json.JSONException;
import android.graphics.Typeface;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.view.View;
import android.view.ViewGroup$LayoutParams;
import android.widget.TableLayout$LayoutParams;
import android.widget.TableRow;
import java.net.URL;
import android.util.Log;
import org.json.JSONArray;
import android.widget.TableLayout;
import android.view.View$OnClickListener;
import android.os.Bundle;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager$NameNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.app.Activity;

public class Grid extends Activity
{
    private static final String a;
    
    static {
        a = Grid.class.getName();
    }
    
    private void a() {
        final Intent intent = new Intent((Context)this, (Class)Main.class);
        intent.putExtra("disableGrid", System.currentTimeMillis());
        this.startActivity(intent);
        this.finish();
    }
    
    private boolean a(final String s) {
        final PackageManager packageManager = this.getPackageManager();
        try {
            packageManager.getPackageInfo(s, 1);
            return true;
        }
        catch (final PackageManager$NameNotFoundException ex) {
            return false;
        }
    }
    
    public void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        final String packageName = this.getPackageName();
        final String e = TalkingTomApplication.e();
        final String f = TalkingTomApplication.f();
        Label_0315: {
            if (!packageName.equals((Object)e) && !packageName.equals((Object)f) && !this.a(e)) {
                break Label_0315;
            }
            int n = 1;
            while (true) {
                this.setContentView(2130903040);
                this.findViewById(2131296257).setOnClickListener((View$OnClickListener)new ax(this));
                final TableLayout tableLayout = (TableLayout)this.findViewById(2131296256);
                try {
                    final JSONArray jsonArray = new JSONArray(this.getIntent().getExtras().getString("gridData"));
                    if (jsonArray.length() == 0) {
                        this.a();
                    }
                    final JSONArray jsonArray2 = new JSONArray();
                    Log.v(Grid.a, "gridData: " + this.getIntent().getExtras().getString("gridData"));
                    for (int i = 0; i < jsonArray.length(); ++i) {
                        if (jsonArray.getJSONObject(i).getString("friendId").equals((Object)packageName)) {
                            jsonArray2.put((Object)jsonArray.getJSONObject(i));
                            break;
                        }
                    }
                    for (int j = 0; j < jsonArray.length(); ++j) {
                        final JSONObject jsonObject = jsonArray.getJSONObject(j);
                        final String string = jsonObject.getString("friendId");
                        Log.d(Grid.a, "Grid friend id: " + string);
                        if (!string.equals((Object)packageName) && (n == 0 || !string.equals((Object)f))) {
                            jsonArray2.put((Object)jsonObject);
                        }
                    }
                    Object o = null;
                    int n2 = 0;
                    TableRow tableRow;
                    int n3;
                    for (int k = 0; k < jsonArray2.length(); ++k, o = tableRow, n2 = n3) {
                        final JSONObject jsonObject2 = jsonArray2.getJSONObject(k);
                        final String string2 = jsonObject2.getString("friendId");
                        final Drawable a = Main.a((Context)this, new URL(jsonObject2.getString("iconUrl")));
                        tableRow = (TableRow)o;
                        n3 = n2;
                        if (a != null) {
                            if (n2 == 0) {
                                o = new TableRow((Context)this);
                                final TableLayout$LayoutParams layoutParams = new TableLayout$LayoutParams(-2, -2);
                                layoutParams.bottomMargin = 20;
                                ((TableRow)o).setLayoutParams((ViewGroup$LayoutParams)layoutParams);
                                tableLayout.addView((View)o);
                            }
                            final LinearLayout linearLayout = new LinearLayout((Context)this);
                            linearLayout.setOrientation(1);
                            linearLayout.setGravity(1);
                            final ImageView imageView = new ImageView((Context)this);
                            imageView.setBackgroundDrawable(a);
                            if (this.getString(2131099648).equals((Object)"normal")) {
                                imageView.setLayoutParams(new ViewGroup$LayoutParams(72, 72));
                            }
                            else {
                                imageView.setLayoutParams(new ViewGroup$LayoutParams(48, 48));
                            }
                            linearLayout.addView((View)imageView);
                            final TextView textView = new TextView((Context)this);
                            textView.setText((CharSequence)jsonObject2.getString("title"));
                            textView.setTextSize(12.0f);
                            textView.setTypeface((Typeface)null, 1);
                            textView.setLayoutParams(new ViewGroup$LayoutParams(-1, -2));
                            textView.setGravity(1);
                            linearLayout.addView((View)textView);
                            final ay ay = new ay(this, string2);
                            final az az = new az(this, jsonObject2);
                            if (!this.a(string2)) {
                                goto Label_0735;
                            }
                            imageView.setImageDrawable(this.getResources().getDrawable(2130837520));
                            imageView.setOnClickListener((View$OnClickListener)ay);
                            textView.setOnClickListener((View$OnClickListener)ay);
                            ((TableRow)o).addView((View)linearLayout);
                            ++n2;
                            tableRow = (TableRow)o;
                            if ((n3 = n2) == 3) {
                                n3 = 0;
                                tableRow = (TableRow)o;
                            }
                        }
                    }
                    goto Label_0734;
                    n = 0;
                }
                catch (final JSONException ex) {
                    Log.e(Grid.a, ex.getLocalizedMessage(), (Throwable)ex);
                }
                catch (final MalformedURLException ex2) {
                    Log.e(Grid.a, ex2.getLocalizedMessage(), (Throwable)ex2);
                    goto Label_0734;
                }
            }
        }
    }
    
    public boolean onKeyDown(final int n, final KeyEvent keyEvent) {
        if (n == 4) {
            this.a();
        }
        return super.onKeyDown(n, keyEvent);
    }
    
    public void onPause() {
        super.onPause();
        this.finish();
    }
}
