package com.outfit7.talkingtom;

import android.content.DialogInterface;
import android.content.DialogInterface$OnDismissListener;

final class fz implements DialogInterface$OnDismissListener
{
    private fy a;
    
    fz(final fy a) {
        this.a = a;
    }
    
    public final void onDismiss(final DialogInterface dialogInterface) {
        ((BackgroundActivity)this.a.a).a().sendEmptyMessage(2);
    }
}
