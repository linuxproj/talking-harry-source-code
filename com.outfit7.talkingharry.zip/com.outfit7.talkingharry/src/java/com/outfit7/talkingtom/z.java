package com.outfit7.talkingtom;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.BlockingQueue;

final class z extends Thread
{
    private BlockingQueue a;
    private u b;
    
    public z(final u b) {
        this.b = b;
        this.a = (BlockingQueue)new LinkedBlockingQueue();
    }
    
    final void a() {
        synchronized (this) {
            this.a.clear();
        }
    }
    
    final void a(final ap ex) {
        try {
            ((ap)ex).a.lock();
            try {
                this.a.put((Object)ex);
                ((ap)ex).b.await();
            }
            finally {
                ((ap)ex).a.unlock();
            }
        }
        catch (final InterruptedException ex) {}
    }
    
    public final void run() {
        while (true) {
            Object o;
            try {
                while (true) {
                    o = this.a.take();
                    ((ap)o).a.lock();
                    final z z = this;
                    final u u = z.b;
                    final ap ap = (ap)o;
                    u.a(ap);
                    final ap ap2 = (ap)o;
                    final Condition condition = ap2.b;
                    condition.signal();
                }
            }
            catch (final InterruptedException o) {
                continue;
            }
            try {
                final z z = this;
                final u u = z.b;
                final ap ap = (ap)o;
                u.a(ap);
                final ap ap2 = (ap)o;
                final Condition condition = ap2.b;
                condition.signal();
                continue;
            }
            finally {
                ((ap)o).a.unlock();
            }
            break;
        }
    }
}
