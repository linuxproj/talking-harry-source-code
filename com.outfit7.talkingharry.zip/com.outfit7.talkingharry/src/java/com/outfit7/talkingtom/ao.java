package com.outfit7.talkingtom;

final class ao extends Thread
{
    private boolean a;
    private ad b;
    
    private ao(final ad b, final byte b2) {
        this.b = b;
    }
    
    final void a() {
        this.a = true;
    }
    
    public final void run() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: dup            
        //     2: astore          9
        //     4: monitorenter   
        //     5: aload_0        
        //     6: invokevirtual   java/lang/Object.notify:()V
        //     9: aload           9
        //    11: monitorexit    
        //    12: aload_0        
        //    13: getfield        com/outfit7/talkingtom/ao.b:Lcom/outfit7/talkingtom/ad;
        //    16: getfield        com/outfit7/talkingtom/ad.b:Lcom/outfit7/talkingtom/Engine;
        //    19: getfield        com/outfit7/talkingtom/Engine.b:Lcom/outfit7/talkingtom/s;
        //    22: aload_0        
        //    23: getfield        com/outfit7/talkingtom/ao.b:Lcom/outfit7/talkingtom/ad;
        //    26: getfield        com/outfit7/talkingtom/ad.b:Lcom/outfit7/talkingtom/Engine;
        //    29: getfield        com/outfit7/talkingtom/Engine.b:Lcom/outfit7/talkingtom/s;
        //    32: bipush          21
        //    34: invokevirtual   com/outfit7/talkingtom/s.obtainMessage:(I)Landroid/os/Message;
        //    37: invokevirtual   com/outfit7/talkingtom/s.sendMessage:(Landroid/os/Message;)Z
        //    40: pop            
        //    41: aload_0        
        //    42: getfield        com/outfit7/talkingtom/ao.b:Lcom/outfit7/talkingtom/ad;
        //    45: aload_0        
        //    46: getfield        com/outfit7/talkingtom/ao.b:Lcom/outfit7/talkingtom/ad;
        //    49: iconst_0       
        //    50: invokestatic    com/outfit7/talkingtom/ad.b:(Lcom/outfit7/talkingtom/ad;I)I
        //    53: invokestatic    com/outfit7/talkingtom/ad.a:(Lcom/outfit7/talkingtom/ad;I)I
        //    56: pop            
        //    57: iconst_0       
        //    58: istore_2       
        //    59: iconst_1       
        //    60: istore_1       
        //    61: new             Lcom/outfit7/talkingtom/r;
        //    64: astore          7
        //    66: aload           7
        //    68: aload_0        
        //    69: getfield        com/outfit7/talkingtom/ao.b:Lcom/outfit7/talkingtom/ad;
        //    72: getfield        com/outfit7/talkingtom/ad.b:Lcom/outfit7/talkingtom/Engine;
        //    75: invokespecial   com/outfit7/talkingtom/r.<init>:(Lcom/outfit7/talkingtom/Engine;)V
        //    78: aload_0        
        //    79: getfield        com/outfit7/talkingtom/ao.a:Z
        //    82: ifne            269
        //    85: iload_2        
        //    86: iconst_5       
        //    87: irem           
        //    88: ifne            401
        //    91: iload_1        
        //    92: ifne            264
        //    95: iconst_1       
        //    96: istore_1       
        //    97: aload_0        
        //    98: getfield        com/outfit7/talkingtom/ao.b:Lcom/outfit7/talkingtom/ad;
        //   101: getfield        com/outfit7/talkingtom/ad.b:Lcom/outfit7/talkingtom/Engine;
        //   104: getfield        com/outfit7/talkingtom/Engine.b:Lcom/outfit7/talkingtom/s;
        //   107: astore_3       
        //   108: aload_0        
        //   109: getfield        com/outfit7/talkingtom/ao.b:Lcom/outfit7/talkingtom/ad;
        //   112: getfield        com/outfit7/talkingtom/ad.b:Lcom/outfit7/talkingtom/Engine;
        //   115: getfield        com/outfit7/talkingtom/Engine.b:Lcom/outfit7/talkingtom/s;
        //   118: astore          4
        //   120: new             Lcom/outfit7/talkingtom/ac;
        //   123: astore          6
        //   125: aload_0        
        //   126: getfield        com/outfit7/talkingtom/ao.b:Lcom/outfit7/talkingtom/ad;
        //   129: invokestatic    com/outfit7/talkingtom/ad.b:(Lcom/outfit7/talkingtom/ad;)[Landroid/graphics/drawable/Drawable;
        //   132: iload_1        
        //   133: aaload         
        //   134: astore          8
        //   136: new             Ljava/lang/Integer;
        //   139: astore          5
        //   141: aload           5
        //   143: sipush          300
        //   146: aload_0        
        //   147: getfield        com/outfit7/talkingtom/ao.b:Lcom/outfit7/talkingtom/ad;
        //   150: invokestatic    com/outfit7/talkingtom/ad.c:(Lcom/outfit7/talkingtom/ad;)I
        //   153: isub           
        //   154: bipush          10
        //   156: idiv           
        //   157: invokespecial   java/lang/Integer.<init>:(I)V
        //   160: aload           6
        //   162: aload           8
        //   164: aload           5
        //   166: invokevirtual   java/lang/Integer.toString:()Ljava/lang/String;
        //   169: invokespecial   com/outfit7/talkingtom/ac.<init>:(Landroid/graphics/drawable/Drawable;Ljava/lang/String;)V
        //   172: aload_3        
        //   173: aload           4
        //   175: bipush          10
        //   177: aload           6
        //   179: invokevirtual   com/outfit7/talkingtom/s.obtainMessage:(ILjava/lang/Object;)Landroid/os/Message;
        //   182: invokevirtual   com/outfit7/talkingtom/s.sendMessage:(Landroid/os/Message;)Z
        //   185: pop            
        //   186: aload_0        
        //   187: getfield        com/outfit7/talkingtom/ao.b:Lcom/outfit7/talkingtom/ad;
        //   190: invokestatic    com/outfit7/talkingtom/ad.d:(Lcom/outfit7/talkingtom/ad;)I
        //   193: pop            
        //   194: aload_0        
        //   195: getfield        com/outfit7/talkingtom/ao.b:Lcom/outfit7/talkingtom/ad;
        //   198: invokestatic    com/outfit7/talkingtom/ad.c:(Lcom/outfit7/talkingtom/ad;)I
        //   201: aload_0        
        //   202: getfield        com/outfit7/talkingtom/ao.b:Lcom/outfit7/talkingtom/ad;
        //   205: invokestatic    com/outfit7/talkingtom/ad.e:(Lcom/outfit7/talkingtom/ad;)I
        //   208: if_icmple       226
        //   211: aload_0        
        //   212: getfield        com/outfit7/talkingtom/ao.b:Lcom/outfit7/talkingtom/ad;
        //   215: aload_0        
        //   216: getfield        com/outfit7/talkingtom/ao.b:Lcom/outfit7/talkingtom/ad;
        //   219: invokestatic    com/outfit7/talkingtom/ad.c:(Lcom/outfit7/talkingtom/ad;)I
        //   222: invokestatic    com/outfit7/talkingtom/ad.b:(Lcom/outfit7/talkingtom/ad;I)I
        //   225: pop            
        //   226: aload_0        
        //   227: getfield        com/outfit7/talkingtom/ao.b:Lcom/outfit7/talkingtom/ad;
        //   230: invokestatic    com/outfit7/talkingtom/ad.c:(Lcom/outfit7/talkingtom/ad;)I
        //   233: sipush          300
        //   236: if_icmpne       247
        //   239: aload_0        
        //   240: getfield        com/outfit7/talkingtom/ao.b:Lcom/outfit7/talkingtom/ad;
        //   243: iconst_0       
        //   244: invokevirtual   com/outfit7/talkingtom/ad.a:(Z)V
        //   247: aload           7
        //   249: invokevirtual   com/outfit7/talkingtom/r.c:()V
        //   252: iinc            2, 1
        //   255: goto            61
        //   258: astore_3       
        //   259: aload           9
        //   261: monitorexit    
        //   262: aload_3        
        //   263: athrow         
        //   264: iconst_0       
        //   265: istore_1       
        //   266: goto            97
        //   269: aload_0        
        //   270: getfield        com/outfit7/talkingtom/ao.b:Lcom/outfit7/talkingtom/ad;
        //   273: getfield        com/outfit7/talkingtom/ad.b:Lcom/outfit7/talkingtom/Engine;
        //   276: getfield        com/outfit7/talkingtom/Engine.b:Lcom/outfit7/talkingtom/s;
        //   279: aload_0        
        //   280: getfield        com/outfit7/talkingtom/ao.b:Lcom/outfit7/talkingtom/ad;
        //   283: getfield        com/outfit7/talkingtom/ad.b:Lcom/outfit7/talkingtom/Engine;
        //   286: getfield        com/outfit7/talkingtom/Engine.b:Lcom/outfit7/talkingtom/s;
        //   289: bipush          10
        //   291: new             Lcom/outfit7/talkingtom/ac;
        //   294: dup            
        //   295: aload_0        
        //   296: getfield        com/outfit7/talkingtom/ao.b:Lcom/outfit7/talkingtom/ad;
        //   299: invokestatic    com/outfit7/talkingtom/ad.b:(Lcom/outfit7/talkingtom/ad;)[Landroid/graphics/drawable/Drawable;
        //   302: iconst_0       
        //   303: aaload         
        //   304: aconst_null    
        //   305: invokespecial   com/outfit7/talkingtom/ac.<init>:(Landroid/graphics/drawable/Drawable;Ljava/lang/String;)V
        //   308: invokevirtual   com/outfit7/talkingtom/s.obtainMessage:(ILjava/lang/Object;)Landroid/os/Message;
        //   311: invokevirtual   com/outfit7/talkingtom/s.sendMessage:(Landroid/os/Message;)Z
        //   314: pop            
        //   315: aload_0        
        //   316: dup            
        //   317: astore          9
        //   319: monitorenter   
        //   320: aload_0        
        //   321: invokevirtual   java/lang/Object.notify:()V
        //   324: aload           9
        //   326: monitorexit    
        //   327: return         
        //   328: astore_3       
        //   329: aload           9
        //   331: monitorexit    
        //   332: aload_3        
        //   333: athrow         
        //   334: astore_3       
        //   335: aload_0        
        //   336: getfield        com/outfit7/talkingtom/ao.b:Lcom/outfit7/talkingtom/ad;
        //   339: getfield        com/outfit7/talkingtom/ad.b:Lcom/outfit7/talkingtom/Engine;
        //   342: getfield        com/outfit7/talkingtom/Engine.b:Lcom/outfit7/talkingtom/s;
        //   345: aload_0        
        //   346: getfield        com/outfit7/talkingtom/ao.b:Lcom/outfit7/talkingtom/ad;
        //   349: getfield        com/outfit7/talkingtom/ad.b:Lcom/outfit7/talkingtom/Engine;
        //   352: getfield        com/outfit7/talkingtom/Engine.b:Lcom/outfit7/talkingtom/s;
        //   355: bipush          10
        //   357: new             Lcom/outfit7/talkingtom/ac;
        //   360: dup            
        //   361: aload_0        
        //   362: getfield        com/outfit7/talkingtom/ao.b:Lcom/outfit7/talkingtom/ad;
        //   365: invokestatic    com/outfit7/talkingtom/ad.b:(Lcom/outfit7/talkingtom/ad;)[Landroid/graphics/drawable/Drawable;
        //   368: iconst_0       
        //   369: aaload         
        //   370: aconst_null    
        //   371: invokespecial   com/outfit7/talkingtom/ac.<init>:(Landroid/graphics/drawable/Drawable;Ljava/lang/String;)V
        //   374: invokevirtual   com/outfit7/talkingtom/s.obtainMessage:(ILjava/lang/Object;)Landroid/os/Message;
        //   377: invokevirtual   com/outfit7/talkingtom/s.sendMessage:(Landroid/os/Message;)Z
        //   380: pop            
        //   381: aload_0        
        //   382: dup            
        //   383: astore          9
        //   385: monitorenter   
        //   386: aload_0        
        //   387: invokevirtual   java/lang/Object.notify:()V
        //   390: aload           9
        //   392: monitorexit    
        //   393: aload_3        
        //   394: athrow         
        //   395: astore_3       
        //   396: aload           9
        //   398: monitorexit    
        //   399: aload_3        
        //   400: athrow         
        //   401: goto            186
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type
        //  -----  -----  -----  -----  ----
        //  5      12     258    264    Any
        //  61     85     334    401    Any
        //  97     186    334    401    Any
        //  186    226    334    401    Any
        //  226    247    334    401    Any
        //  247    252    334    401    Any
        //  320    327    328    334    Any
        //  386    393    395    401    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0061:
        //     at w5.m.a(SourceFile:20)
        //     at w5.f.o(SourceFile:122)
        //     at w5.f.r(SourceFile:571)
        //     at w5.f.q(SourceFile:3)
        //     at a6.j.j(SourceFile:32)
        //     at a6.j.i(SourceFile:28)
        //     at a6.i.n(SourceFile:7)
        //     at a6.i.m(SourceFile:174)
        //     at a6.i.c(SourceFile:67)
        //     at a6.i.r(SourceFile:328)
        //     at a6.i.s(SourceFile:17)
        //     at a6.i.q(SourceFile:29)
        //     at a6.i.b(SourceFile:33)
        //     at y5.d.e(SourceFile:6)
        //     at y5.d.b(SourceFile:1)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(SourceFile:306)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:131)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
        //     at e7.a.run(SourceFile:1)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        //     at java.lang.Thread.run(Thread.java:1012)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
