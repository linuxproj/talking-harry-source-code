package com.outfit7.talkingtom;

import java.util.Iterator;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

abstract class m extends Thread
{
    protected boolean a;
    public int b;
    public String c;
    public boolean d;
    ap e;
    protected Lock f;
    protected Condition g;
    protected Condition h;
    private int i;
    private Engine j;
    
    m(final Engine j) {
        this.j = j;
        this.f = (Lock)new ReentrantLock();
        this.g = this.f.newCondition();
        this.h = this.f.newCondition();
    }
    
    protected abstract void a();
    
    public void a(final m m) {
        if (m instanceof n) {
            final n n = (n)m;
            if (n.l != null) {
                final Iterator iterator = n.l.iterator();
                while (iterator.hasNext()) {
                    ((n)iterator.next()).h();
                }
            }
        }
    }
    
    public void b() {
        if (this.e != null) {
            this.e.d();
        }
    }
    
    public void c() {
    }
    
    protected final void d() {
        if (this.i++ <= 0 && this.d) {
            this.j.m.sendEmptyMessage(0);
        }
    }
    
    public void e() {
        this.a = true;
    }
    
    public void f() {
    }
    
    public final void run() {
        try {
            this.a();
            this.j.c.a().a(this);
            this.b();
            synchronized (this) {
                this.notify();
                monitorexit(this);
                this.d();
            }
        }
        finally {
            this.j.c.a().a(this);
            this.b();
            synchronized (this) {
                this.notify();
                monitorexit(this);
                this.d();
            }
        }
    }
}
