package com.outfit7.talkingtom;

import android.media.AudioTrack;

final class u extends Thread
{
    et a;
    final Engine b;
    private int c;
    private boolean d;
    private z e;
    private w f;
    private y g;
    
    public u(final Engine b) {
        this.b = b;
        this.c = -1;
        this.a = new et(this.b.j * 15, this.b.j * 2 / 10, this.b.j);
    }
    
    private boolean e() {
        synchronized (this) {
            return this.d || this.c > 0;
        }
    }
    
    private void f() {
        synchronized (this) {
            this.f.a();
        }
    }
    
    private void g() {
        synchronized (this) {
            if (this.c == 0) {
                this.f.b();
            }
        }
    }
    
    final void a(final ap ap) {
        if (ap.c != null && ap.d > 0) {
            if (ap.d > ap.c.length) {
                ap.d = ap.c.length;
            }
            final AudioTrack e = new AudioTrack(3, this.b.j, 2, 2, ap.d * 2, 0);
            e.write(ap.c, 0, ap.d);
            try {
                e.play();
                if (!ap.i) {
                    this.b.t.a(ap.a());
                }
                ap.e = e;
            }
            catch (final IllegalStateException ex) {
                e.release();
                throw new IllegalStateException("Uninitialised AudioTrack, sRate = " + this.b.j + ", atBufferSize = " + ap.d * 2, (Throwable)ex);
            }
        }
    }
    
    public final boolean a() {
        synchronized (this) {
            boolean b;
            if (this.d) {
                b = false;
            }
            else if (this.c <= 0) {
                b = true;
            }
            else if (--this.c == 0) {
                this.f.b();
                this.notify();
                b = true;
            }
            else {
                b = false;
            }
            return b;
        }
    }
    
    public final void b() {
        synchronized (this) {
            if (!this.d && this.c >= 0 && this.c++ == 0) {
                this.f();
            }
        }
    }
    
    final void c() {
        synchronized (this) {
            this.b();
            this.d = true;
            this.notify();
        }
    }
    
    final void d() {
        synchronized (this) {
            this.d = false;
            this.e.a();
            while (!this.a()) {}
            this.notify();
        }
    }
    
    public final void run() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     2: invokestatic    android/os/Process.setThreadPriority:(I)V
        //     5: aload_0        
        //     6: new             Lcom/outfit7/talkingtom/z;
        //     9: dup            
        //    10: aload_0        
        //    11: invokespecial   com/outfit7/talkingtom/z.<init>:(Lcom/outfit7/talkingtom/u;)V
        //    14: putfield        com/outfit7/talkingtom/u.e:Lcom/outfit7/talkingtom/z;
        //    17: aload_0        
        //    18: getfield        com/outfit7/talkingtom/u.e:Lcom/outfit7/talkingtom/z;
        //    21: invokevirtual   com/outfit7/talkingtom/z.start:()V
        //    24: aload_0        
        //    25: new             Lcom/outfit7/talkingtom/w;
        //    28: dup            
        //    29: aload_0        
        //    30: invokespecial   com/outfit7/talkingtom/w.<init>:(Lcom/outfit7/talkingtom/u;)V
        //    33: putfield        com/outfit7/talkingtom/u.f:Lcom/outfit7/talkingtom/w;
        //    36: aload_0        
        //    37: iconst_1       
        //    38: putfield        com/outfit7/talkingtom/u.c:I
        //    41: aload_0        
        //    42: invokevirtual   com/outfit7/talkingtom/u.a:()Z
        //    45: pop            
        //    46: aload_0        
        //    47: dup            
        //    48: astore_3       
        //    49: monitorenter   
        //    50: aload_0        
        //    51: invokevirtual   java/lang/Object.notify:()V
        //    54: aload_3        
        //    55: monitorexit    
        //    56: aload_0        
        //    57: getfield        com/outfit7/talkingtom/u.f:Lcom/outfit7/talkingtom/w;
        //    60: invokevirtual   com/outfit7/talkingtom/w.c:()[S
        //    63: astore_2       
        //    64: aload_2        
        //    65: arraylength    
        //    66: istore_1       
        //    67: aload_0        
        //    68: invokespecial   com/outfit7/talkingtom/u.e:()Z
        //    71: ifne            56
        //    74: aload_0        
        //    75: getfield        com/outfit7/talkingtom/u.a:Lcom/outfit7/talkingtom/et;
        //    78: aload_2        
        //    79: iload_1        
        //    80: invokevirtual   com/outfit7/talkingtom/et.a:([SI)I
        //    83: pop            
        //    84: aload_0        
        //    85: getfield        com/outfit7/talkingtom/u.a:Lcom/outfit7/talkingtom/et;
        //    88: invokevirtual   com/outfit7/talkingtom/et.e:()Z
        //    91: ifeq            318
        //    94: aload_0        
        //    95: getfield        com/outfit7/talkingtom/u.g:Lcom/outfit7/talkingtom/y;
        //    98: ifnonnull       198
        //   101: aload_0        
        //   102: new             Lcom/outfit7/talkingtom/y;
        //   105: dup            
        //   106: aload_0        
        //   107: invokespecial   com/outfit7/talkingtom/y.<init>:(Lcom/outfit7/talkingtom/u;)V
        //   110: putfield        com/outfit7/talkingtom/u.g:Lcom/outfit7/talkingtom/y;
        //   113: aload_0        
        //   114: getfield        com/outfit7/talkingtom/u.g:Lcom/outfit7/talkingtom/y;
        //   117: iconst_4       
        //   118: putfield        com/outfit7/talkingtom/y.b:I
        //   121: aload_0        
        //   122: getfield        com/outfit7/talkingtom/u.g:Lcom/outfit7/talkingtom/y;
        //   125: ldc             "listenstart"
        //   127: putfield        com/outfit7/talkingtom/y.c:Ljava/lang/String;
        //   130: aload_0        
        //   131: getfield        com/outfit7/talkingtom/u.g:Lcom/outfit7/talkingtom/y;
        //   134: getfield        com/outfit7/talkingtom/y.f:Ljava/util/concurrent/locks/Lock;
        //   137: invokeinterface java/util/concurrent/locks/Lock.lock:()V
        //   142: aload_0        
        //   143: getfield        com/outfit7/talkingtom/u.b:Lcom/outfit7/talkingtom/Engine;
        //   146: getfield        com/outfit7/talkingtom/Engine.c:Lcom/outfit7/talkingtom/ab;
        //   149: invokevirtual   com/outfit7/talkingtom/ab.a:()Lcom/outfit7/talkingtom/aa;
        //   152: aload_0        
        //   153: getfield        com/outfit7/talkingtom/u.b:Lcom/outfit7/talkingtom/Engine;
        //   156: getfield        com/outfit7/talkingtom/Engine.c:Lcom/outfit7/talkingtom/ab;
        //   159: invokevirtual   com/outfit7/talkingtom/ab.a:()Lcom/outfit7/talkingtom/aa;
        //   162: iconst_0       
        //   163: aload_0        
        //   164: getfield        com/outfit7/talkingtom/u.g:Lcom/outfit7/talkingtom/y;
        //   167: invokevirtual   com/outfit7/talkingtom/aa.obtainMessage:(ILjava/lang/Object;)Landroid/os/Message;
        //   170: invokevirtual   com/outfit7/talkingtom/aa.sendMessage:(Landroid/os/Message;)Z
        //   173: pop            
        //   174: aload_0        
        //   175: getfield        com/outfit7/talkingtom/u.g:Lcom/outfit7/talkingtom/y;
        //   178: getfield        com/outfit7/talkingtom/y.h:Ljava/util/concurrent/locks/Condition;
        //   181: invokeinterface java/util/concurrent/locks/Condition.await:()V
        //   186: aload_0        
        //   187: getfield        com/outfit7/talkingtom/u.g:Lcom/outfit7/talkingtom/y;
        //   190: getfield        com/outfit7/talkingtom/y.f:Ljava/util/concurrent/locks/Lock;
        //   193: invokeinterface java/util/concurrent/locks/Lock.unlock:()V
        //   198: aload_0        
        //   199: getfield        com/outfit7/talkingtom/u.a:Lcom/outfit7/talkingtom/et;
        //   202: invokevirtual   com/outfit7/talkingtom/et.d:()Z
        //   205: ifeq            56
        //   208: aload_0        
        //   209: getfield        com/outfit7/talkingtom/u.a:Lcom/outfit7/talkingtom/et;
        //   212: invokevirtual   com/outfit7/talkingtom/et.c:()V
        //   215: aload_0        
        //   216: getfield        com/outfit7/talkingtom/u.g:Lcom/outfit7/talkingtom/y;
        //   219: invokevirtual   com/outfit7/talkingtom/y.g:()V
        //   222: aload_0        
        //   223: aconst_null    
        //   224: putfield        com/outfit7/talkingtom/u.g:Lcom/outfit7/talkingtom/y;
        //   227: aload_0        
        //   228: invokespecial   com/outfit7/talkingtom/u.f:()V
        //   231: aload_0        
        //   232: getfield        com/outfit7/talkingtom/u.b:Lcom/outfit7/talkingtom/Engine;
        //   235: invokestatic    com/outfit7/talkingtom/Engine.f:(Lcom/outfit7/talkingtom/Engine;)Lcom/outfit7/talkingtom/ar;
        //   238: invokeinterface com/outfit7/talkingtom/ar.e:()V
        //   243: new             Lcom/outfit7/talkingtom/v;
        //   246: astore_2       
        //   247: aload_2        
        //   248: aload_0        
        //   249: invokespecial   com/outfit7/talkingtom/v.<init>:(Lcom/outfit7/talkingtom/u;)V
        //   252: aload_2        
        //   253: iconst_4       
        //   254: putfield        com/outfit7/talkingtom/m.b:I
        //   257: aload_2        
        //   258: ldc             "listenstop"
        //   260: putfield        com/outfit7/talkingtom/m.c:Ljava/lang/String;
        //   263: aload_0        
        //   264: getfield        com/outfit7/talkingtom/u.b:Lcom/outfit7/talkingtom/Engine;
        //   267: getfield        com/outfit7/talkingtom/Engine.c:Lcom/outfit7/talkingtom/ab;
        //   270: invokevirtual   com/outfit7/talkingtom/ab.a:()Lcom/outfit7/talkingtom/aa;
        //   273: aload_0        
        //   274: getfield        com/outfit7/talkingtom/u.b:Lcom/outfit7/talkingtom/Engine;
        //   277: getfield        com/outfit7/talkingtom/Engine.c:Lcom/outfit7/talkingtom/ab;
        //   280: invokevirtual   com/outfit7/talkingtom/ab.a:()Lcom/outfit7/talkingtom/aa;
        //   283: iconst_0       
        //   284: aload_2        
        //   285: invokevirtual   com/outfit7/talkingtom/aa.obtainMessage:(ILjava/lang/Object;)Landroid/os/Message;
        //   288: invokevirtual   com/outfit7/talkingtom/aa.sendMessage:(Landroid/os/Message;)Z
        //   291: pop            
        //   292: goto            56
        //   295: astore_2       
        //   296: aload_2        
        //   297: athrow         
        //   298: astore_2       
        //   299: aload_3        
        //   300: monitorexit    
        //   301: aload_2        
        //   302: athrow         
        //   303: astore_2       
        //   304: aload_0        
        //   305: getfield        com/outfit7/talkingtom/u.g:Lcom/outfit7/talkingtom/y;
        //   308: getfield        com/outfit7/talkingtom/y.f:Ljava/util/concurrent/locks/Lock;
        //   311: invokeinterface java/util/concurrent/locks/Lock.unlock:()V
        //   316: aload_2        
        //   317: athrow         
        //   318: aload_0        
        //   319: getfield        com/outfit7/talkingtom/u.g:Lcom/outfit7/talkingtom/y;
        //   322: ifnull          56
        //   325: aload_0        
        //   326: getfield        com/outfit7/talkingtom/u.g:Lcom/outfit7/talkingtom/y;
        //   329: invokevirtual   com/outfit7/talkingtom/y.g:()V
        //   332: aload_0        
        //   333: aconst_null    
        //   334: putfield        com/outfit7/talkingtom/u.g:Lcom/outfit7/talkingtom/y;
        //   337: goto            56
        //   340: astore_2       
        //   341: goto            186
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  50     56     298    303    Any
        //  142    174    303    318    Any
        //  174    186    340    344    Ljava/lang/InterruptedException;
        //  174    186    303    318    Any
        //  243    292    295    298    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 165 out of bounds for length 165
        //     at jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at jdk.internal.util.Preconditions.checkIndex(Preconditions.java:266)
        //     at java.util.Objects.checkIndex(Objects.java:359)
        //     at java.util.ArrayList.get(ArrayList.java:434)
        //     at w5.a.o(SourceFile:31)
        //     at w5.a.j(SourceFile:218)
        //     at a6.j.j(SourceFile:23)
        //     at a6.j.i(SourceFile:28)
        //     at a6.i.n(SourceFile:7)
        //     at a6.i.m(SourceFile:174)
        //     at a6.i.c(SourceFile:67)
        //     at a6.i.r(SourceFile:328)
        //     at a6.i.s(SourceFile:17)
        //     at a6.i.q(SourceFile:29)
        //     at a6.i.b(SourceFile:33)
        //     at y5.d.e(SourceFile:6)
        //     at y5.d.b(SourceFile:1)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(SourceFile:306)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:131)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
        //     at e7.a.run(SourceFile:1)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        //     at java.lang.Thread.run(Thread.java:1012)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
