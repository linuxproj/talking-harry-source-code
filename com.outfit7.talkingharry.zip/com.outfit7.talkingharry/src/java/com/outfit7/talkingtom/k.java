package com.outfit7.talkingtom;

import android.os.Message;
import android.app.ProgressDialog;
import android.os.Handler;

final class k extends Handler
{
    private ProgressDialog a;
    
    k(final ProgressDialog a) {
        this.a = a;
    }
    
    public final void handleMessage(final Message message) {
        switch (message.what) {
            case 1: {
                this.a.setProgress((int)message.obj);
                break;
            }
            case 2: {
                this.a.setMessage((CharSequence)message.obj);
                break;
            }
            case 3: {
                this.a.dismiss();
                break;
            }
        }
    }
}
