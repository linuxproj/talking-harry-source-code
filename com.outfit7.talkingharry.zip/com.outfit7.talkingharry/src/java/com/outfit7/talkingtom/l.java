package com.outfit7.talkingtom;

import java.util.List;
import java.util.Iterator;
import java.util.LinkedList;
import android.os.Handler;

final class l extends Thread
{
    private Handler a;
    private Engine b;
    
    l(final Engine b, final Handler a) {
        this.b = b;
        this.a = a;
    }
    
    public final void run() {
        int i = 0;
        try {
            final String[] list = this.b.g.getAssets().list("sounds/" + this.b.j);
            final LinkedList list2 = new LinkedList();
            while (i < list.length) {
                final String s = list[i];
                ((List)list2).add((Object)s.substring(0, s.length() - 4));
                ++i;
            }
            final int size = ((List)list2).size();
            this.a.sendMessage(this.a.obtainMessage(2, (Object)"Loading..."));
            final Iterator iterator = ((List)list2).iterator();
            int n = 1;
            while (iterator.hasNext()) {
                this.b.d.b((String)iterator.next());
                this.a.sendMessage(this.a.obtainMessage(1, (Object)(int)Math.round(n / (double)size * 100.0)));
                ++n;
            }
            final Object k = this.b.s;
            synchronized (k) {
                this.b.w = true;
                this.b.s.notify();
                monitorexit(k);
                this.a.sendMessage(this.a.obtainMessage(3));
            }
        }
        catch (final Exception ex) {}
    }
}
