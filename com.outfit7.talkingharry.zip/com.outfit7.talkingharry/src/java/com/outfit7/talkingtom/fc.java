package com.outfit7.talkingtom;

import android.os.Handler;
import com.outfit7.a.a;

final class fc implements a
{
    private Handler a;
    
    public fc(final Handler a) {
        this.a = a;
    }
    
    @Override
    public final void a(final float n) {
        this.a.sendMessage(this.a.obtainMessage(2, (Object)Math.round(n)));
    }
    
    @Override
    public final void b(final float n) {
        this.a.sendMessage(this.a.obtainMessage(1, (Object)Math.round(n)));
    }
}
