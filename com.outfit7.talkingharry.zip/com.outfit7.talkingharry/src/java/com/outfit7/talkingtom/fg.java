package com.outfit7.talkingtom;

import android.app.Activity;
import android.view.View;
import android.view.View$OnClickListener;

final class fg implements View$OnClickListener
{
    private String a;
    private VideoUploadedToFbActivity b;
    
    fg(final VideoUploadedToFbActivity b, final String a) {
        this.b = b;
        this.a = a;
    }
    
    public final void onClick(final View view) {
        VideoUploadedToFbActivity.a(this.b, this.a);
    }
}
