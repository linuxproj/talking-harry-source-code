package com.outfit7.talkingtom;

import android.content.Context;
import android.widget.ImageView;
import android.app.Activity;
import android.widget.RelativeLayout;

final class dr extends n
{
    final RelativeLayout m;
    final int n;
    final dq o;
    private int p;
    private String q;
    private String r;
    private int s;
    
    dr(final dq o, final Engine engine, final String s, final Activity activity, final String q, final RelativeLayout m, final int n, final String r, final int s2) {
        this.o = o;
        this.q = q;
        this.m = m;
        this.n = n;
        this.r = r;
        this.s = s2;
        engine.getClass();
        super(engine, s, activity);
        this.p = 1;
    }
    
    @Override
    public final void b(int n) {
        super.b(n);
        if (this.o.a.a.n != this.o.a.a.o) {
            this.a = true;
        }
        if (n == this.s) {
            this.b = 5;
        }
        if (n != this.k.size()) {
            return;
        }
        final dl a = this.o.a;
        n = this.p--;
        dl.a(a, n);
        final dl a2 = this.o.a;
        synchronized (a2) {
            this.o.a.notify();
        }
    }
    
    @Override
    public final void f() {
        super.b = 100;
    }
    
    @Override
    public final void j() {
        super.j();
        this.g();
        this.a(0).b = this.q;
        ++this.o.a.d;
        final Engine a = this.o.a.a.c;
        a.getClass();
        final n n = new n(a, this.o.a.a);
        final ImageView imageView = new ImageView((Context)this.o.a.a);
        final double n2 = this.o.a.a.k / (double)this.m.getHeight();
        this.o.a.a.c.b.post((Runnable)new ds(this, imageView));
        n.a(imageView);
        n.a(this.r);
        if (n2 < 0.42) {
            n.b(0, 12);
        }
        else if (n2 < 0.6) {
            n.b(0, 9);
        }
        else {
            n.b(0, 5);
        }
        this.a(n);
    }
    
    @Override
    public final void k() {
        dl.a(this.o.a, this.p--);
        final dl a = this.o.a;
        synchronized (a) {
            this.o.a.notify();
            monitorexit(a);
            Main.d(this.o.a.a);
        }
    }
}
