package com.outfit7.talkingtom;

import android.content.Intent;
import android.widget.RelativeLayout$LayoutParams;
import android.os.Bundle;
import android.app.Activity;

public class GridProxy extends Activity
{
    private int a;
    
    static {
        GridProxy.class.getName();
    }
    
    public void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.a = 0;
    }
    
    protected void onResume() {
        super.onResume();
        if (this.a++ > 0) {
            this.finish();
        }
        else {
            this.setContentView(2130903042);
            final RelativeLayout$LayoutParams relativeLayout$LayoutParams = (RelativeLayout$LayoutParams)this.findViewById(2131296261).getLayoutParams();
            relativeLayout$LayoutParams.topMargin = 0;
            relativeLayout$LayoutParams.bottomMargin = 0;
            this.startActivity((Intent)this.getIntent().getExtras().get("intent"));
        }
    }
}
