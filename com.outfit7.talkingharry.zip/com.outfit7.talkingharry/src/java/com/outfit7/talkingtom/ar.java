package com.outfit7.talkingtom;

public interface ar
{
    int a(final aq p0);
    
    String a();
    
    String a(final int p0);
    
    int b();
    
    void c();
    
    void d();
    
    void e();
    
    void f();
    
    void g();
}
