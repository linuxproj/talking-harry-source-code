package com.outfit7.talkingtom;

import android.app.Activity;

final class co extends n
{
    private cm m;
    
    co(final cm m, final Engine engine, final String s, final Activity activity) {
        this.m = m;
        engine.getClass();
        super(engine, s, activity);
    }
    
    @Override
    public final void b(final int n) {
        super.b(n);
        if (n == 5) {
            this.d();
        }
    }
    
    @Override
    public final void f() {
        super.b = 4;
    }
    
    @Override
    public final void j() {
        super.j();
        ++this.m.a.g;
        this.a(0, 19);
        this.a(0).b = "swoosh_0" + this.m.a.a.c.a(1, 3);
    }
    
    @Override
    public final void k() {
        super.k();
        final cl a = this.m.a;
        synchronized (a) {
            --this.m.a.g;
            this.m.a.notify();
        }
    }
}
