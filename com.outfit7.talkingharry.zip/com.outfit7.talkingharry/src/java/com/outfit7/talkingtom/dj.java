package com.outfit7.talkingtom;

final class dj implements Runnable
{
    private int a;
    private di b;
    
    dj(final di b, final int a) {
        this.b = b;
        this.a = a;
    }
    
    public final void run() {
        this.b.a.setProgress(this.a);
    }
}
