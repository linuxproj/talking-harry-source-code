package com.outfit7.talkingtom;

import android.app.Activity;

final class cx
{
    final cv a;
    private int b;
    
    cx(final cv a) {
        this.a = a;
    }
    
    public final void a() {
        if (this.b == 0) {
            this.b();
        }
    }
    
    public final void b() {
        if (this.a.a.n == this.a.a.q) {
            final Engine a = this.a.a.c;
            a.getClass();
            final cy cy = new cy(this, a, "gozd/godrnja", this.a.a);
            cy.b = 5;
            cy.d = true;
            this.a.a.c.c.a().sendMessage(this.a.a.c.c.a().obtainMessage(0, (Object)cy));
        }
    }
}
