package com.outfit7.talkingtom;

import android.app.Activity;
import android.view.View;
import android.view.View$OnClickListener;

final class fo implements View$OnClickListener
{
    private VideoUploadedToYtActivity a;
    
    fo(final VideoUploadedToYtActivity a) {
        this.a = a;
    }
    
    public final void onClick(final View view) {
        VideoUploadedToYtActivity.a(this.a);
    }
}
