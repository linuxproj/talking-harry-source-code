package com.outfit7.talkingtom;

import android.app.Activity;

final class dy extends n
{
    private dx m;
    
    dy(final dx m, final Engine engine, final Activity activity) {
        this.m = m;
        engine.getClass();
        super(engine, activity);
    }
    
    @Override
    public final void c() {
        super.c();
        Main.d(this.m.c);
    }
    
    @Override
    public final void f() {
        super.b = 5;
    }
    
    @Override
    public final void j() {
        super.j();
        this.m.c.p.d();
        ++this.m.c.p.g;
        if (this.m.c.c.a(1, 2) == 1) {
            this.a("ninje/roka");
            this.g();
            this.m.c.c.a(1, 2);
            this.a(0).b = "punchHand";
        }
        else {
            this.a("ninje/noga");
            this.g();
            this.a(0).b = "punchFoot";
        }
    }
    
    @Override
    public final void k() {
        super.k();
        Main.d(this.m.c);
        final cl i = this.m.c.p;
        synchronized (i) {
            --this.m.c.p.g;
            this.m.c.p.notify();
        }
    }
}
