package com.outfit7.talkingtom;

import android.os.Looper;
import android.os.Handler;

final class bg extends Handler
{
    long a;
    bf b;
    
    bg(final Looper looper) {
        super(looper);
    }
}
