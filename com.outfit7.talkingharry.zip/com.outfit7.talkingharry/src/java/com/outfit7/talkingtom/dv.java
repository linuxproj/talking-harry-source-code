package com.outfit7.talkingtom;

import java.util.Iterator;
import android.view.View;
import android.widget.RelativeLayout;

final class dv implements Runnable
{
    private dt a;
    
    dv(final dt a) {
        this.a = a;
    }
    
    public final void run() {
        final RelativeLayout relativeLayout = (RelativeLayout)this.a.c.findViewById(2131296263);
        for (final View view : this.a.b) {
            if (view.getParent() != null) {
                relativeLayout.removeView(view);
            }
        }
    }
}
