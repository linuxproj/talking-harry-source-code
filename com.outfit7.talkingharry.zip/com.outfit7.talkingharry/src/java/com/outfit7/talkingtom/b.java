package com.outfit7.talkingtom;

import android.app.AlertDialog;
import android.content.DialogInterface$OnClickListener;
import android.app.AlertDialog$Builder;
import android.content.DialogInterface$OnDismissListener;
import java.util.Iterator;
import java.io.ByteArrayInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.BufferedOutputStream;
import android.graphics.Bitmap$CompressFormat;
import java.io.ByteArrayOutputStream;
import android.util.DisplayMetrics;
import android.graphics.Paint;
import android.graphics.Matrix;
import android.graphics.Canvas;
import android.graphics.Bitmap$Config;
import com.outfit7.a.e;
import java.io.FileInputStream;
import java.io.InputStream;
import android.content.Context;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Arrays;
import android.app.Activity;
import java.util.List;
import java.io.File;
import com.outfit7.jpeg2avi.Avi;
import com.outfit7.jpeg2avi.AviAudio;
import android.graphics.Bitmap;
import android.app.ProgressDialog;
import android.os.Handler;

public class b
{
    static Handler a;
    static ProgressDialog b;
    private static final String c;
    private static Bitmap f;
    private static boolean g;
    private AviAudio d;
    private Avi e;
    
    static {
        c = b.class.getName();
        com.outfit7.talkingtom.b.f = null;
    }
    
    private b(final File file, final int n) {
        file.getParentFile().mkdirs();
        this.d = new AviAudio(1, 16, n);
        this.e = new Avi(file.getAbsolutePath(), 240, 360, "MJPG", 10, this.d);
    }
    
    public static g a(final boolean b, final TalkingTomApplication talkingTomApplication, final q[] array, final ap[] array2, final Handler handler, final boolean[] array3, final int[] array4, final List[] array5, final Activity activity) {
        g g;
        if (array == null) {
            g = null;
        }
        else {
            File file;
            if (b) {
                file = talkingTomApplication.d();
            }
            else {
                file = talkingTomApplication.c();
            }
            if (file.exists()) {
                file.delete();
            }
            file.getParentFile().mkdirs();
            final int i = talkingTomApplication.i();
            final b b2 = new b(file, i);
            final int length = array.length;
            handler.sendMessage(handler.obtainMessage(14, (Object)length));
            int n;
            for (n = length - 1; array[n] == null; --n) {}
            final ArrayList list = new ArrayList((Collection)Arrays.asList((Object[])array));
            int n2;
            if (length % 10 != 0) {
                n2 = 10 - length % 10;
            }
            else {
                n2 = 0;
            }
            int n3 = n2;
            if (n2 <= 6) {
                n3 = n2 + 10;
            }
            for (int j = 0; j < n3; ++j) {
                ((List)list).add((Object)array[n]);
            }
            final q[] array6 = (q[])((List)list).toArray((Object[])new q[0]);
            final int length2 = array6.length;
            final int n4 = i / 10;
            int n5 = 0;
            ap ap = null;
            int n7;
            for (int n6 = 0; n6 < length2 && !b.g; ++n6, n5 = n7) {
                n7 = n5;
                if (n6 < array4.length) {
                    n7 = n5;
                    if (array4[n6] != 0) {
                        n7 = array4[n6];
                    }
                }
                final q q = array6[n6];
                List list2;
                if (n6 < array5.length) {
                    list2 = array5[n6];
                }
                else {
                    list2 = null;
                }
                final InputStream a = a((Context)talkingTomApplication, q, n7, list2, activity);
                final byte[] array7 = new byte[a.available()];
                a.read(array7);
                b2.e.addFrame(array7, array7.length);
                a.close();
                if (n6 >= array2.length) {
                    break;
                }
                final ap ap2 = array2[n6];
                if (ap2 != null) {
                    ap2.c();
                    final short[] b3 = ap2.b();
                    final byte[] array8 = new byte[b3.length * 2];
                    for (int k = 0; k < b3.length; ++k) {
                        array8[k * 2 + 1] = (byte)((b3[k] & 0xFF00) >> 8);
                        array8[k * 2] = (byte)(b3[k] & 0xFF);
                    }
                    b2.e.addAudio(array8, array8.length);
                    ap = ap2;
                }
                else {
                    short[] b4 = null;
                    if (array3[n6]) {
                        ap = null;
                    }
                    if (ap != null) {
                        b4 = ap.b();
                    }
                    if (b4 != null) {
                        final byte[] array9 = new byte[b4.length * 2];
                        for (int l = 0; l < b4.length; ++l) {
                            array9[l * 2 + 1] = (byte)((b4[l] & 0xFF00) >> 8);
                            array9[l * 2] = (byte)(b4[l] & 0xFF);
                        }
                        b2.e.addAudio(array9, array9.length);
                    }
                    else {
                        ap = null;
                        final byte[] array10 = new byte[n4 * 2];
                        Arrays.fill(array10, (byte)0);
                        b2.e.addAudio(array10, array10.length);
                    }
                }
                handler.sendMessage(handler.obtainMessage(1, (Object)(n6 + 1)));
            }
            b2.e.close();
            if (b.g) {
                g = null;
            }
            else {
                g = new g(file.getAbsolutePath(), Math.round(1.0f * length2 / 10.0f), file.length());
            }
        }
        return g;
    }
    
    private static InputStream a(final Context context, final q q, final int n, final List list, final Activity activity) {
        Bitmap f = null;
        if (q != null) {
            f = q.a();
        }
        if (f == null) {
            f = com.outfit7.talkingtom.b.f;
        }
        else {
            com.outfit7.talkingtom.b.f = f;
        }
        File file = null;
        Label_0105: {
            if (list != null || q == null || q.a == null) {
                file = null;
                break Label_0105;
            }
            file = new File(context.getCacheDir(), q.a.replace((CharSequence)"/", (CharSequence)"-") + ".jpg");
            if (!file.exists()) {
                break Label_0105;
            }
            final Object o = new FileInputStream(file);
            return (InputStream)o;
        }
        final Bitmap copy = e.a(context.getResources(), n).copy(Bitmap$Config.ARGB_8888, true);
        final Canvas canvas = new Canvas(copy);
        canvas.drawBitmap(f, new Matrix(), (Paint)null);
        if (list != null) {
            final DisplayMetrics displayMetrics = new DisplayMetrics();
            activity.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
            for (final q q2 : list) {
                final Bitmap a = q2.a();
                if (a != null) {
                    final double n2 = q2.b.topMargin / (double)displayMetrics.heightPixels;
                    final double n3 = q2.b.leftMargin / (double)displayMetrics.widthPixels;
                    final Matrix matrix = new Matrix();
                    matrix.preScale(1.3333334f, 1.3333334f);
                    matrix.preTranslate((float)(n3 * 180.0), (float)(n2 * 240.0));
                    canvas.drawBitmap(a, matrix, (Paint)null);
                }
            }
        }
        final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        copy.compress(Bitmap$CompressFormat.JPEG, 40, (OutputStream)new BufferedOutputStream((OutputStream)byteArrayOutputStream, 4096));
        copy.recycle();
        byteArrayOutputStream.close();
        if (file != null) {
            final FileOutputStream fileOutputStream = new FileOutputStream(file);
            fileOutputStream.write(byteArrayOutputStream.toByteArray());
            fileOutputStream.close();
        }
        final Object o = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
        return (InputStream)o;
    }
    
    static void a() {
        com.outfit7.talkingtom.b.g = true;
        if (com.outfit7.talkingtom.b.a != null) {
            com.outfit7.talkingtom.b.a.sendMessage(com.outfit7.talkingtom.b.a.obtainMessage(111));
        }
    }
    
    public static void a(final Activity activity, final DialogInterface$OnDismissListener onDismissListener) {
        final AlertDialog$Builder alertDialog$Builder = new AlertDialog$Builder((Context)activity);
        alertDialog$Builder.setTitle((CharSequence)activity.getString(2131099662));
        alertDialog$Builder.setMessage((CharSequence)activity.getString(2131099663));
        alertDialog$Builder.setPositiveButton((CharSequence)activity.getString(2131099651), (DialogInterface$OnClickListener)new com.outfit7.talkingtom.e());
        final AlertDialog create = alertDialog$Builder.create();
        if (onDismissListener != null) {
            create.setOnDismissListener(onDismissListener);
        }
        create.show();
    }
    
    public static void a(final boolean b, final Activity activity, final f f) {
        (b.b = new ProgressDialog((Context)activity)).setProgressStyle(1);
        b.b.setMessage((CharSequence)activity.getResources().getString(2131099665));
        b.b.setCancelable(false);
        b.b.show();
        b.g = false;
        b.a = new c(f);
        new d(activity, b).start();
    }
}
