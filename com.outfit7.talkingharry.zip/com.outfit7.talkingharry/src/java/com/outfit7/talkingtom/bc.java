package com.outfit7.talkingtom;

import android.app.Activity;

final class bc extends n
{
    private Engine m;
    
    bc(final Engine engine, final String s, final Activity activity, final Engine m) {
        this.m = m;
        engine.getClass();
        super(engine, s, activity);
    }
    
    @Override
    public final void j() {
        super.j();
        this.g();
        this.m.d().c((ap)null);
        this.m.d().b(this.m.d().a);
    }
}
