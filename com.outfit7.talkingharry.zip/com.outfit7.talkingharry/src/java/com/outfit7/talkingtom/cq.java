package com.outfit7.talkingtom;

final class cq implements ar
{
    private cl a;
    
    cq(final cl a) {
        this.a = a;
    }
    
    @Override
    public final int a(final aq aq) {
        return 0;
    }
    
    @Override
    public final String a() {
        this.a.d();
        return "animations/ninje/poslusa/poslusa.png";
    }
    
    @Override
    public final String a(final int n) {
        return String.format("animations/ninje/govor/govor%04d.png", new Object[] { n });
    }
    
    @Override
    public final int b() {
        return 2130837508;
    }
    
    @Override
    public final void c() {
        this.a.a.r.a(true);
    }
    
    @Override
    public final void d() {
        this.a.a.r.a(false);
    }
    
    @Override
    public final void e() {
        this.a.a.r.b(true);
    }
    
    @Override
    public final void f() {
        this.a.a.r.b(false);
    }
    
    @Override
    public final void g() {
        Main.d(this.a.a);
    }
}
