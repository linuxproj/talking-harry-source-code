package com.outfit7.talkingtom;

final class x implements Runnable
{
    private w a;
    
    x(final w a) {
        this.a = a;
    }
    
    public final void run() {
        this.a.a.lock();
        try {
            this.a.b = false;
            w.b(this.a);
        }
        finally {
            this.a.a.unlock();
        }
    }
}
