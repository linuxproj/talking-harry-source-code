package com.outfit7.talkingtom;

import android.view.View;
import android.view.View$OnClickListener;

final class bh implements View$OnClickListener
{
    private Main a;
    
    bh(final Main a) {
        this.a = a;
    }
    
    public final void onClick(final View view) {
        if (this.a.c.d().h()) {
            this.a.r.b();
            this.a.a();
        }
    }
}
