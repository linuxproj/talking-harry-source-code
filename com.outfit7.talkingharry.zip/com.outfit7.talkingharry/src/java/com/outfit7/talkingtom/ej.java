package com.outfit7.talkingtom;

import android.app.Activity;

public class ej
{
    private static final String a;
    
    static {
        a = ej.class.getName();
    }
    
    public static void a(final Activity activity) {
        b.a(false, activity, new ek(activity));
    }
}
