package com.outfit7.talkingtom;

import android.content.SharedPreferences$Editor;
import android.preference.Preference;
import android.preference.PreferenceScreen;
import android.os.Bundle;
import android.preference.PreferenceActivity;

public class Preferences extends PreferenceActivity
{
    private static final String a;
    
    static {
        a = Preferences.class.getName();
    }
    
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.addPreferencesFromResource(2131034112);
    }
    
    public boolean onPreferenceTreeClick(final PreferenceScreen preferenceScreen, final Preference preference) {
        if ("clearData".equals((Object)preference.getKey())) {
            new ei(this).start();
            final SharedPreferences$Editor edit = this.getSharedPreferences("prefs", 0).edit();
            edit.remove("youtubeUsername");
            edit.remove("youtubePassword");
            edit.commit();
        }
        return true;
    }
}
