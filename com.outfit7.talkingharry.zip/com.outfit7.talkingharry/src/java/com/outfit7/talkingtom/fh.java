package com.outfit7.talkingtom;

import android.view.View;
import android.view.View$OnClickListener;

final class fh implements View$OnClickListener
{
    private VideoUploadedToFbActivity a;
    
    fh(final VideoUploadedToFbActivity a) {
        this.a = a;
    }
    
    public final void onClick(final View view) {
        this.a.setResult(1);
        this.a.finish();
    }
}
