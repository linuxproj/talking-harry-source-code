package com.outfit7.talkingtom;

import android.view.KeyEvent;
import android.os.Handler;
import android.widget.ImageView;
import android.view.View$OnClickListener;
import android.widget.TextView;
import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;

public class News extends Activity
{
    private Bundle a;
    
    protected void onActivityResult(final int n, final int n2, final Intent intent) {
        switch (n) {
            case 1: {
                this.finish();
                break;
            }
        }
    }
    
    public void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2130903043);
        this.a = this.getIntent().getExtras();
        ((TextView)this.findViewById(2131296282)).setText((CharSequence)this.a.getString("title"));
        ((TextView)this.findViewById(2131296283)).setText((CharSequence)this.a.getString("description"));
        ((TextView)this.findViewById(2131296284)).setText((CharSequence)this.a.getString("okButtonText"));
        ((TextView)this.findViewById(2131296285)).setText((CharSequence)this.a.getString("closeButtonText"));
        final ef ef = new ef(this);
        this.findViewById(2131296284).setOnClickListener((View$OnClickListener)ef);
        this.findViewById(2131296285).setOnClickListener((View$OnClickListener)ef);
        new eh(this, new eg((ImageView)this.findViewById(2131296280))).start();
    }
    
    public boolean onKeyDown(final int n, final KeyEvent keyEvent) {
        boolean onKeyDown;
        if (n == 4 && keyEvent.getRepeatCount() == 0) {
            this.finish();
            onKeyDown = true;
        }
        else {
            onKeyDown = super.onKeyDown(n, keyEvent);
        }
        return onKeyDown;
    }
}
