package com.outfit7.talkingtom;

import com.outfit7.a.d;
import android.util.Log;
import com.outfit7.b.b;
import com.outfit7.b.a;
import android.app.Activity;

final class gc extends Thread
{
    private Activity a;
    private a b;
    private String c;
    private String d;
    private String e;
    private String f;
    private gd g;
    
    gc(final Activity a, final a b, final String c, final String d, final String e, final String f, final gd g) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
        this.g = g;
    }
    
    public final void run() {
        YouTubeLoginActivity.a.sendMessage(YouTubeLoginActivity.a.obtainMessage(2));
        try {
            YouTubeLoginActivity.a.sendMessage(YouTubeLoginActivity.a.obtainMessage(5, (Object)YouTubeLoginActivity.b(this.b.a(this.c, this.d, "Talking Harry the Hedgehog, talking harry, talking harry hedgehog, talking tom cat, talking tom, talking bird, hedgehog, talking carl, funny animation, funny cartoon, Outfit7, Outfit7TalkingHedgehog", this.e, this.f, "Talking Harry the Hedgehog, talking harry, talking harry hedgehog, talking tom cat, talking tom, talking bird, hedgehog, talking carl, funny animation, funny cartoon, Outfit7, Outfit7TalkingHedgehog", ((TalkingTomApplication)this.a.getApplicationContext()).c().getAbsolutePath(), "video/x-motion-jpeg", this.g))));
        }
        catch (final Exception ex) {
            String s = "";
            if (ex instanceof b) {
                switch (((b)ex).a()) {
                    case 1: {
                        s = this.a.getString(2131099702);
                        break;
                    }
                    case 2: {
                        s = this.a.getString(2131099703);
                        break;
                    }
                    case 3: {
                        s = this.a.getString(2131099701);
                        break;
                    }
                }
            }
            else {
                Log.e(YouTubeLoginActivity.c, ex.getLocalizedMessage(), (Throwable)ex);
                s = this.a.getString(2131099701);
                if (ex.getLocalizedMessage() != null) {
                    s = s + " " + ex.getLocalizedMessage();
                }
            }
            YouTubeLoginActivity.a.sendMessage(YouTubeLoginActivity.a.obtainMessage(3, (Object)s));
        }
        catch (final d d) {}
    }
}
