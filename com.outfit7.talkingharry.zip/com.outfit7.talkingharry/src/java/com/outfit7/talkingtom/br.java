package com.outfit7.talkingtom;

import android.app.Activity;

final class br extends n
{
    private bq m;
    
    br(final bq m, final Engine engine, final String s, final Activity activity) {
        this.m = m;
        engine.getClass();
        super(engine, s, activity);
    }
    
    @Override
    public final void f() {
        super.b = 10;
    }
    
    @Override
    public final void j() {
        super.j();
        this.g();
        this.a(0).b = "rain";
    }
    
    @Override
    public final void k() {
        super.k();
        Main.d(this.m.a);
    }
}
