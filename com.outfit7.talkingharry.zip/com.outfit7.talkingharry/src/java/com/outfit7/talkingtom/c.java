package com.outfit7.talkingtom;

import android.os.Message;
import android.os.Handler;

final class c extends Handler
{
    private f a;
    
    c(final f a) {
        this.a = a;
    }
    
    public final void handleMessage(final Message message) {
        switch (message.what) {
            case 14: {
                if (!b.g) {
                    b.b.setMax((int)message.obj);
                    break;
                }
                break;
            }
            case 15: {
                if (!b.g) {
                    b.b.dismiss();
                    this.a.a((Throwable)message.obj);
                    break;
                }
                break;
            }
            case 3: {
                if (!b.g) {
                    b.b.dismiss();
                    this.a.a((g)message.obj);
                    break;
                }
                break;
            }
            case 1: {
                if (!b.g) {
                    b.b.setProgress((int)message.obj);
                    break;
                }
                break;
            }
            case 111: {
                b.b.dismiss();
                break;
            }
        }
    }
}
