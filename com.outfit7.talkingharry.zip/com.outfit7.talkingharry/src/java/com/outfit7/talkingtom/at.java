package com.outfit7.talkingtom;

import android.widget.ImageView;

final class at
{
    q a;
    boolean b;
    int c;
    String d;
    boolean e;
    m f;
    boolean g;
    ImageView h;
    
    at(final q q, final boolean b, final String s, final int n) {
        this(q, b, s, n, true, (byte)0);
    }
    
    private at(final q a, final boolean b, final String d, final int c, final boolean e) {
        this.a = a;
        this.b = b;
        this.d = d;
        this.c = c;
        this.e = e;
        this.f = null;
    }
    
    at(final q q, final boolean b, final String s, final int n, final boolean b2, final byte b3) {
        this(q, b, s, n, b2);
    }
}
