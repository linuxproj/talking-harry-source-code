package com.outfit7.talkingtom;

import com.android.vending.licensing.LicenseCheckerCallback$ApplicationErrorCode;
import com.outfit7.soundtouch.JSoundTouch;
import android.app.Activity;
import com.android.vending.licensing.LicenseCheckerCallback;

class Misc$1MyLicenseCheckerCallback implements LicenseCheckerCallback
{
    final Activity a;
    
    Misc$1MyLicenseCheckerCallback(final Activity a) {
        this.a = a;
    }
    
    public void allow() {
        JSoundTouch.init();
    }
    
    public void applicationError(final LicenseCheckerCallback$ApplicationErrorCode licenseCheckerCallback$ApplicationErrorCode) {
        JSoundTouch.init();
    }
    
    public void dontAllow() {
        JSoundTouch.init();
    }
}
