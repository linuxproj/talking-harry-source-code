package com.outfit7.talkingtom;

import android.graphics.Bitmap;
import android.os.Message;
import android.widget.ImageView;
import android.os.Handler;

final class eg extends Handler
{
    private ImageView a;
    
    eg(final ImageView a) {
        this.a = a;
    }
    
    public final void handleMessage(final Message message) {
        try {
            this.a.setImageBitmap((Bitmap)message.obj);
        }
        catch (final Exception ex) {}
    }
}
