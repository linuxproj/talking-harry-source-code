package com.outfit7.talkingtom;

import android.app.Activity;

final class fr implements Runnable
{
    private VideoUploadedToYtActivity a;
    
    fr(final VideoUploadedToYtActivity a) {
        this.a = a;
    }
    
    public final void run() {
        en.b(this.a);
    }
}
