package com.outfit7.talkingtom;

import com.a.a.h;
import com.a.a.d;
import com.a.a.e;
import org.json.JSONException;
import com.outfit7.talkingtom.a.a;
import org.json.JSONArray;
import org.json.JSONObject;
import android.os.Bundle;
import android.content.Context;
import android.widget.Toast;
import android.app.Activity;
import com.a.a.g;

final class fs implements g
{
    private Activity a;
    
    public fs(final Activity a) {
        this.a = a;
    }
    
    private void a(final Throwable t) {
        if (t != null) {
            Toast.makeText((Context)this.a, (CharSequence)(this.a.getString(2131099669) + t.getLocalizedMessage()), 1).show();
        }
    }
    
    @Override
    public final void a() {
        this.a((Throwable)null);
    }
    
    @Override
    public final void a(final Bundle bundle) {
        try {
            final ft ft = new ft(this);
            final String stringExtra = this.a.getIntent().getStringExtra("youtubeVideoTitle");
            final String stringExtra2 = this.a.getIntent().getStringExtra("youtubeVideoDescription");
            final String stringExtra3 = this.a.getIntent().getStringExtra("youtubeVideoId");
            final Activity a = this.a;
            final e a2 = ((TalkingTomApplication)a.getApplicationContext()).a();
            final JSONObject jsonObject = new JSONObject();
            jsonObject.put("name", (Object)stringExtra);
            jsonObject.put("href", (Object)("http://www.youtube.com/watch?v=" + stringExtra3));
            jsonObject.put("caption", (Object)"www.youtube.com");
            jsonObject.put("description", (Object)stringExtra2);
            final JSONArray jsonArray = new JSONArray();
            final JSONObject jsonObject2 = new JSONObject();
            jsonObject2.put("type", (Object)"flash");
            jsonObject2.put("swfsrc", (Object)("http://www.youtube.com/v/" + stringExtra3));
            jsonObject2.put("imgsrc", (Object)("http://i.ytimg.com/vi/" + stringExtra3 + "/2.jpg"));
            jsonArray.put((Object)jsonObject2);
            jsonObject.put("media", (Object)jsonArray);
            final String string = jsonObject.toString();
            final Bundle bundle2 = new Bundle();
            bundle2.putString("attachment", string);
            a2.a((Context)a, "stream.publish", bundle2, ft);
        }
        catch (final JSONException ex) {
            com.outfit7.talkingtom.a.a.a(this.a, (Throwable)ex, "Failed to publish video on Facebook wall.");
        }
    }
    
    @Override
    public final void a(final d d) {
        this.a((Throwable)d);
    }
    
    @Override
    public final void a(final h h) {
        this.a((Throwable)h);
    }
}
