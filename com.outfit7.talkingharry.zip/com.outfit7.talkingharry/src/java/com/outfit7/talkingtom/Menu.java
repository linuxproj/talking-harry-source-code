package com.outfit7.talkingtom;

import android.content.DialogInterface$OnCancelListener;
import android.content.DialogInterface$OnClickListener;
import android.app.AlertDialog$Builder;
import android.content.Intent;
import android.os.Environment;
import android.content.Context;
import android.widget.Toast;
import android.app.AlertDialog;
import android.app.Activity;

public class Menu extends Activity
{
    private AlertDialog a;
    
    static {
        Menu.class.getName();
    }
    
    protected void onActivityResult(final int n, final int n2, final Intent intent) {
        switch (n2) {
            case 1: {
                this.finish();
                break;
            }
        }
    }
    
    protected void onPause() {
        super.onPause();
        if (this.a != null) {
            this.a.dismiss();
        }
    }
    
    protected void onResume() {
        super.onResume();
        final AlertDialog$Builder alertDialog$Builder = new AlertDialog$Builder((Context)this);
        alertDialog$Builder.setItems((CharSequence[])new String[] { this.getString(2131099656), this.getString(2131099657), this.getString(2131099658), this.getString(2131099659), this.getString(2131099660) }, (DialogInterface$OnClickListener)new eb(this));
        (this.a = alertDialog$Builder.create()).setCancelable(true);
        this.a.setOnCancelListener((DialogInterface$OnCancelListener)new ec(this));
        this.a.show();
    }
}
