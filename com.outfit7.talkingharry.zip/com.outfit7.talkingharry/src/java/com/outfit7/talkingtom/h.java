package com.outfit7.talkingtom;

import android.content.Context;
import android.content.Intent;
import android.app.Activity;
import android.os.Message;
import android.os.Handler;

final class h extends Handler
{
    private BackgroundActivity a;
    
    private h(final BackgroundActivity a, final byte b) {
        this.a = a;
    }
    
    public final void handleMessage(final Message message) {
        switch (message.what) {
            case 1: {
                this.a.setResult(1);
                this.a.finish();
                break;
            }
            case 2: {
                this.a.setResult(2);
                this.a.finish();
                break;
            }
            case 3: {
                this.a.a = true;
                en.c(this.a);
                break;
            }
            case 4: {
                this.a.a = true;
                this.a.startActivityForResult(new Intent((Context)this.a, (Class)YouTubeLoginActivity.class), 3);
                break;
            }
            case 5: {
                this.a.a = true;
                VideoCommentActivity.b(this.a, (String)message.obj);
                break;
            }
        }
    }
}
