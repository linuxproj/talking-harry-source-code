package com.outfit7.talkingtom;

import com.a.a.h;
import com.a.a.d;
import android.content.Intent;
import android.os.Bundle;
import android.content.Context;
import android.widget.Toast;
import android.app.Activity;
import com.a.a.g;

final class em implements g
{
    private Activity a;
    
    public em(final Activity a) {
        this.a = a;
    }
    
    private void a(final Throwable t) {
        if (t != null) {
            Toast.makeText((Context)this.a, (CharSequence)(this.a.getString(2131099669) + t.getLocalizedMessage()), 1).show();
        }
        ((BackgroundActivity)this.a).a().sendEmptyMessage(2);
    }
    
    @Override
    public final void a() {
        this.a((Throwable)null);
    }
    
    @Override
    public final void a(final Bundle bundle) {
        this.a.startActivityForResult(new Intent((Context)this.a, (Class)VideoCommentActivity.class), 5);
    }
    
    @Override
    public final void a(final d d) {
        this.a((Throwable)d);
    }
    
    @Override
    public final void a(final h h) {
        this.a((Throwable)h);
    }
}
