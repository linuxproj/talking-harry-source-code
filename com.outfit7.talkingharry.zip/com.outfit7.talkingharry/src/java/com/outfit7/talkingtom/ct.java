package com.outfit7.talkingtom;

final class ct extends Thread
{
    private cs a;
    
    ct(final cs a) {
        this.a = a;
    }
    
    public final void run() {
        this.a.a.m.a_();
    }
}
