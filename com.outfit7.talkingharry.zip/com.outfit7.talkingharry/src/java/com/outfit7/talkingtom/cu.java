package com.outfit7.talkingtom;

import android.graphics.ColorFilter;
import android.graphics.PorterDuff$Mode;
import android.widget.ImageView;
import android.view.MotionEvent;
import android.view.View;
import android.view.View$OnTouchListener;

final class cu implements View$OnTouchListener
{
    public final boolean onTouch(final View view, final MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            ((ImageView)view).setColorFilter(-7829368, PorterDuff$Mode.MULTIPLY);
            view.performClick();
        }
        else if (motionEvent.getAction() == 1 || motionEvent.getAction() == 3) {
            ((ImageView)view).setColorFilter((ColorFilter)null);
            return true;
        }
        return false;
    }
}
