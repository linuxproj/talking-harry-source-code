package com.outfit7.talkingtom;

public final class r
{
    private long a;
    private int b;
    
    public r() {
    }
    
    private r(final byte b) {
        this.a = System.currentTimeMillis();
    }
    
    final boolean a() {
        ++this.b;
        return this.a + this.b * 100 <= System.currentTimeMillis();
    }
    
    final void b() {
        final long n = System.currentTimeMillis() - (this.a + (this.b - 1) * 100);
        if (n >= 100L) {
            return;
        }
        try {
            Thread.sleep(100L - n);
        }
        catch (final Exception ex) {}
    }
    
    final void c() {
        final long n = System.currentTimeMillis() - this.a;
        if (n >= 100L) {
            return;
        }
        try {
            Thread.sleep(100L - n);
        }
        catch (final Exception ex) {}
    }
}
