package com.outfit7.talkingtom;

import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.view.View$OnClickListener;

final class ef implements View$OnClickListener
{
    private News a;
    
    ef(final News a) {
        this.a = a;
    }
    
    public final void onClick(final View view) {
        switch (view.getId()) {
            case 2131296284: {
                this.a.startActivityForResult(new Intent("android.intent.action.VIEW", Uri.parse(this.a.a.getString("url"))), 1);
                break;
            }
            case 2131296285: {
                this.a.finish();
                break;
            }
        }
    }
}
