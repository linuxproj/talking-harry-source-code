package com.outfit7.talkingtom;

abstract class ce extends Thread
{
    protected long a;
    protected long b;
    private Main c;
    
    private ce(final Main c, final byte b) {
        this.c = c;
    }
    
    public void a() {
        this.a = System.currentTimeMillis() + this.b;
    }
    
    public boolean b() {
        return this != this.c.l;
    }
    
    public abstract n c();
    
    public void run() {
        while (true) {
            if (System.currentTimeMillis() < this.a) {
                try {
                    Thread.sleep(500L);
                }
                catch (final Exception ex) {}
            }
            else {
                this.a = Long.MAX_VALUE;
                final n c = this.c();
                c.b = 2;
                if (this.b()) {
                    break;
                }
                this.c.c.c.a().sendMessage(this.c.c.c.a().obtainMessage(0, (Object)c));
            }
        }
    }
}
