package com.outfit7.talkingtom;

import java.util.Iterator;
import android.widget.RelativeLayout$LayoutParams;
import android.app.Activity;
import android.view.View$OnClickListener;
import android.view.View$OnTouchListener;
import android.content.Context;
import android.view.View;
import android.widget.RelativeLayout;

final class cl extends dt
{
    final Main a;
    private String d;
    private boolean e;
    private int f;
    private int g;
    
    cl(final Main a) {
        super(this.a = a);
        final RelativeLayout relativeLayout = (RelativeLayout)a.findViewById(2131296263);
        final View view = new View((Context)a);
        relativeLayout.addView(view);
        this.b.add((Object)view);
        view.setHapticFeedbackEnabled(false);
        view.setOnTouchListener((View$OnTouchListener)new bx(a));
        view.setOnClickListener((View$OnClickListener)new cm(this));
    }
    
    final void a_() {
        synchronized (this) {
            while (this.g != 0) {
                try {
                    this.wait();
                }
                catch (final InterruptedException ex) {}
            }
            monitorexit(this);
            final String a = ((dw)Main.b.get((Object)"default")).a();
            final Engine a2 = this.a.c;
            a2.getClass();
            final cp cp = new cp(this, a2, a, this.a);
            cp.b = 5;
            cp.d = true;
            this.a.c.c.a().sendMessage(this.a.c.c.a().obtainMessage(0, (Object)cp));
            this.d = "default";
            this.b();
            this.e = true;
        }
    }
    
    @Override
    final void b() {
        final View view = (View)this.b.get(0);
        final dw dw = (dw)Main.b.get((Object)this.d);
        final RelativeLayout$LayoutParams relativeLayout$LayoutParams = (RelativeLayout$LayoutParams)view.getLayoutParams();
        relativeLayout$LayoutParams.width = (int)(dw.b * this.a.f);
        relativeLayout$LayoutParams.height = (int)(dw.c * this.a.f);
        relativeLayout$LayoutParams.topMargin = (int)(dw.d * this.a.f) + this.a.g;
        relativeLayout$LayoutParams.leftMargin = (int)(dw.e * this.a.f) + this.a.h;
    }
    
    @Override
    final boolean c() {
        boolean b;
        if (!super.c()) {
            b = false;
        }
        else {
            this.f = 0;
            final RelativeLayout relativeLayout = (RelativeLayout)this.a.findViewById(2131296263);
            Main.a(this.a, 2);
            for (final View view : this.b) {
                if (view.getParent() == null) {
                    relativeLayout.addView(view);
                }
            }
            this.a.c.a(new cq(this));
            this.a.m = new dx(this.a);
            this.a.m.start();
            this.a.l = new cf(this.a);
            this.a.l.start();
            this.a.r.a();
            final Engine a = this.a.c;
            a.getClass();
            final cr cr = new cr(this, a, "ninje/default", this.a);
            cr.b = Integer.MAX_VALUE;
            cr.d = true;
            this.a.c.c.a().sendMessage(this.a.c.c.a().obtainMessage(0, (Object)cr));
            this.d = "default";
            this.b();
            this.e = false;
            b = true;
        }
        return b;
    }
    
    final void d() {
        this.d = "default";
        this.b();
    }
    
    @Override
    final boolean e() {
        boolean b;
        if (!super.e()) {
            b = false;
        }
        else {
            this.a.l = null;
            this.a.m = null;
            this.a.r.b();
            b = true;
        }
        return b;
    }
}
