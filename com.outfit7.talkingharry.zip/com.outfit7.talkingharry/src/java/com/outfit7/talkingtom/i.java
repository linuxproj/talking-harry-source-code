package com.outfit7.talkingtom;

import com.a.a.h;
import com.a.a.d;
import android.os.Bundle;
import com.a.a.g;

public abstract class i implements g
{
    @Override
    public void a() {
    }
    
    @Override
    public void a(final Bundle bundle) {
    }
    
    @Override
    public final void a(final d d) {
        d.printStackTrace();
    }
    
    @Override
    public final void a(final h h) {
        h.printStackTrace();
    }
}
