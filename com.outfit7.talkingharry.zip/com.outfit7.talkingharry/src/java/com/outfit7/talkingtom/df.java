package com.outfit7.talkingtom;

import android.view.View;
import android.view.View$OnClickListener;

final class df implements View$OnClickListener
{
    private de a;
    
    df(final de a) {
        this.a = a;
    }
    
    public final void onClick(final View view) {
        this.a.a.b(this.a.b.getString("gridData", (String)null));
    }
}
