package com.outfit7.talkingtom;

import android.os.Process;

final class v extends m
{
    private u i;
    
    v(final u i) {
        this.i = i;
        super(i.b);
    }
    
    public final void a() {
        Process.setThreadPriority(-8);
        final short[] array = new short[this.i.a.f()];
        final int a = this.i.a.a(array, 0, array.length);
        final aq aq = new aq(this.i.b, array, a);
        if (!this.i.e() && !this.a) {
            final int a2 = this.i.b.k.a(aq);
            aq.g.r.e.a(aq);
            this.i.b.t.c(aq);
            this.i.b.t.b(0);
            int n = 0;
            while (true) {
                try {
                    final r r = new r(this.i.b);
                    if (this.i.e()) {
                        break;
                    }
                    if (this.a) {
                        break;
                    }
                    this.i.b.t.b(n);
                    this.i.b.b.sendMessage(this.i.b.b.obtainMessage(4, (Object)new at(new q(this.i.b, this.i.b.k.a(u.a(this.i, n))), true, "talk", 4, false, (byte)0)));
                    r.c();
                    ++n;
                    if (n >= (a + a2) / (this.i.b.j / 10)) {
                        break;
                    }
                    continue;
                }
                finally {
                    aq.d();
                    this.i.b.b.sendMessage(this.i.b.b.obtainMessage(4, (Object)new at(new q(this.i.b, this.i.b.k.b()), true, "base", 4, false, (byte)0)));
                    this.i.b.k.g();
                }
            }
        }
    }
    
    @Override
    public final void b() {
        super.b();
        this.i.b.k.f();
        this.i.g();
    }
    
    @Override
    public final void c() {
        super.c();
        this.i.b.k.f();
        this.i.g();
    }
}
