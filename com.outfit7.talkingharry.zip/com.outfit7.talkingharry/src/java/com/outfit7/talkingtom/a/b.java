package com.outfit7.talkingtom.a;

import android.content.Context;
import android.widget.Toast;
import android.app.Activity;

final class b implements Runnable
{
    private String a;
    private Throwable b;
    private Activity c;
    
    b(final String a, final Throwable b, final Activity c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    public final void run() {
        final String a = this.a;
        if (this.b != null && this.b.getLocalizedMessage() != null) {
            new StringBuilder().append(a).append(this.b.getLocalizedMessage());
        }
        Toast.makeText((Context)this.c, (CharSequence)this.a, 1).show();
    }
}
