package com.outfit7.talkingtom.a;

import android.app.Activity;

public final class a
{
    public static void a(final Activity activity, final Throwable t, final String s) {
        activity.runOnUiThread((Runnable)new b(s, t, activity));
    }
}
