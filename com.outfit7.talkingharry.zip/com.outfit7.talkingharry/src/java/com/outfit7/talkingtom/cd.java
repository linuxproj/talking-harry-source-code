package com.outfit7.talkingtom;

import android.os.Looper;
import android.os.Handler;

final class cd extends Handler
{
    cd(final Looper looper) {
        super(looper);
    }
}
