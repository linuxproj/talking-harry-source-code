package com.outfit7.talkingtom;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.View$OnClickListener;

final class bl implements View$OnClickListener
{
    private Main a;
    
    bl(final Main a) {
        this.a = a;
    }
    
    public final void onClick(final View view) {
        this.a.startActivity(new Intent((Context)this.a, (Class)Info.class));
    }
}
