package com.outfit7.talkingtom;

import android.content.DialogInterface$OnDismissListener;
import android.util.Log;
import android.app.Activity;

final class eo extends f
{
    final Activity a;
    
    eo(final Activity a) {
        this.a = a;
    }
    
    @Override
    public final void a(final g g) {
        ((TalkingTomApplication)this.a.getApplicationContext()).a(g);
        ((BackgroundActivity)this.a).a().sendEmptyMessage(3);
    }
    
    @Override
    public final void a(final Throwable t) {
        Log.e(en.a, t.getLocalizedMessage(), t);
        b.a(this.a, (DialogInterface$OnDismissListener)new ep(this));
    }
}
