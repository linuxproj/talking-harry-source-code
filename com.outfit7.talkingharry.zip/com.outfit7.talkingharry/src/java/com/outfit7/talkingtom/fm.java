package com.outfit7.talkingtom;

import android.os.Message;
import android.app.Activity;
import android.os.Handler;

final class fm extends Handler
{
    private Activity a;
    
    public fm(final Activity a) {
        this.a = a;
    }
    
    public final void handleMessage(final Message message) {
        switch (message.what) {
            case 1: {
                VideoUploadedToFbActivity.a(this.a, this);
                break;
            }
            case 2: {
                VideoUploadedToFbActivity.b(this.a, this);
                break;
            }
            case 3: {
                en.b(this.a);
                break;
            }
            case 4: {
                VideoUploadedToFbActivity.c(this.a);
                break;
            }
        }
    }
}
