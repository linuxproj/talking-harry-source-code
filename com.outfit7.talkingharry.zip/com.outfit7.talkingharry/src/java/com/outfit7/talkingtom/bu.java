package com.outfit7.talkingtom;

final class bu implements Runnable
{
    private Main a;
    
    bu(final Main a) {
        this.a = a;
    }
    
    public final void run() {
        if (this.a.q == null) {
            this.a.q = new cv(this.a);
        }
        this.a.q.c();
        this.a.n = this.a.q;
    }
}
