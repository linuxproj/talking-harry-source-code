package com.outfit7.talkingtom;

import android.os.Message;
import com.outfit7.b.a;
import android.app.Activity;
import android.os.Handler;

final class fw extends Handler
{
    private Thread a;
    private boolean b;
    private Activity c;
    private String d;
    private String e;
    private String f;
    private String g;
    private a h;
    
    fw(final Activity c, final String d, final String e, final String f, final String g, final a h) {
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
        this.g = g;
        this.h = h;
    }
    
    public final void handleMessage(final Message p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getfield        android/os/Message.what:I
        //     4: lookupswitch {
        //                1: 313
        //                2: 114
        //                3: 153
        //                4: 285
        //                5: 338
        //                6: 502
        //                7: 257
        //               14: 89
        //              111: 610
        //          default: 88
        //        }
        //    88: return         
        //    89: invokestatic    com/outfit7/talkingtom/YouTubeLoginActivity.c:()Z
        //    92: ifne            88
        //    95: getstatic       com/outfit7/talkingtom/YouTubeLoginActivity.b:Landroid/app/ProgressDialog;
        //    98: aload_1        
        //    99: getfield        android/os/Message.obj:Ljava/lang/Object;
        //   102: checkcast       Ljava/lang/Integer;
        //   105: invokevirtual   java/lang/Integer.intValue:()I
        //   108: invokevirtual   android/app/ProgressDialog.setMax:(I)V
        //   111: goto            88
        //   114: invokestatic    com/outfit7/talkingtom/YouTubeLoginActivity.c:()Z
        //   117: ifne            88
        //   120: getstatic       com/outfit7/talkingtom/YouTubeLoginActivity.b:Landroid/app/ProgressDialog;
        //   123: aload_0        
        //   124: getfield        com/outfit7/talkingtom/fw.c:Landroid/app/Activity;
        //   127: ldc             2131099666
        //   129: invokevirtual   android/app/Activity.getString:(I)Ljava/lang/String;
        //   132: invokevirtual   android/app/ProgressDialog.setMessage:(Ljava/lang/CharSequence;)V
        //   135: getstatic       com/outfit7/talkingtom/YouTubeLoginActivity.b:Landroid/app/ProgressDialog;
        //   138: bipush          100
        //   140: invokevirtual   android/app/ProgressDialog.setMax:(I)V
        //   143: getstatic       com/outfit7/talkingtom/YouTubeLoginActivity.b:Landroid/app/ProgressDialog;
        //   146: iconst_0       
        //   147: invokevirtual   android/app/ProgressDialog.setProgress:(I)V
        //   150: goto            88
        //   153: invokestatic    com/outfit7/talkingtom/YouTubeLoginActivity.c:()Z
        //   156: ifne            88
        //   159: aload_0        
        //   160: dup            
        //   161: astore          4
        //   163: monitorenter   
        //   164: aload_0        
        //   165: getfield        com/outfit7/talkingtom/fw.b:Z
        //   168: ifne            245
        //   171: aload_0        
        //   172: iconst_1       
        //   173: putfield        com/outfit7/talkingtom/fw.b:Z
        //   176: aload_0        
        //   177: getfield        com/outfit7/talkingtom/fw.c:Landroid/app/Activity;
        //   180: aload_1        
        //   181: getfield        android/os/Message.obj:Ljava/lang/Object;
        //   184: checkcast       Ljava/lang/String;
        //   187: iconst_1       
        //   188: invokestatic    android/widget/Toast.makeText:(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;
        //   191: invokevirtual   android/widget/Toast.show:()V
        //   194: new             Landroid/content/Intent;
        //   197: astore_1       
        //   198: aload_1        
        //   199: aload_0        
        //   200: getfield        com/outfit7/talkingtom/fw.c:Landroid/app/Activity;
        //   203: ldc             Lcom/outfit7/talkingtom/YouTubeLoginActivity;.class
        //   205: invokespecial   android/content/Intent.<init>:(Landroid/content/Context;Ljava/lang/Class;)V
        //   208: aload_1        
        //   209: ldc             "youtubeVideoTitle"
        //   211: aload_0        
        //   212: getfield        com/outfit7/talkingtom/fw.d:Ljava/lang/String;
        //   215: invokevirtual   android/content/Intent.putExtra:(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
        //   218: pop            
        //   219: aload_1        
        //   220: ldc             "youtubeVideoDescription"
        //   222: aload_0        
        //   223: getfield        com/outfit7/talkingtom/fw.e:Ljava/lang/String;
        //   226: invokevirtual   android/content/Intent.putExtra:(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
        //   229: pop            
        //   230: aload_0        
        //   231: getfield        com/outfit7/talkingtom/fw.c:Landroid/app/Activity;
        //   234: aload_1        
        //   235: iconst_3       
        //   236: invokevirtual   android/app/Activity.startActivityForResult:(Landroid/content/Intent;I)V
        //   239: getstatic       com/outfit7/talkingtom/YouTubeLoginActivity.b:Landroid/app/ProgressDialog;
        //   242: invokevirtual   android/app/ProgressDialog.dismiss:()V
        //   245: aload           4
        //   247: monitorexit    
        //   248: goto            88
        //   251: astore_1       
        //   252: aload           4
        //   254: monitorexit    
        //   255: aload_1        
        //   256: athrow         
        //   257: invokestatic    com/outfit7/talkingtom/YouTubeLoginActivity.c:()Z
        //   260: ifne            88
        //   263: getstatic       com/outfit7/talkingtom/YouTubeLoginActivity.b:Landroid/app/ProgressDialog;
        //   266: aload_1        
        //   267: getfield        android/os/Message.obj:Ljava/lang/Object;
        //   270: checkcast       Ljava/lang/Float;
        //   273: invokevirtual   java/lang/Float.floatValue:()F
        //   276: invokestatic    java/lang/Math.round:(F)I
        //   279: invokevirtual   android/app/ProgressDialog.setMax:(I)V
        //   282: goto            88
        //   285: invokestatic    com/outfit7/talkingtom/YouTubeLoginActivity.c:()Z
        //   288: ifne            88
        //   291: getstatic       com/outfit7/talkingtom/YouTubeLoginActivity.b:Landroid/app/ProgressDialog;
        //   294: aload_1        
        //   295: getfield        android/os/Message.obj:Ljava/lang/Object;
        //   298: checkcast       Ljava/lang/Float;
        //   301: invokevirtual   java/lang/Float.floatValue:()F
        //   304: invokestatic    java/lang/Math.round:(F)I
        //   307: invokevirtual   android/app/ProgressDialog.setProgress:(I)V
        //   310: goto            88
        //   313: invokestatic    com/outfit7/talkingtom/YouTubeLoginActivity.c:()Z
        //   316: ifne            88
        //   319: getstatic       com/outfit7/talkingtom/YouTubeLoginActivity.b:Landroid/app/ProgressDialog;
        //   322: aload_1        
        //   323: getfield        android/os/Message.obj:Ljava/lang/Object;
        //   326: checkcast       Ljava/lang/Integer;
        //   329: invokevirtual   java/lang/Integer.intValue:()I
        //   332: invokevirtual   android/app/ProgressDialog.setProgress:(I)V
        //   335: goto            88
        //   338: invokestatic    com/outfit7/talkingtom/YouTubeLoginActivity.c:()Z
        //   341: ifne            88
        //   344: aload_0        
        //   345: dup            
        //   346: astore          4
        //   348: monitorenter   
        //   349: aload_0        
        //   350: getfield        com/outfit7/talkingtom/fw.b:Z
        //   353: ifne            490
        //   356: aload_0        
        //   357: iconst_1       
        //   358: putfield        com/outfit7/talkingtom/fw.b:Z
        //   361: aload_0        
        //   362: getfield        com/outfit7/talkingtom/fw.c:Landroid/app/Activity;
        //   365: ldc             "prefs"
        //   367: iconst_0       
        //   368: invokevirtual   android/app/Activity.getSharedPreferences:(Ljava/lang/String;I)Landroid/content/SharedPreferences;
        //   371: invokeinterface android/content/SharedPreferences.edit:()Landroid/content/SharedPreferences$Editor;
        //   376: astore_2       
        //   377: aload_2        
        //   378: ldc             "youtubeUsername"
        //   380: aload_0        
        //   381: getfield        com/outfit7/talkingtom/fw.f:Ljava/lang/String;
        //   384: invokeinterface android/content/SharedPreferences$Editor.putString:(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
        //   389: pop            
        //   390: aload_2        
        //   391: ldc             "youtubePassword"
        //   393: aload_0        
        //   394: getfield        com/outfit7/talkingtom/fw.g:Ljava/lang/String;
        //   397: invokeinterface android/content/SharedPreferences$Editor.putString:(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
        //   402: pop            
        //   403: aload_2        
        //   404: invokeinterface android/content/SharedPreferences$Editor.commit:()Z
        //   409: pop            
        //   410: aload_1        
        //   411: getfield        android/os/Message.obj:Ljava/lang/Object;
        //   414: checkcast       Ljava/lang/String;
        //   417: astore_3       
        //   418: aload_3        
        //   419: invokestatic    com/outfit7/talkingtom/YouTubeLoginActivity.a:(Ljava/lang/String;)Ljava/lang/String;
        //   422: astore_1       
        //   423: new             Landroid/content/Intent;
        //   426: astore_2       
        //   427: aload_2        
        //   428: aload_0        
        //   429: getfield        com/outfit7/talkingtom/fw.c:Landroid/app/Activity;
        //   432: ldc             Lcom/outfit7/talkingtom/VideoUploadedToYtActivity;.class
        //   434: invokespecial   android/content/Intent.<init>:(Landroid/content/Context;Ljava/lang/Class;)V
        //   437: aload_2        
        //   438: ldc             "youtubeVideoTitle"
        //   440: aload_0        
        //   441: getfield        com/outfit7/talkingtom/fw.d:Ljava/lang/String;
        //   444: invokevirtual   android/content/Intent.putExtra:(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
        //   447: pop            
        //   448: aload_2        
        //   449: ldc             "youtubeVideoDescription"
        //   451: aload_0        
        //   452: getfield        com/outfit7/talkingtom/fw.e:Ljava/lang/String;
        //   455: invokevirtual   android/content/Intent.putExtra:(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
        //   458: pop            
        //   459: aload_2        
        //   460: ldc             "youtubeVideoId"
        //   462: aload_3        
        //   463: invokevirtual   android/content/Intent.putExtra:(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
        //   466: pop            
        //   467: aload_2        
        //   468: ldc             "youtubeVideoUrl"
        //   470: aload_1        
        //   471: invokevirtual   android/content/Intent.putExtra:(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
        //   474: pop            
        //   475: aload_0        
        //   476: getfield        com/outfit7/talkingtom/fw.c:Landroid/app/Activity;
        //   479: aload_2        
        //   480: iconst_4       
        //   481: invokevirtual   android/app/Activity.startActivityForResult:(Landroid/content/Intent;I)V
        //   484: getstatic       com/outfit7/talkingtom/YouTubeLoginActivity.b:Landroid/app/ProgressDialog;
        //   487: invokevirtual   android/app/ProgressDialog.dismiss:()V
        //   490: aload           4
        //   492: monitorexit    
        //   493: goto            88
        //   496: astore_1       
        //   497: aload           4
        //   499: monitorexit    
        //   500: aload_1        
        //   501: athrow         
        //   502: invokestatic    com/outfit7/talkingtom/YouTubeLoginActivity.c:()Z
        //   505: ifne            88
        //   508: aload_0        
        //   509: dup            
        //   510: astore          4
        //   512: monitorenter   
        //   513: aload_0        
        //   514: getfield        com/outfit7/talkingtom/fw.b:Z
        //   517: ifne            590
        //   520: aload_0        
        //   521: iconst_1       
        //   522: putfield        com/outfit7/talkingtom/fw.b:Z
        //   525: aload_0        
        //   526: getfield        com/outfit7/talkingtom/fw.h:Lcom/outfit7/b/a;
        //   529: invokevirtual   com/outfit7/b/a.a:()V
        //   532: aload_0        
        //   533: getfield        com/outfit7/talkingtom/fw.a:Ljava/lang/Thread;
        //   536: invokevirtual   java/lang/Thread.stop:()V
        //   539: new             Landroid/content/Intent;
        //   542: astore_1       
        //   543: aload_1        
        //   544: aload_0        
        //   545: getfield        com/outfit7/talkingtom/fw.c:Landroid/app/Activity;
        //   548: ldc             Lcom/outfit7/talkingtom/YouTubeLoginActivity;.class
        //   550: invokespecial   android/content/Intent.<init>:(Landroid/content/Context;Ljava/lang/Class;)V
        //   553: aload_1        
        //   554: ldc             "youtubeVideoTitle"
        //   556: aload_0        
        //   557: getfield        com/outfit7/talkingtom/fw.d:Ljava/lang/String;
        //   560: invokevirtual   android/content/Intent.putExtra:(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
        //   563: pop            
        //   564: aload_1        
        //   565: ldc             "youtubeVideoDescription"
        //   567: aload_0        
        //   568: getfield        com/outfit7/talkingtom/fw.e:Ljava/lang/String;
        //   571: invokevirtual   android/content/Intent.putExtra:(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
        //   574: pop            
        //   575: aload_0        
        //   576: getfield        com/outfit7/talkingtom/fw.c:Landroid/app/Activity;
        //   579: aload_1        
        //   580: iconst_3       
        //   581: invokevirtual   android/app/Activity.startActivityForResult:(Landroid/content/Intent;I)V
        //   584: getstatic       com/outfit7/talkingtom/YouTubeLoginActivity.b:Landroid/app/ProgressDialog;
        //   587: invokevirtual   android/app/ProgressDialog.dismiss:()V
        //   590: aload           4
        //   592: monitorexit    
        //   593: goto            88
        //   596: astore_1       
        //   597: aload           4
        //   599: monitorexit    
        //   600: aload_1        
        //   601: athrow         
        //   602: astore_1       
        //   603: aload_1        
        //   604: invokevirtual   java/lang/RuntimeException.printStackTrace:()V
        //   607: goto            539
        //   610: getstatic       com/outfit7/talkingtom/YouTubeLoginActivity.b:Landroid/app/ProgressDialog;
        //   613: invokevirtual   android/app/ProgressDialog.dismiss:()V
        //   616: goto            88
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  164    245    251    257    Any
        //  245    248    251    257    Any
        //  349    490    496    502    Any
        //  490    493    496    502    Any
        //  513    525    596    602    Any
        //  525    539    602    610    Ljava/lang/RuntimeException;
        //  525    539    596    602    Any
        //  539    590    596    602    Any
        //  590    593    596    602    Any
        //  603    607    596    602    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0539:
        //     at w5.m.a(SourceFile:20)
        //     at w5.f.o(SourceFile:122)
        //     at w5.f.r(SourceFile:571)
        //     at w5.f.q(SourceFile:3)
        //     at a6.j.j(SourceFile:32)
        //     at a6.j.i(SourceFile:28)
        //     at a6.i.n(SourceFile:7)
        //     at a6.i.m(SourceFile:174)
        //     at a6.i.c(SourceFile:67)
        //     at a6.i.r(SourceFile:328)
        //     at a6.i.s(SourceFile:17)
        //     at a6.i.q(SourceFile:29)
        //     at a6.i.b(SourceFile:33)
        //     at y5.d.e(SourceFile:6)
        //     at y5.d.b(SourceFile:1)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(SourceFile:306)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:131)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
        //     at e7.a.run(SourceFile:1)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        //     at java.lang.Thread.run(Thread.java:1012)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
