package com.outfit7.talkingtom;

final class as
{
    int a;
    
    as(final int a) {
        this.a = a;
    }
}
