package com.outfit7.talkingtom;

final class dk implements Runnable
{
    private dh a;
    
    dk(final dh a) {
        this.a = a;
    }
    
    public final void run() {
        if (this.a.b != null) {
            this.a.b.setVisibility(8);
        }
        this.a.b = null;
        this.a.d = (this.a.c = false);
    }
}
