package com.outfit7.talkingtom;

import android.view.View;
import android.view.View$OnClickListener;

final class ax implements View$OnClickListener
{
    private Grid a;
    
    ax(final Grid a) {
        this.a = a;
    }
    
    public final void onClick(final View view) {
        this.a.a();
    }
}
