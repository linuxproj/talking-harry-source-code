package com.outfit7.talkingtom;

import android.content.DialogInterface;
import android.content.DialogInterface$OnClickListener;

final class ga implements DialogInterface$OnClickListener
{
    public final void onClick(final DialogInterface dialogInterface, final int n) {
        YouTubeLoginActivity.a.sendEmptyMessage(6);
    }
}
