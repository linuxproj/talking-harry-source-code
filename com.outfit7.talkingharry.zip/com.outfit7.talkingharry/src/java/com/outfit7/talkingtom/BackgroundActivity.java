package com.outfit7.talkingtom;

import android.os.Bundle;
import android.content.Intent;
import android.os.Handler;
import android.app.Activity;

public class BackgroundActivity extends Activity
{
    boolean a;
    private int b;
    private Handler c;
    
    static {
        BackgroundActivity.class.getName();
    }
    
    public final Handler a() {
        return this.c;
    }
    
    protected void onActivityResult(final int n, final int n2, final Intent intent) {
        Label_0048: {
            Label_0040: {
                switch (n) {
                    case 1: {
                        if (!en.b(this)) {
                            break Label_0048;
                        }
                        break;
                    }
                    case 2: {
                        this.setResult(1);
                        this.finish();
                        break;
                    }
                    case 3: {
                        switch (n2) {
                            default: {
                                break Label_0040;
                            }
                            case 1: {
                                this.setResult(1);
                                this.finish();
                                break Label_0040;
                            }
                            case 2: {
                                this.setResult(2);
                                this.finish();
                                break Label_0040;
                            }
                            case 3: {
                                YouTubeLoginActivity.a(this, intent.getStringExtra("youtubeUsername"), intent.getStringExtra("youtubePassword"), intent.getStringExtra("youtubeVideoTitle"), intent.getStringExtra("youtubeVideoDescription"));
                                break Label_0040;
                            }
                        }
                        break;
                    }
                    case 4: {
                        switch (n2) {
                            default: {
                                break Label_0040;
                            }
                            case 0:
                            case 1: {
                                this.setResult(1);
                                this.finish();
                                break Label_0040;
                            }
                            case 2: {
                                this.setResult(2);
                                this.finish();
                                break Label_0040;
                            }
                        }
                        break;
                    }
                    case 5: {
                        switch (n2) {
                            default: {
                                break Label_0040;
                            }
                            case 2: {
                                this.setResult(2);
                                this.finish();
                                break Label_0040;
                            }
                            case 4: {
                                VideoCommentActivity.a(this, intent.getStringExtra("facebokVideoDescription"));
                                break Label_0040;
                            }
                        }
                        break;
                    }
                    case 6: {
                        switch (n2) {
                            case 0:
                            case 1: {
                                break Label_0048;
                            }
                            default: {
                                break Label_0040;
                            }
                            case 2: {
                                this.setResult(2);
                                this.finish();
                                break Label_0040;
                            }
                        }
                        break;
                    }
                }
            }
            return;
        }
        this.setResult(1);
        this.finish();
    }
    
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.a = false;
        this.c = new h(this);
        switch (this.b = this.getIntent().getIntExtra("action", -1)) {
            case 1: {
                YouTubeLoginActivity.a(this);
                break;
            }
            case 2: {
                ej.a(this);
                break;
            }
            case 3: {
                en.a(this);
                break;
            }
        }
    }
    
    protected void onDestroy() {
        super.onDestroy();
    }
    
    protected void onRestart() {
        super.onRestart();
    }
    
    protected void onResume() {
        super.onResume();
    }
    
    protected void onStart() {
        super.onStart();
    }
    
    protected void onStop() {
        super.onStop();
        com.outfit7.talkingtom.b.a();
        YouTubeLoginActivity.a();
        VideoCommentActivity.a();
        if (!this.a) {
            this.finish();
        }
    }
}
