package com.outfit7.talkingtom;

public final class es
{
    public static final int[] a;
    
    static {
        a = new int[] { 2130771968 };
    }
}
