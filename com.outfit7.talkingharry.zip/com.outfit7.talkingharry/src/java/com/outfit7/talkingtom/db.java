package com.outfit7.talkingtom;

import android.app.Activity;

final class db extends n
{
    final cv m;
    
    db(final cv m, final Engine engine, final String s, final Activity activity) {
        this.m = m;
        engine.getClass();
        super(engine, s, activity);
    }
    
    @Override
    public final void j() {
        super.j();
        this.g();
        this.m.a.c.b.sendMessage(this.m.a.c.b.obtainMessage(5, (Object)new as(2130837504)));
        this.m.a.c.b.post((Runnable)new dc(this));
    }
    
    @Override
    public final void k() {
        super.k();
        if (this.m.a.m != null && this.m.a.m.getState() == Thread$State.NEW) {
            this.m.a.m.start();
        }
    }
}
