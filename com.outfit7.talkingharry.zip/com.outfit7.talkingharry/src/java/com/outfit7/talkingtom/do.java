package com.outfit7.talkingtom;

final class do implements Runnable
{
    final dn a;
    
    do(final dn a) {
        this.a = a;
    }
    
    public final void run() {
        this.a.m.a.r.a(this.a.m.a.findViewById(2131296266), new dp(this));
    }
}
