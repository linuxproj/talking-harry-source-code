package com.outfit7.talkingtom;

import android.graphics.drawable.Drawable;

final class ac
{
    Drawable a;
    String b;
    
    ac(final Drawable a, final String b) {
        this.a = a;
        this.b = b;
    }
}
