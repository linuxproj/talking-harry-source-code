package com.outfit7.talkingtom;

import android.content.DialogInterface$OnDismissListener;
import android.util.Log;
import android.app.Activity;

final class ek extends f
{
    private Activity a;
    
    public ek(final Activity a) {
        this.a = a;
    }
    
    @Override
    public final void a(final g g) {
        final TalkingTomApplication talkingTomApplication = (TalkingTomApplication)this.a.getApplicationContext();
        talkingTomApplication.a(g);
        talkingTomApplication.a(this.a, new em(this.a));
    }
    
    @Override
    public final void a(final Throwable t) {
        Log.e(ej.a, t.getLocalizedMessage(), t);
        b.a(this.a, (DialogInterface$OnDismissListener)new el(this));
    }
}
