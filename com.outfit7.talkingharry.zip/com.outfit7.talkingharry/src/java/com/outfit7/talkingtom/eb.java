package com.outfit7.talkingtom;

import java.io.File;
import android.content.Context;
import android.content.Intent;
import android.content.DialogInterface;
import android.content.DialogInterface$OnClickListener;

final class eb implements DialogInterface$OnClickListener
{
    private Menu a;
    
    eb(final Menu a) {
        this.a = a;
    }
    
    public final void onClick(final DialogInterface dialogInterface, final int n) {
        switch (n) {
            case 0: {
                this.a.startActivity(new Intent((Context)this.a, (Class)AnimationPlayer.class));
                break;
            }
            case 1: {
                final Intent intent = new Intent((Context)this.a, (Class)BackgroundActivity.class);
                intent.putExtra("action", 1);
                this.a.startActivityForResult(intent, 0);
                break;
            }
            case 2: {
                final Intent intent2 = new Intent((Context)this.a, (Class)BackgroundActivity.class);
                intent2.putExtra("action", 2);
                this.a.startActivityForResult(intent2, 0);
                break;
            }
            case 3: {
                if (!Menu.a()) {
                    Menu.a(this.a);
                    this.a.finish();
                    break;
                }
                final Intent intent3 = new Intent((Context)this.a, (Class)BackgroundActivity.class);
                intent3.putExtra("action", 3);
                this.a.startActivityForResult(intent3, 0);
                break;
            }
            case 4: {
                final TalkingTomApplication talkingTomApplication = (TalkingTomApplication)this.a.getApplicationContext();
                final File d = talkingTomApplication.d();
                if (d.exists()) {
                    d.delete();
                }
                final File c = talkingTomApplication.c();
                if (c.exists()) {
                    c.delete();
                }
                dialogInterface.dismiss();
                this.a.finish();
                break;
            }
        }
    }
}
