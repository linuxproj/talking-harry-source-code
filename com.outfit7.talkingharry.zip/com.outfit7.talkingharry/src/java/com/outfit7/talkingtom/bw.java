package com.outfit7.talkingtom;

final class bw implements Runnable
{
    private Main a;
    
    bw(final Main a) {
        this.a = a;
    }
    
    public final void run() {
        if (this.a.o == null) {
            this.a.o = new dl(this.a);
        }
        this.a.o.c();
        this.a.n = this.a.o;
    }
}
