package com.outfit7.talkingtom;

import java.net.URLConnection;
import android.view.View;
import android.widget.ImageView;
import android.view.MenuItem;
import android.view.View$OnClickListener;
import android.view.View$OnTouchListener;
import com.outfit7.soundtouch.SoundTouch;
import com.outfit7.soundtouch.JSoundTouch;
import android.telephony.TelephonyManager;
import android.os.Build;
import com.tapjoy.a;
import android.content.SharedPreferences$Editor;
import android.os.Bundle;
import android.content.SharedPreferences;
import org.json.JSONArray;
import android.os.Parcelable;
import android.content.Intent;
import android.graphics.Bitmap;
import android.util.Log;
import java.io.OutputStream;
import android.graphics.Bitmap$CompressFormat;
import java.io.InputStream;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import java.net.URL;
import android.content.Context;
import java.util.HashMap;
import java.util.Map;
import android.app.Activity;

public class Main extends Activity
{
    private static final String a;
    private static final Map b;
    private Engine c;
    private ed d;
    private de e;
    private double f;
    private int g;
    private int h;
    private boolean i;
    private float j;
    private float k;
    private ce l;
    private ce m;
    private dt n;
    private dl o;
    private cl p;
    private cv q;
    private dh r;
    
    static {
        a = Main.class.getName();
        b = (Map)new HashMap();
    }
    
    public Main() {
        Main.b.put((Object)"default", (Object)new dw("ninje/default", 150, 260, 10, 50));
        Main.b.put((Object)"levo", (Object)new dw("ninje/levo", 100, 280, 0, 0));
        Main.b.put((Object)"desno", (Object)new dw("ninje/desno", 80, 260, 0, 160));
        Main.b.put((Object)"visenje0", (Object)new dw("ninje/visenje0", 240, 215, 0, 0));
        Main.b.put((Object)"visenje1", (Object)new dw("ninje/visenje1", 130, 240, 0, 110));
        Main.b.put((Object)"visenje2", (Object)new dw("ninje/visenje2", 130, 250, 0, 0));
        Main.b.put((Object)"jogi", (Object)new dw("ninje/jogi", 90, 150, 50, 80));
        this.i = true;
    }
    
    static Drawable a(final Context p0, final URL p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: astore_3       
        //     2: aconst_null    
        //     3: astore_2       
        //     4: aload_1        
        //     5: invokevirtual   java/net/URL.getPath:()Ljava/lang/String;
        //     8: bipush          47
        //    10: bipush          58
        //    12: invokevirtual   java/lang/String.replace:(CC)Ljava/lang/String;
        //    15: astore_1       
        //    16: ldc             Lcom/outfit7/talkingtom/Main;.class
        //    18: dup            
        //    19: astore          4
        //    21: monitorenter   
        //    22: aload_0        
        //    23: aload_1        
        //    24: invokevirtual   android/content/Context.openFileInput:(Ljava/lang/String;)Ljava/io/FileInputStream;
        //    27: astore_1       
        //    28: aload_1        
        //    29: invokestatic    android/graphics/BitmapFactory.decodeStream:(Ljava/io/InputStream;)Landroid/graphics/Bitmap;
        //    32: astore_3       
        //    33: aload_2        
        //    34: astore_0       
        //    35: aload_3        
        //    36: ifnull          48
        //    39: new             Landroid/graphics/drawable/BitmapDrawable;
        //    42: astore_0       
        //    43: aload_0        
        //    44: aload_3        
        //    45: invokespecial   android/graphics/drawable/BitmapDrawable.<init>:(Landroid/graphics/Bitmap;)V
        //    48: aload_1        
        //    49: invokevirtual   java/io/InputStream.close:()V
        //    52: aload           4
        //    54: monitorexit    
        //    55: aload_0        
        //    56: areturn        
        //    57: astore_0       
        //    58: aload_1        
        //    59: invokevirtual   java/io/InputStream.close:()V
        //    62: aload_0        
        //    63: athrow         
        //    64: astore_1       
        //    65: aconst_null    
        //    66: astore_0       
        //    67: aload           4
        //    69: monitorexit    
        //    70: aload_1        
        //    71: athrow         
        //    72: astore_1       
        //    73: getstatic       com/outfit7/talkingtom/Main.a:Ljava/lang/String;
        //    76: aload_1        
        //    77: invokevirtual   java/lang/Exception.getMessage:()Ljava/lang/String;
        //    80: aload_1        
        //    81: invokestatic    android/util/Log.d:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
        //    84: pop            
        //    85: goto            55
        //    88: astore_0       
        //    89: aload_3        
        //    90: astore_0       
        //    91: goto            55
        //    94: astore_1       
        //    95: goto            55
        //    98: astore_1       
        //    99: aconst_null    
        //   100: astore_0       
        //   101: goto            73
        //   104: astore_1       
        //   105: goto            67
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  4      16     88     94     Ljava/lang/Exception;
        //  16     22     98     104    Ljava/lang/Exception;
        //  22     28     64     67     Any
        //  28     33     57     64     Any
        //  39     48     57     64     Any
        //  48     55     104    108    Any
        //  58     64     64     67     Any
        //  67     72     72     73     Ljava/lang/Exception;
        //  73     85     94     98     Ljava/lang/Exception;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 68 out of bounds for length 68
        //     at jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at jdk.internal.util.Preconditions.checkIndex(Preconditions.java:266)
        //     at java.util.Objects.checkIndex(Objects.java:359)
        //     at java.util.ArrayList.get(ArrayList.java:434)
        //     at w5.a.o(SourceFile:31)
        //     at w5.a.j(SourceFile:218)
        //     at a6.j.j(SourceFile:23)
        //     at a6.j.i(SourceFile:28)
        //     at a6.i.n(SourceFile:7)
        //     at a6.i.m(SourceFile:174)
        //     at a6.i.c(SourceFile:67)
        //     at a6.i.r(SourceFile:328)
        //     at a6.i.s(SourceFile:17)
        //     at a6.i.q(SourceFile:29)
        //     at a6.i.b(SourceFile:33)
        //     at y5.d.e(SourceFile:6)
        //     at y5.d.b(SourceFile:1)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(SourceFile:306)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:131)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
        //     at e7.a.run(SourceFile:1)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        //     at java.lang.Thread.run(Thread.java:1012)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private void b(final String s) {
        final Intent intent = new Intent((Context)this, (Class)Grid.class);
        intent.putExtra("gridData", s);
        final Intent intent2 = new Intent((Context)this, (Class)GridProxy.class);
        intent2.putExtra("intent", (Parcelable)intent);
        this.startActivity(intent2);
        this.finish();
    }
    
    private boolean c(String replace) {
        while (true) {
            try {
                final JSONArray jsonArray = new JSONArray(replace);
                int i = 0;
                while (i < jsonArray.length()) {
                    replace = new URL(jsonArray.getJSONObject(i).getString("iconUrl")).getPath().replace('/', ':');
                    boolean b;
                    try {
                        this.openFileInput(replace);
                        ++i;
                        continue;
                    }
                    catch (final Exception ex) {
                        b = false;
                    }
                    return b;
                }
                return true;
            }
            catch (final Exception ex2) {
                return false;
            }
            return true;
        }
    }
    
    private void e() {
        if (!this.i) {
            this.runOnUiThread((Runnable)new bu(this));
        }
    }
    
    private boolean f() {
        final SharedPreferences sharedPreferences = this.getSharedPreferences("prefs", 0);
        return !sharedPreferences.getBoolean("shown", false) && sharedPreferences.getLong("timestamp", 0L) > 0L;
    }
    
    final Drawable a(final URL url) {
        return a((Context)this, url);
    }
    
    public final void a() {
        this.startActivity(new Intent((Context)this, (Class)Menu.class));
    }
    
    final void b() {
        final SharedPreferences sharedPreferences = this.getSharedPreferences("prefs", 0);
        final bk bk = new bk(sharedPreferences);
        final Bundle extras = this.getIntent().getExtras();
        Boolean b2;
        final Boolean b = b2 = (boolean)(1 != 0);
        if (extras != null) {
            final long long1 = sharedPreferences.getLong("disableGridMillis", 0L);
            final Long n = (Long)extras.get("disableGrid");
            b2 = b;
            if (n != null) {
                b2 = b;
                if (n != long1) {
                    b2 = true;
                    final SharedPreferences$Editor edit = sharedPreferences.edit();
                    edit.putLong("disableGridMillis", (long)n);
                    edit.commit();
                }
            }
        }
        Boolean value;
        if ((value = b2) == null) {
            value = false;
        }
        final boolean c = this.c(bk.a);
        Boolean value2 = value;
        if (!value) {
            value2 = (!c || bk.a == null);
        }
        new bj(this, bk.a).start();
        if (bk.a != null && !value2 && !this.f()) {
            this.b(bk.a);
        }
    }
    
    public void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        com.tapjoy.a.a(this.getApplicationContext());
        this.setContentView(2130903042);
        System.out.println("BOARD : " + Build.BOARD);
        System.out.println("BRAND : " + Build.BRAND);
        System.out.println("DEVICE : " + Build.DEVICE);
        System.out.println("DISPLAY : " + Build.DISPLAY);
        System.out.println("FINGERPRINT : " + Build.FINGERPRINT);
        System.out.println("HOST : " + Build.HOST);
        System.out.println("ID : " + Build.ID);
        System.out.println("MODEL : " + Build.MODEL);
        System.out.println("PRODUCT : " + Build.PRODUCT);
        System.out.println("TAGS : " + Build.TAGS);
        System.out.println("TIME : " + Build.TIME);
        System.out.println("TYPE : " + Build.TYPE);
        System.out.println("USER : " + Build.USER);
        final TelephonyManager telephonyManager = (TelephonyManager)this.getSystemService("phone");
        if (telephonyManager.getDeviceId() != null) {
            System.out.println("device id: " + telephonyManager.getDeviceId());
        }
        this.setVolumeControlStream(3);
        JSoundTouch.init();
        while (true) {
            try {
                SoundTouch.setup(this.getPackageManager().getApplicationInfo(this.getPackageName(), 0));
                (this.d = new ed()).a(this);
                this.findViewById(2131296269).setOnTouchListener((View$OnTouchListener)new cu());
                this.findViewById(2131296269).setOnClickListener((View$OnClickListener)new bh(this));
                this.findViewById(2131296272).setOnTouchListener((View$OnTouchListener)new cu());
                this.findViewById(2131296272).setOnClickListener((View$OnClickListener)new bl(this));
                this.findViewById(2131296275).setOnTouchListener((View$OnTouchListener)new cu());
                this.findViewById(2131296275).setOnClickListener((View$OnClickListener)new bm(this));
                this.findViewById(2131296278).setOnTouchListener((View$OnTouchListener)new cu());
                this.findViewById(2131296278).setOnClickListener((View$OnClickListener)new bo(this));
                this.findViewById(2131296276).setOnTouchListener((View$OnTouchListener)new cu());
                this.findViewById(2131296276).setOnClickListener((View$OnClickListener)new bq(this));
                this.findViewById(2131296277).setOnTouchListener((View$OnTouchListener)new cu());
                this.findViewById(2131296277).setOnClickListener((View$OnClickListener)new bs(this));
                this.findViewById(2131296264).setKeepScreenOn(true);
                this.c = Engine.a(this);
                this.c.a = this;
                this.c.a((Activity)this);
                this.c.g();
                this.r = new dh(this);
                this.e = new de(this);
            }
            catch (final Exception ex) {
                Log.d(Main.a, ex.getMessage(), (Throwable)ex);
                continue;
            }
            break;
        }
    }
    
    public boolean onCreateOptionsMenu(final android.view.Menu menu) {
        this.getMenuInflater().inflate(2131230720, menu);
        return true;
    }
    
    protected void onDestroy() {
        super.onDestroy();
        com.tapjoy.a.a(this.getApplicationContext()).finalize();
        if (this.d != null) {
            this.d.a();
        }
    }
    
    public boolean onOptionsItemSelected(final MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case 2131296309: {
                this.startActivity(new Intent((Context)this, (Class)Preferences.class));
                break;
            }
        }
        return super.onOptionsItemSelected(menuItem);
    }
    
    protected void onPause() {
        super.onPause();
        if (!this.i) {
            this.i = true;
            if (this.n != null) {
                this.n.e();
            }
            this.c.f();
            this.findViewById(2131296268).setVisibility(8);
            this.findViewById(2131296271).setVisibility(8);
            this.findViewById(2131296274).setVisibility(8);
        }
    }
    
    protected void onRestart() {
        super.onRestart();
    }
    
    protected void onResume() {
        super.onResume();
        if (this.i) {
            this.i = false;
            this.c.e();
            this.findViewById(2131296268).setVisibility(0);
            final ImageView imageView = (ImageView)this.findViewById(2131296273);
            if (imageView.getDrawable() != null) {
                imageView.setVisibility(0);
            }
            this.e();
            if (this.getSharedPreferences("com.outfit7.talkingharry_preferences", 0).getBoolean("listenLong", false)) {
                this.c.a(30);
                this.c.a(0.8);
            }
            else {
                this.c.a(5);
                this.c.a(0.1);
            }
            this.e.a();
            final SharedPreferences sharedPreferences = this.getSharedPreferences("prefs", 0);
            if (this.f()) {
                final Intent intent = new Intent((Context)this, (Class)News.class);
                intent.putExtra("title", sharedPreferences.getString("title", ""));
                intent.putExtra("description", sharedPreferences.getString("description", ""));
                intent.putExtra("okButtonText", sharedPreferences.getString("okButtonText", ""));
                intent.putExtra("closeButtonText", sharedPreferences.getString("closeButtonText", ""));
                intent.putExtra("url", sharedPreferences.getString("url", ""));
                intent.putExtra("imageUrl", sharedPreferences.getString("imageUrl", ""));
                final SharedPreferences$Editor edit = sharedPreferences.edit();
                edit.putBoolean("shown", true);
                edit.commit();
                this.startActivity(intent);
            }
            new bi(this).start();
        }
    }
    
    protected void onStart() {
        super.onStart();
    }
    
    protected void onStop() {
        super.onStop();
        try {
            final SharedPreferences$Editor edit = ((Context)this).getSharedPreferences("facebook-session", 0).edit();
            edit.clear();
            edit.commit();
        }
        catch (final Throwable t) {
            t.printStackTrace();
            Log.w(Main.a, t.getLocalizedMessage(), t);
        }
    }
    
    public void onWindowFocusChanged(final boolean b) {
        if (b) {
            if (this.f <= 0.0) {
                final View viewById = this.findViewById(2131296263);
                if (viewById.getWidth() / (double)viewById.getHeight() < 0.6666666666666666) {
                    this.f = viewById.getHeight() / 360.0;
                    this.h = (viewById.getWidth() - (int)(this.f * 240.0)) / 2;
                }
                else {
                    this.f = viewById.getWidth() / 240.0;
                    this.g = (viewById.getHeight() - (int)(this.f * 360.0)) / 2;
                }
            }
            this.n.b();
        }
    }
}
