package com.outfit7.talkingtom;

import android.content.DialogInterface;
import android.content.DialogInterface$OnCancelListener;

final class ec implements DialogInterface$OnCancelListener
{
    private Menu a;
    
    ec(final Menu a) {
        this.a = a;
    }
    
    public final void onCancel(final DialogInterface dialogInterface) {
        dialogInterface.dismiss();
        this.a.finish();
    }
}
