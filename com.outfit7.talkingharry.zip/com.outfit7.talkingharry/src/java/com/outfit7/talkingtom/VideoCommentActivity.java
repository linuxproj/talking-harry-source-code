package com.outfit7.talkingtom;

import android.content.Intent;
import android.widget.TextView;
import android.view.View;
import com.a.a.c;
import com.a.a.a;
import android.os.Bundle;
import android.content.DialogInterface$OnCancelListener;
import android.content.DialogInterface$OnClickListener;
import android.os.Handler;
import android.content.Context;
import com.a.a.g;
import android.app.ProgressDialog;
import android.view.View$OnClickListener;
import android.app.Activity;

public class VideoCommentActivity extends Activity implements View$OnClickListener
{
    private static final String a;
    private static ProgressDialog b;
    private static boolean c;
    
    static {
        a = VideoCommentActivity.class.getName();
    }
    
    static void a() {
        VideoCommentActivity.c = true;
    }
    
    public static void a(final Activity activity, final String s) {
        ((TalkingTomApplication)activity.getApplicationContext()).a(activity, new ev(activity, s));
    }
    
    public static void b(final Activity activity, final String s) {
        final TalkingTomApplication talkingTomApplication = (TalkingTomApplication)activity.getApplicationContext();
        final aw aw = new aw(talkingTomApplication.a(), "b3c6850e9db4c44a80f6a9e848297dae", "c79cd8d2ce9964e4b98ef93eb2d1b4e9");
        VideoCommentActivity.c = false;
        VideoCommentActivity.b = new ProgressDialog((Context)activity);
        final ey ey = new ey(activity, aw);
        VideoCommentActivity.b.setCancelable(true);
        VideoCommentActivity.b.setProgressStyle(1);
        VideoCommentActivity.b.setMessage((CharSequence)activity.getString(2131099666));
        VideoCommentActivity.b.setButton(-2, (CharSequence)activity.getString(2131099682), (DialogInterface$OnClickListener)new ez(ey));
        VideoCommentActivity.b.setOnCancelListener((DialogInterface$OnCancelListener)new fa(ey));
        while (true) {
            try {
                VideoCommentActivity.b.show();
                new fb(talkingTomApplication, activity, aw, s, ey).start();
            }
            catch (final Exception ex) {
                continue;
            }
            break;
        }
    }
    
    public void onBackPressed() {
        this.setResult(2);
        this.finish();
    }
    
    public void onClick(final View view) {
        switch (view.getId()) {
            case 2131296300: {
                final String string = ((TextView)this.findViewById(2131296298)).getText().toString();
                final Intent intent = new Intent();
                intent.putExtra("facebokVideoDescription", string);
                this.setResult(4, intent);
                this.finish();
                break;
            }
            case 2131296301: {
                this.setResult(2);
                this.finish();
                break;
            }
        }
    }
    
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2130903047);
        this.findViewById(2131296300).setOnClickListener((View$OnClickListener)this);
        this.findViewById(2131296301).setOnClickListener((View$OnClickListener)this);
    }
}
