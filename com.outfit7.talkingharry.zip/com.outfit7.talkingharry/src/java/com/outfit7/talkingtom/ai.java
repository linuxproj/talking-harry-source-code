package com.outfit7.talkingtom;

import android.widget.ImageView;

final class ai implements Runnable
{
    private int a;
    private ah b;
    
    ai(final ah b, final int a) {
        this.b = b;
        this.a = a;
    }
    
    public final void run() {
        ((ImageView)this.b.i.findViewById(2131296262)).setImageResource(this.b.j.r[this.a]);
    }
}
