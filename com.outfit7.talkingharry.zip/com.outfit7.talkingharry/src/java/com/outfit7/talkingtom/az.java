package com.outfit7.talkingtom;

import android.content.Intent;
import android.net.Uri;
import android.view.View;
import org.json.JSONObject;
import android.view.View$OnClickListener;

final class az implements View$OnClickListener
{
    private JSONObject a;
    private Grid b;
    
    az(final Grid b, final JSONObject a) {
        this.b = b;
        this.a = a;
    }
    
    public final void onClick(final View view) {
        try {
            this.b.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(this.a.getString("storeUrl"))));
            this.b.finish();
        }
        catch (final Exception ex) {}
    }
}
