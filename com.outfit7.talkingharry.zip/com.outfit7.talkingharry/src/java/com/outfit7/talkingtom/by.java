package com.outfit7.talkingtom;

import android.view.MotionEvent;
import android.view.View;

final class by implements Runnable
{
    final View a;
    final bx b;
    private long c;
    private MotionEvent d;
    
    by(final bx b, final MotionEvent d, final View a) {
        this.b = b;
        this.d = d;
        this.a = a;
        this.c = this.b.j;
    }
    
    public final void run() {
        this.b.g.lock();
        try {
            if (this.b.f != 0L) {
                this.b.f = 0L;
                if (this.d.getEventTime() - this.d.getDownTime() < 200L) {
                    this.b.a.runOnUiThread((Runnable)new bz(this));
                }
            }
        }
        finally {
            this.b.g.unlock();
        }
    }
}
