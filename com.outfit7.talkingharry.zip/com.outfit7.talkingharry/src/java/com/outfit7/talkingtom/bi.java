package com.outfit7.talkingtom;

final class bi extends Thread
{
    private Main a;
    
    bi(final Main a) {
        this.a = a;
    }
    
    public final void run() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getfield        com/outfit7/talkingtom/bi.a:Lcom/outfit7/talkingtom/Main;
        //     4: ldc             "phone"
        //     6: invokevirtual   com/outfit7/talkingtom/Main.getSystemService:(Ljava/lang/String;)Ljava/lang/Object;
        //     9: checkcast       Landroid/telephony/TelephonyManager;
        //    12: astore_1       
        //    13: aload_1        
        //    14: invokevirtual   android/telephony/TelephonyManager.getDeviceId:()Ljava/lang/String;
        //    17: ifnull          272
        //    20: aload_1        
        //    21: invokevirtual   android/telephony/TelephonyManager.getDeviceId:()Ljava/lang/String;
        //    24: astore_1       
        //    25: aload_0        
        //    26: getfield        com/outfit7/talkingtom/bi.a:Lcom/outfit7/talkingtom/Main;
        //    29: ldc             "prefs"
        //    31: iconst_0       
        //    32: invokevirtual   com/outfit7/talkingtom/Main.getSharedPreferences:(Ljava/lang/String;I)Landroid/content/SharedPreferences;
        //    35: astore_2       
        //    36: aload_2        
        //    37: ldc             "lastCheckOfNews"
        //    39: lconst_0       
        //    40: invokeinterface android/content/SharedPreferences.getLong:(Ljava/lang/String;J)J
        //    45: ldc2_w          259200000
        //    48: ladd           
        //    49: invokestatic    java/lang/System.currentTimeMillis:()J
        //    52: lcmp           
        //    53: ifge            248
        //    56: aload_0        
        //    57: getfield        com/outfit7/talkingtom/bi.a:Lcom/outfit7/talkingtom/Main;
        //    60: invokevirtual   com/outfit7/talkingtom/Main.getApplicationContext:()Landroid/content/Context;
        //    63: checkcast       Lcom/outfit7/talkingtom/TalkingTomApplication;
        //    66: astore_3       
        //    67: aload_3        
        //    68: invokevirtual   com/outfit7/talkingtom/TalkingTomApplication.h:()Ljava/lang/String;
        //    71: astore          4
        //    73: aload_3        
        //    74: aload_1        
        //    75: invokevirtual   com/outfit7/talkingtom/TalkingTomApplication.a:(Ljava/lang/String;)Ljava/lang/String;
        //    78: aload           4
        //    80: invokestatic    com/outfit7/talkingtom/aw.a:(Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;
        //    83: astore_1       
        //    84: aload_1        
        //    85: ifnull          248
        //    88: aload_2        
        //    89: ldc             "timestamp"
        //    91: lconst_0       
        //    92: invokeinterface android/content/SharedPreferences.getLong:(Ljava/lang/String;J)J
        //    97: aload_1        
        //    98: ldc             "timestamp"
        //   100: invokevirtual   org/json/JSONObject.getLong:(Ljava/lang/String;)J
        //   103: lcmp           
        //   104: ifge            248
        //   107: aload_2        
        //   108: invokeinterface android/content/SharedPreferences.edit:()Landroid/content/SharedPreferences$Editor;
        //   113: astore_2       
        //   114: aload_2        
        //   115: ldc             "title"
        //   117: aload_1        
        //   118: ldc             "title"
        //   120: invokevirtual   org/json/JSONObject.getString:(Ljava/lang/String;)Ljava/lang/String;
        //   123: invokeinterface android/content/SharedPreferences$Editor.putString:(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
        //   128: pop            
        //   129: aload_2        
        //   130: ldc             "description"
        //   132: aload_1        
        //   133: ldc             "description"
        //   135: invokevirtual   org/json/JSONObject.getString:(Ljava/lang/String;)Ljava/lang/String;
        //   138: invokeinterface android/content/SharedPreferences$Editor.putString:(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
        //   143: pop            
        //   144: aload_2        
        //   145: ldc             "okButtonText"
        //   147: aload_1        
        //   148: ldc             "okButtonText"
        //   150: invokevirtual   org/json/JSONObject.getString:(Ljava/lang/String;)Ljava/lang/String;
        //   153: invokeinterface android/content/SharedPreferences$Editor.putString:(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
        //   158: pop            
        //   159: aload_2        
        //   160: ldc             "closeButtonText"
        //   162: aload_1        
        //   163: ldc             "closeButtonText"
        //   165: invokevirtual   org/json/JSONObject.getString:(Ljava/lang/String;)Ljava/lang/String;
        //   168: invokeinterface android/content/SharedPreferences$Editor.putString:(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
        //   173: pop            
        //   174: aload_2        
        //   175: ldc             "url"
        //   177: aload_1        
        //   178: ldc             "url"
        //   180: invokevirtual   org/json/JSONObject.getString:(Ljava/lang/String;)Ljava/lang/String;
        //   183: invokeinterface android/content/SharedPreferences$Editor.putString:(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
        //   188: pop            
        //   189: aload_2        
        //   190: ldc             "imageUrl"
        //   192: aload_1        
        //   193: ldc             "imageUrl"
        //   195: invokevirtual   org/json/JSONObject.getString:(Ljava/lang/String;)Ljava/lang/String;
        //   198: invokeinterface android/content/SharedPreferences$Editor.putString:(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
        //   203: pop            
        //   204: aload_2        
        //   205: ldc             "timestamp"
        //   207: aload_1        
        //   208: ldc             "timestamp"
        //   210: invokevirtual   org/json/JSONObject.getLong:(Ljava/lang/String;)J
        //   213: invokeinterface android/content/SharedPreferences$Editor.putLong:(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;
        //   218: pop            
        //   219: aload_2        
        //   220: ldc             "shown"
        //   222: iconst_0       
        //   223: invokeinterface android/content/SharedPreferences$Editor.putBoolean:(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;
        //   228: pop            
        //   229: aload_2        
        //   230: ldc             "lastCheckOfNews"
        //   232: invokestatic    java/lang/System.currentTimeMillis:()J
        //   235: invokeinterface android/content/SharedPreferences$Editor.putLong:(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;
        //   240: pop            
        //   241: aload_2        
        //   242: invokeinterface android/content/SharedPreferences$Editor.commit:()Z
        //   247: pop            
        //   248: return         
        //   249: astore_1       
        //   250: ldc             ""
        //   252: astore_1       
        //   253: goto            25
        //   256: astore_1       
        //   257: invokestatic    com/outfit7/talkingtom/Main.d:()Ljava/lang/String;
        //   260: aload_1        
        //   261: invokevirtual   java/lang/Exception.getLocalizedMessage:()Ljava/lang/String;
        //   264: aload_1        
        //   265: invokestatic    android/util/Log.e:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
        //   268: pop            
        //   269: goto            248
        //   272: ldc             ""
        //   274: astore_1       
        //   275: goto            25
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  0      25     249    256    Ljava/lang/RuntimeException;
        //  56     84     256    272    Ljava/lang/Exception;
        //  88     248    256    272    Ljava/lang/Exception;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0248:
        //     at w5.m.a(SourceFile:20)
        //     at w5.f.o(SourceFile:122)
        //     at w5.f.r(SourceFile:571)
        //     at w5.f.q(SourceFile:3)
        //     at a6.j.j(SourceFile:32)
        //     at a6.j.i(SourceFile:28)
        //     at a6.i.n(SourceFile:7)
        //     at a6.i.m(SourceFile:174)
        //     at a6.i.c(SourceFile:67)
        //     at a6.i.r(SourceFile:328)
        //     at a6.i.s(SourceFile:17)
        //     at a6.i.q(SourceFile:29)
        //     at a6.i.b(SourceFile:33)
        //     at y5.d.e(SourceFile:6)
        //     at y5.d.b(SourceFile:1)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(SourceFile:306)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:131)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
        //     at e7.a.run(SourceFile:1)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        //     at java.lang.Thread.run(Thread.java:1012)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
