package com.outfit7.talkingtom;

import com.a.a.h;
import com.a.a.d;
import android.os.Bundle;
import com.outfit7.talkingtom.a.a;
import android.util.Log;
import android.app.Activity;
import com.a.a.g;

final class ev implements g
{
    final Activity a;
    final String b;
    
    ev(final Activity a, final String b) {
        this.a = a;
        this.b = b;
    }
    
    private void a(final Throwable t) {
        final String string = this.a.getString(2131099679) + t.getLocalizedMessage();
        Log.e(VideoCommentActivity.a, t.getLocalizedMessage(), t);
        com.outfit7.talkingtom.a.a.a(this.a, t, string);
        ((BackgroundActivity)this.a).a().sendEmptyMessage(2);
    }
    
    @Override
    public final void a() {
        ((BackgroundActivity)this.a).a().sendEmptyMessage(2);
    }
    
    @Override
    public final void a(final Bundle bundle) {
        this.a.runOnUiThread((Runnable)new ew(this));
    }
    
    @Override
    public final void a(final d d) {
        this.a((Throwable)d);
    }
    
    @Override
    public final void a(final h h) {
        this.a((Throwable)h);
    }
}
