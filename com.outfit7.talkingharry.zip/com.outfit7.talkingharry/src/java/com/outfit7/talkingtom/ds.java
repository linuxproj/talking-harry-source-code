package com.outfit7.talkingtom;

import android.widget.RelativeLayout$LayoutParams;
import android.widget.ImageView$ScaleType;
import android.view.View;
import android.widget.ImageView;

final class ds implements Runnable
{
    private ImageView a;
    private dr b;
    
    ds(final dr b, final ImageView a) {
        this.b = b;
        this.a = a;
    }
    
    public final void run() {
        this.b.m.addView((View)this.a);
        this.a.setScaleType(ImageView$ScaleType.FIT_XY);
        final RelativeLayout$LayoutParams relativeLayout$LayoutParams = (RelativeLayout$LayoutParams)this.a.getLayoutParams();
        relativeLayout$LayoutParams.height = (int)(600.0 * this.b.o.a.a.f);
        relativeLayout$LayoutParams.width = (int)(this.b.n * this.b.o.a.a.f);
        relativeLayout$LayoutParams.topMargin = (int)this.b.o.a.a.k - (int)(80.0 * this.b.o.a.a.f);
        relativeLayout$LayoutParams.bottomMargin = -(int)this.b.o.a.a.k;
        relativeLayout$LayoutParams.leftMargin = (int)this.b.o.a.a.j - (int)(this.b.n / 2.0 * this.b.o.a.a.f);
        if (relativeLayout$LayoutParams.leftMargin < 0) {
            relativeLayout$LayoutParams.leftMargin = 0;
        }
        relativeLayout$LayoutParams.rightMargin = -relativeLayout$LayoutParams.leftMargin;
    }
}
