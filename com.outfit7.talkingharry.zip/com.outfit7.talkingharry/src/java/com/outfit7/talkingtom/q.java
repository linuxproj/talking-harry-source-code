package com.outfit7.talkingtom;

import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory$Options;
import java.io.InputStream;
import android.util.Log;
import com.outfit7.a.e;
import android.graphics.Bitmap;
import android.widget.RelativeLayout$LayoutParams;

public final class q
{
    String a;
    RelativeLayout$LayoutParams b;
    boolean c;
    private int d;
    private Engine e;
    
    public q() {
    }
    
    q(final Engine e) {
        this.e = e;
    }
    
    q(final Engine e, final int d) {
        this.e = e;
        this.d = d;
    }
    
    q(final Engine e, final String a) {
        this.e = e;
        this.a = a;
    }
    
    private Bitmap b() {
        try {
            return com.outfit7.a.e.a(this.e.a.getResources(), this.d);
        }
        catch (final Throwable t) {
            Log.e(Engine.e, t.getMessage(), t);
            return null;
        }
    }
    
    private byte[] c() {
        try {
            final InputStream open = this.e.h.open(this.a);
            final byte[] array = new byte[open.available()];
            open.read(array);
            open.close();
            return array;
        }
        catch (final Exception ex) {
            Log.e(Engine.e, ex.getMessage(), (Throwable)ex);
            return null;
        }
    }
    
    final Bitmap a() {
        Bitmap bitmap;
        if (this.a != null) {
            final byte[] c = this.c();
            bitmap = BitmapFactory.decodeByteArray(c, 0, c.length, new BitmapFactory$Options());
        }
        else {
            bitmap = this.b();
        }
        return bitmap;
    }
}
