package com.outfit7.talkingtom;

import android.view.View;
import android.view.View$OnClickListener;

final class a implements View$OnClickListener
{
    private AnimationPlayer a;
    
    a(final AnimationPlayer a) {
        this.a = a;
    }
    
    public final void onClick(final View view) {
        Engine.a().d().b(this.a);
    }
}
