package com.outfit7.talkingtom;

import java.util.Arrays;
import android.os.HandlerThread;
import java.util.concurrent.locks.ReentrantLock;
import android.os.Handler;
import java.util.concurrent.locks.Condition;
import android.media.AudioRecord;
import java.util.concurrent.locks.Lock;

public final class w
{
    Lock a;
    private boolean b;
    private AudioRecord c;
    private int d;
    private int e;
    private int f;
    private Condition g;
    private Handler h;
    private final int i;
    private u j;
    
    public w() {
    }
    
    w(final u j) {
        this.j = j;
        this.b = false;
        this.a = (Lock)new ReentrantLock();
        this.g = this.a.newCondition();
        this.a.newCondition();
        final HandlerThread handlerThread = new HandlerThread("ARConsumerHandlerThread");
        handlerThread.start();
        this.h = new Handler(handlerThread.getLooper());
        this.i = this.j.b.j / 10;
        this.e = AudioRecord.getMinBufferSize(j.b.j, 2, 2);
        if (this.e > j.b.j * 10 * 2 / 10) {
            this.d = this.e;
        }
        else {
            this.d = (j.b.j * 10 * 2 / 10 / this.e + 1) * this.e;
        }
    }
    
    final void a() {
        this.a.lock();
        try {
            this.b = false;
            this.a.unlock();
            this.h.post((Runnable)new x(this));
        }
        finally {
            this.a.unlock();
        }
    }
    
    final void b() {
        this.a.lock();
        try {
            if (!this.b) {
                this.b = true;
                ++this.f;
                try {
                    (this.c = new AudioRecord(1, this.j.b.g.i(), 2, 2, this.d)).startRecording();
                    this.j.a.b();
                    this.g.signal();
                    this.a.unlock();
                }
                catch (final IllegalStateException ex) {
                    this.c.release();
                    throw new IllegalStateException("Uninitialised AudioRecord, nRecordsAcquired = " + this.f + ", sRate = " + this.j.b.j + ", arBufferSize = " + this.d + ", arMinBufferSize = " + this.e, (Throwable)ex);
                }
            }
        }
        finally {
            this.a.unlock();
        }
    }
    
    final short[] c() {
        this.a.lock();
        Label_0042: {
            try {
                while (!this.b) {
                    this.g.await();
                }
                break Label_0042;
            }
            catch (final InterruptedException ex) {
                this.a.unlock();
                return null;
                array = new short[this.i];
                final int read = this.c.read(array, 0, array.length);
                iftrue(Label_0075:)(read >= array.length);
                Arrays.fill(array, read, array.length, (short)0);
                Label_0075: {
                    this.a.unlock();
                }
                return array;
            }
            finally {
                this.a.unlock();
            }
        }
    }
}
