package com.outfit7.talkingtom;

import android.util.Log;
import android.content.Context;
import com.a.a.h;
import com.a.a.d;
import android.os.Bundle;
import android.app.Activity;
import com.a.a.g;

final class eu implements g
{
    private g a;
    private Activity b;
    private TalkingTomApplication c;
    
    eu(final TalkingTomApplication c, final g a, final Activity b) {
        this.c = c;
        this.a = a;
        this.b = b;
    }
    
    @Override
    public final void a() {
        this.a.a();
    }
    
    @Override
    public final void a(final Bundle bundle) {
        this.a.a(bundle);
    }
    
    @Override
    public final void a(final d d) {
        this.a.a(d);
    }
    
    @Override
    public final void a(final h h) {
        this.a.a(h);
        try {
            this.c.e.a((Context)this.b);
        }
        catch (final Exception ex) {
            Log.w(TalkingTomApplication.c, ex.getLocalizedMessage(), (Throwable)ex);
        }
    }
}
