package com.outfit7.talkingtom;

import android.view.MotionEvent;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import android.view.View;
import android.view.View$OnTouchListener;

final class bx extends Thread implements View$OnTouchListener
{
    final Main a;
    private float b;
    private float c;
    private float d;
    private View e;
    private long f;
    private Lock g;
    private Condition h;
    private Condition i;
    private long j;
    private cd k;
    
    bx(final Main p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     2: putfield        com/outfit7/talkingtom/bx.a:Lcom/outfit7/talkingtom/Main;
        //     5: aload_0        
        //     6: invokespecial   java/lang/Thread.<init>:()V
        //     9: aload_0        
        //    10: new             Ljava/util/concurrent/locks/ReentrantLock;
        //    13: dup            
        //    14: invokespecial   java/util/concurrent/locks/ReentrantLock.<init>:()V
        //    17: putfield        com/outfit7/talkingtom/bx.g:Ljava/util/concurrent/locks/Lock;
        //    20: aload_0        
        //    21: aload_0        
        //    22: getfield        com/outfit7/talkingtom/bx.g:Ljava/util/concurrent/locks/Lock;
        //    25: invokeinterface java/util/concurrent/locks/Lock.newCondition:()Ljava/util/concurrent/locks/Condition;
        //    30: putfield        com/outfit7/talkingtom/bx.h:Ljava/util/concurrent/locks/Condition;
        //    33: aload_0        
        //    34: aload_0        
        //    35: getfield        com/outfit7/talkingtom/bx.g:Ljava/util/concurrent/locks/Lock;
        //    38: invokeinterface java/util/concurrent/locks/Lock.newCondition:()Ljava/util/concurrent/locks/Condition;
        //    43: putfield        com/outfit7/talkingtom/bx.i:Ljava/util/concurrent/locks/Condition;
        //    46: aload_0        
        //    47: getfield        com/outfit7/talkingtom/bx.g:Ljava/util/concurrent/locks/Lock;
        //    50: invokeinterface java/util/concurrent/locks/Lock.lock:()V
        //    55: aload_0        
        //    56: invokevirtual   com/outfit7/talkingtom/bx.start:()V
        //    59: aload_0        
        //    60: getfield        com/outfit7/talkingtom/bx.h:Ljava/util/concurrent/locks/Condition;
        //    63: invokeinterface java/util/concurrent/locks/Condition.await:()V
        //    68: aload_0        
        //    69: getfield        com/outfit7/talkingtom/bx.g:Ljava/util/concurrent/locks/Lock;
        //    72: invokeinterface java/util/concurrent/locks/Lock.unlock:()V
        //    77: return         
        //    78: astore_1       
        //    79: aload_0        
        //    80: getfield        com/outfit7/talkingtom/bx.g:Ljava/util/concurrent/locks/Lock;
        //    83: invokeinterface java/util/concurrent/locks/Lock.unlock:()V
        //    88: aload_1        
        //    89: athrow         
        //    90: astore_1       
        //    91: goto            68
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  55     59     78     90     Any
        //  59     68     90     94     Ljava/lang/InterruptedException;
        //  59     68     78     90     Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0068:
        //     at w5.m.a(SourceFile:20)
        //     at w5.f.o(SourceFile:122)
        //     at w5.f.r(SourceFile:571)
        //     at w5.f.q(SourceFile:3)
        //     at a6.j.j(SourceFile:32)
        //     at a6.j.i(SourceFile:28)
        //     at a6.i.n(SourceFile:7)
        //     at a6.i.k(SourceFile:69)
        //     at a6.i.c(SourceFile:57)
        //     at a6.i.r(SourceFile:328)
        //     at a6.i.s(SourceFile:17)
        //     at a6.i.q(SourceFile:29)
        //     at a6.i.b(SourceFile:33)
        //     at y5.d.e(SourceFile:6)
        //     at y5.d.b(SourceFile:1)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(SourceFile:306)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:131)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
        //     at e7.a.run(SourceFile:1)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        //     at java.lang.Thread.run(Thread.java:1012)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public final boolean onTouch(final View e, final MotionEvent motionEvent) {
        while (true) {
            Label_0166: {
                Label_0091: {
                    synchronized (this) {
                        switch (motionEvent.getAction()) {
                            case 1: {
                                ++this.j;
                                this.k.post((Runnable)new by(this, motionEvent, e));
                                break;
                            }
                            case 0: {
                                break Label_0091;
                            }
                            case 2: {
                                break Label_0166;
                            }
                        }
                        return true;
                    }
                }
                this.b = motionEvent.getRawX();
                this.c = motionEvent.getRawY();
                this.d = 0.0f;
                this.e = e;
                this.g.lock();
                try {
                    this.f = System.currentTimeMillis();
                    this.i.signal();
                    return true;
                }
                finally {
                    this.g.unlock();
                }
            }
            final float abs = Math.abs(motionEvent.getRawX() - this.b);
            final float abs2 = Math.abs(motionEvent.getRawY() - this.c);
            if (abs > this.d) {
                this.d = abs;
            }
            if (abs2 > this.d) {
                this.d = abs2;
                return true;
            }
            return true;
        }
    }
    
    public final void run() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getfield        com/outfit7/talkingtom/bx.g:Ljava/util/concurrent/locks/Lock;
        //     4: invokeinterface java/util/concurrent/locks/Lock.lock:()V
        //     9: new             Landroid/os/HandlerThread;
        //    12: astore          4
        //    14: aload           4
        //    16: ldc             "onTouch"
        //    18: invokespecial   android/os/HandlerThread.<init>:(Ljava/lang/String;)V
        //    21: aload           4
        //    23: invokevirtual   android/os/HandlerThread.start:()V
        //    26: new             Lcom/outfit7/talkingtom/cd;
        //    29: astore_3       
        //    30: aload_3        
        //    31: aload           4
        //    33: invokevirtual   android/os/HandlerThread.getLooper:()Landroid/os/Looper;
        //    36: invokespecial   com/outfit7/talkingtom/cd.<init>:(Landroid/os/Looper;)V
        //    39: aload_0        
        //    40: aload_3        
        //    41: putfield        com/outfit7/talkingtom/bx.k:Lcom/outfit7/talkingtom/cd;
        //    44: aload_0        
        //    45: getfield        com/outfit7/talkingtom/bx.h:Ljava/util/concurrent/locks/Condition;
        //    48: invokeinterface java/util/concurrent/locks/Condition.signal:()V
        //    53: aload_0        
        //    54: getfield        com/outfit7/talkingtom/bx.g:Ljava/util/concurrent/locks/Lock;
        //    57: invokeinterface java/util/concurrent/locks/Lock.unlock:()V
        //    62: aload_0        
        //    63: getfield        com/outfit7/talkingtom/bx.g:Ljava/util/concurrent/locks/Lock;
        //    66: invokeinterface java/util/concurrent/locks/Lock.lock:()V
        //    71: aload_0        
        //    72: getfield        com/outfit7/talkingtom/bx.f:J
        //    75: lstore_1       
        //    76: lload_1        
        //    77: lconst_0       
        //    78: lcmp           
        //    79: ifne            127
        //    82: aload_0        
        //    83: getfield        com/outfit7/talkingtom/bx.i:Ljava/util/concurrent/locks/Condition;
        //    86: invokeinterface java/util/concurrent/locks/Condition.await:()V
        //    91: aload_0        
        //    92: getfield        com/outfit7/talkingtom/bx.g:Ljava/util/concurrent/locks/Lock;
        //    95: invokeinterface java/util/concurrent/locks/Lock.unlock:()V
        //   100: goto            62
        //   103: astore_3       
        //   104: aload_0        
        //   105: getfield        com/outfit7/talkingtom/bx.g:Ljava/util/concurrent/locks/Lock;
        //   108: invokeinterface java/util/concurrent/locks/Lock.unlock:()V
        //   113: aload_3        
        //   114: athrow         
        //   115: astore_3       
        //   116: aload_0        
        //   117: getfield        com/outfit7/talkingtom/bx.g:Ljava/util/concurrent/locks/Lock;
        //   120: invokeinterface java/util/concurrent/locks/Lock.unlock:()V
        //   125: aload_3        
        //   126: athrow         
        //   127: aload_0        
        //   128: getfield        com/outfit7/talkingtom/bx.g:Ljava/util/concurrent/locks/Lock;
        //   131: invokeinterface java/util/concurrent/locks/Lock.unlock:()V
        //   136: ldc2_w          200
        //   139: invokestatic    java/lang/Thread.sleep:(J)V
        //   142: aload_0        
        //   143: getfield        com/outfit7/talkingtom/bx.g:Ljava/util/concurrent/locks/Lock;
        //   146: invokeinterface java/util/concurrent/locks/Lock.lock:()V
        //   151: aload_0        
        //   152: getfield        com/outfit7/talkingtom/bx.f:J
        //   155: lconst_0       
        //   156: lcmp           
        //   157: ifeq            197
        //   160: aload_0        
        //   161: getfield        com/outfit7/talkingtom/bx.d:F
        //   164: ldc             5.0
        //   166: fcmpg          
        //   167: ifge            209
        //   170: aload_0        
        //   171: getfield        com/outfit7/talkingtom/bx.k:Lcom/outfit7/talkingtom/cd;
        //   174: astore          4
        //   176: new             Lcom/outfit7/talkingtom/ca;
        //   179: astore_3       
        //   180: aload_3        
        //   181: aload_0        
        //   182: invokespecial   com/outfit7/talkingtom/ca.<init>:(Lcom/outfit7/talkingtom/bx;)V
        //   185: aload           4
        //   187: aload_3        
        //   188: invokevirtual   com/outfit7/talkingtom/cd.post:(Ljava/lang/Runnable;)Z
        //   191: pop            
        //   192: aload_0        
        //   193: lconst_0       
        //   194: putfield        com/outfit7/talkingtom/bx.f:J
        //   197: aload_0        
        //   198: getfield        com/outfit7/talkingtom/bx.g:Ljava/util/concurrent/locks/Lock;
        //   201: invokeinterface java/util/concurrent/locks/Lock.unlock:()V
        //   206: goto            62
        //   209: aload_0        
        //   210: getfield        com/outfit7/talkingtom/bx.a:Lcom/outfit7/talkingtom/Main;
        //   213: astore          4
        //   215: new             Lcom/outfit7/talkingtom/cc;
        //   218: astore_3       
        //   219: aload_3        
        //   220: aload_0        
        //   221: invokespecial   com/outfit7/talkingtom/cc.<init>:(Lcom/outfit7/talkingtom/bx;)V
        //   224: aload           4
        //   226: aload_3        
        //   227: invokevirtual   com/outfit7/talkingtom/Main.runOnUiThread:(Ljava/lang/Runnable;)V
        //   230: goto            197
        //   233: astore_3       
        //   234: aload_0        
        //   235: getfield        com/outfit7/talkingtom/bx.g:Ljava/util/concurrent/locks/Lock;
        //   238: invokeinterface java/util/concurrent/locks/Lock.unlock:()V
        //   243: aload_3        
        //   244: athrow         
        //   245: astore_3       
        //   246: goto            142
        //   249: astore_3       
        //   250: goto            91
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  9      53     103    115    Any
        //  71     76     115    127    Any
        //  82     91     249    253    Ljava/lang/InterruptedException;
        //  82     91     115    127    Any
        //  136    142    245    249    Ljava/lang/InterruptedException;
        //  151    197    233    245    Any
        //  209    230    233    245    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 113 out of bounds for length 113
        //     at jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at jdk.internal.util.Preconditions.checkIndex(Preconditions.java:266)
        //     at java.util.Objects.checkIndex(Objects.java:359)
        //     at java.util.ArrayList.get(ArrayList.java:434)
        //     at w5.a.o(SourceFile:31)
        //     at w5.a.j(SourceFile:218)
        //     at a6.j.j(SourceFile:23)
        //     at a6.j.i(SourceFile:28)
        //     at a6.i.n(SourceFile:7)
        //     at a6.i.m(SourceFile:174)
        //     at a6.i.c(SourceFile:67)
        //     at a6.i.r(SourceFile:328)
        //     at a6.i.s(SourceFile:17)
        //     at a6.i.q(SourceFile:29)
        //     at a6.i.b(SourceFile:33)
        //     at y5.d.e(SourceFile:6)
        //     at y5.d.b(SourceFile:1)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(SourceFile:306)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:131)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
        //     at e7.a.run(SourceFile:1)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        //     at java.lang.Thread.run(Thread.java:1012)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
