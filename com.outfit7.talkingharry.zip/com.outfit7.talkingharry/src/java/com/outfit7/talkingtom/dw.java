package com.outfit7.talkingtom;

final class dw
{
    private String a;
    private int b;
    private int c;
    private int d;
    private int e;
    
    public dw(final String a, final int b, final int c, final int d, final int e) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
    }
    
    public final String a() {
        return this.a;
    }
    
    @Override
    public final String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("TouchZone[name=").append(this.a).append(", width=").append(this.b).append(", height=");
        sb.append(this.c).append(", top=").append(this.d).append(", left=").append(this.e).append("]");
        return sb.toString();
    }
}
