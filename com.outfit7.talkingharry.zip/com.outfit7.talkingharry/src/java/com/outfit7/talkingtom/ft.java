package com.outfit7.talkingtom;

import com.outfit7.talkingtom.a.a;
import android.os.Bundle;

final class ft extends i
{
    final fs a;
    
    ft(final fs a) {
        this.a = a;
    }
    
    @Override
    public final void a(final Bundle bundle) {
        if (bundle.getString("post_id") == null) {
            com.outfit7.talkingtom.a.a.a(this.a.a, null, this.a.a.getString(2131099708));
        }
        this.a.a.runOnUiThread((Runnable)new fu(this));
    }
}
