package com.outfit7.talkingtom;

import android.util.Log;
import android.content.DialogInterface;
import android.content.DialogInterface$OnClickListener;

final class e implements DialogInterface$OnClickListener
{
    public final void onClick(final DialogInterface dialogInterface, final int n) {
        try {
            dialogInterface.dismiss();
        }
        catch (final RuntimeException ex) {
            Log.w(b.c, ex.getLocalizedMessage(), (Throwable)ex);
        }
    }
}
