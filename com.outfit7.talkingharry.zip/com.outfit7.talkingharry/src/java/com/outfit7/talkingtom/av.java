package com.outfit7.talkingtom;

final class av extends aq
{
    public av(final au au, final av av) {
        this(au, av.c);
    }
    
    public av(final au au, final short[] c) {
        super(au.a);
        if (c != null) {
            this.c = c;
            this.d = c.length;
        }
    }
}
