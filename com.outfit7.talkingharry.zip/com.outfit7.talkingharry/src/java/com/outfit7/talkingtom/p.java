package com.outfit7.talkingtom;

final class p
{
    String a;
    String b;
    private n c;
    
    p(final n c) {
        this.c = c;
    }
    
    final p a(final int n) {
        this.a = (String)this.c.i.get(n);
        return this;
    }
    
    @Override
    public final String toString() {
        return this.a;
    }
}
