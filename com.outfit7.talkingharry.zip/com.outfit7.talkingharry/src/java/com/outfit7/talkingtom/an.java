package com.outfit7.talkingtom;

final class an extends m
{
    an(final ad ad) {
        super(ad.b);
    }
    
    public final void a() {
    }
}
