package com.outfit7.talkingtom;

final class dc implements Runnable
{
    private db a;
    
    dc(final db a) {
        this.a = a;
    }
    
    public final void run() {
        this.a.m.a.findViewById(2131296271).setVisibility(0);
        this.a.m.a.findViewById(2131296274).setVisibility(0);
    }
}
