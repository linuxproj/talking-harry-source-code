package com.outfit7.talkingtom;

final class cb implements Runnable
{
    private ca a;
    
    cb(final ca a) {
        this.a = a;
    }
    
    public final void run() {
        if (this.a.b >= this.a.a.j) {
            this.a.a.a.j = this.a.a.b;
            this.a.a.a.k = this.a.a.c;
            this.a.a.e.performClick();
        }
    }
}
