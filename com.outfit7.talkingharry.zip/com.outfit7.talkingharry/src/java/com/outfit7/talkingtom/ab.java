package com.outfit7.talkingtom;

import android.os.Looper;

final class ab extends Thread
{
    private aa a;
    private boolean b;
    private Engine c;
    
    ab(final Engine c, final boolean b) {
        this.c = c;
        this.b = b;
    }
    
    final aa a() {
        return this.a;
    }
    
    public final void run() {
        Looper.prepare();
        this.a = new aa(this.c);
        synchronized (this) {
            this.notify();
            monitorexit(this);
            if (this.b) {
                this.c.c();
            }
            Looper.loop();
        }
    }
}
