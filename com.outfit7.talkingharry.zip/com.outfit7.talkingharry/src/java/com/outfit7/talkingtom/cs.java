package com.outfit7.talkingtom;

final class cs implements Runnable
{
    final cr a;
    
    cs(final cr a) {
        this.a = a;
    }
    
    public final void run() {
        this.a.m.a.r.a(this.a.m.a.findViewById(2131296265), new ct(this));
    }
}
