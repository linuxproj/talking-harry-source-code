package com.outfit7.talkingtom;

import android.graphics.Bitmap;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;

final class ak implements Runnable
{
    private RelativeLayout a;
    private ImageView b;
    
    ak(final RelativeLayout a, final ImageView b) {
        this.a = a;
        this.b = b;
    }
    
    public final void run() {
        this.a.removeView((View)this.b);
        this.b.setImageBitmap((Bitmap)null);
    }
}
