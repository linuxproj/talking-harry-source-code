package com.outfit7.talkingtom;

import android.app.Activity;

final class ea extends n
{
    private dz m;
    
    ea(final dz m, final Engine engine, final Activity activity) {
        this.m = m;
        engine.getClass();
        super(engine, activity);
    }
    
    @Override
    public final void c() {
        super.c();
        Main.d(this.m.c);
    }
    
    @Override
    public final void f() {
        super.b = 5;
    }
    
    @Override
    public final void j() {
        super.j();
        if (this.m.e++ == 0 && this.m.c.l != null) {
            this.m.c.l.start();
        }
        if (this.m.c.c.a(1, 2) == 1 || this.m.d++ == 0) {
            this.a("gozd/zeha");
            this.g();
            this.a(0).b = "zeh" + this.m.c.c.a(1, 2) + "n";
        }
        else {
            this.a("gozd/vzdih");
            this.g();
            this.a(0).b = "xhaleNew";
        }
    }
    
    @Override
    public final void k() {
        super.k();
        Main.d(this.m.c);
    }
}
