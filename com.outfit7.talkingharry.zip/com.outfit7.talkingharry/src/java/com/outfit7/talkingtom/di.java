package com.outfit7.talkingtom;

import android.widget.ProgressBar;

final class di extends Thread
{
    private final ProgressBar a;
    private Thread b;
    private dh c;
    
    di(final dh c, final Thread b) {
        this.c = c;
        this.b = b;
        this.a = this.c.b;
    }
    
    public final void run() {
        int n = 100;
    Label_0048_Outer:
        while (true) {
            Label_0071: {
                if (n < 0) {
                    break Label_0071;
                }
                if (this.c.b != this.a) {
                    break;
                }
                this.c.a.post((Runnable)new dj(this, n));
                while (true) {
                    try {
                        Thread.sleep(220L);
                        int n2 = n;
                        if (this.c.c) {
                            n2 = n + 1;
                        }
                        n = n2 - 1;
                        continue Label_0048_Outer;
                        iftrue(Label_0021:)(this.b == null || this.a == null);
                        while (true) {
                            Block_6: {
                                break Block_6;
                                try {
                                    while (this.c.d) {
                                        try {
                                            this.c.wait();
                                        }
                                        catch (final InterruptedException ex) {}
                                    }
                                    final dh c;
                                    monitorexit(c);
                                    this.b.start();
                                }
                                finally {
                                    final dh c;
                                    monitorexit(c);
                                }
                            }
                            final dh c = this.c;
                            monitorenter(c);
                            continue;
                        }
                    }
                    catch (final InterruptedException ex2) {
                        continue;
                    }
                    break;
                }
            }
        }
        Label_0021:;
    }
}
