package com.outfit7.talkingtom;

final class da implements ar
{
    private cv a;
    
    da(final cv a) {
        this.a = a;
    }
    
    @Override
    public final int a(final aq aq) {
        return 0;
    }
    
    @Override
    public final String a() {
        return "animations/gozd/poslusa/poslusa.png";
    }
    
    @Override
    public final String a(final int n) {
        return String.format("animations/gozd/govor/govor%04d.png", new Object[] { n });
    }
    
    @Override
    public final int b() {
        return 2130837507;
    }
    
    @Override
    public final void c() {
    }
    
    @Override
    public final void d() {
    }
    
    @Override
    public final void e() {
    }
    
    @Override
    public final void f() {
    }
    
    @Override
    public final void g() {
        Main.d(this.a.a);
    }
}
