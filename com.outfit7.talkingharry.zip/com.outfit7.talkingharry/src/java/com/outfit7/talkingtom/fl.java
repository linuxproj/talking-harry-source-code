package com.outfit7.talkingtom;

import android.os.Bundle;

final class fl extends i
{
    @Override
    public final void a() {
    }
    
    @Override
    public final void a(final Bundle bundle) {
    }
}
