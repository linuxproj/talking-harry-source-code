package com.outfit7.talkingtom;

public final class g
{
    private String a;
    private int b;
    private long c;
    
    public g(final String a, final int b, final long c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    public final int a() {
        return this.b;
    }
    
    public final long b() {
        return this.c;
    }
    
    @Override
    public final String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("AviData[file=").append(this.a);
        sb.append(", lengthInSeconds=").append(this.b);
        sb.append(", sizeInBytes=").append(this.c);
        sb.append("]");
        return sb.toString();
    }
}
