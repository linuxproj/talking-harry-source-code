package com.outfit7.talkingtom;

import android.app.Activity;

final class dz extends ce
{
    final Main c;
    private int d;
    private int e;
    
    private dz(final Main c, final byte b) {
        super(this.c = c);
    }
    
    @Override
    public final void a() {
        this.a = System.currentTimeMillis() + this.c.c.a(0, 10000) + 5000L;
    }
    
    @Override
    public final boolean b() {
        return this != this.c.m;
    }
    
    @Override
    public final n c() {
        final Engine a = this.c.c;
        a.getClass();
        final ea ea = new ea(this, a, this.c);
        ea.d = true;
        return ea;
    }
}
