package com.outfit7.talkingtom;

import android.view.View;
import android.view.View$OnClickListener;

final class cw implements View$OnClickListener
{
    private cx a;
    
    cw(final cx a) {
        this.a = a;
    }
    
    public final void onClick(final View view) {
        this.a.b();
    }
}
