package com.outfit7.talkingtom;

import android.app.Activity;

final class cr extends n
{
    final cl m;
    
    cr(final cl m, final Engine engine, final String s, final Activity activity) {
        this.m = m;
        engine.getClass();
        super(engine, s, activity);
    }
    
    @Override
    public final void j() {
        super.j();
        this.g();
        this.m.a.c.b.sendMessage(this.m.a.c.b.obtainMessage(5, (Object)new as(2130837505)));
        this.m.a.c.b.post((Runnable)new cs(this));
    }
    
    @Override
    public final void k() {
        super.k();
    }
}
