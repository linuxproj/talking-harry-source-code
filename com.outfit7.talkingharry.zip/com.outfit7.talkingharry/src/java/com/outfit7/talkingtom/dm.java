package com.outfit7.talkingtom;

final class dm implements ar
{
    private dl a;
    
    dm(final dl a) {
        this.a = a;
    }
    
    @Override
    public final int a(final aq aq) {
        int n;
        if ((n = ((TalkingTomApplication)this.a.a.getApplicationContext()).i()) > aq.d) {
            n = aq.d;
        }
        final short[] c = new short[aq.d + n];
        System.arraycopy((Object)aq.c, 0, (Object)c, 0, aq.d);
        System.arraycopy((Object)aq.c, aq.d - n, (Object)c, aq.d, n);
        aq.c = c;
        aq.d += n;
        return n;
    }
    
    @Override
    public final String a() {
        return "animations/stolpnica/poslusa/poslusa.png";
    }
    
    @Override
    public final String a(final int n) {
        return String.format("animations/stolpnica/govor/odpre_usta%04d.png", new Object[] { n });
    }
    
    @Override
    public final int b() {
        return 2130837509;
    }
    
    @Override
    public final void c() {
        this.a.a.r.a(true);
    }
    
    @Override
    public final void d() {
        this.a.a.r.a(false);
    }
    
    @Override
    public final void e() {
        this.a.a.r.b(true);
    }
    
    @Override
    public final void f() {
        this.a.a.r.b(false);
    }
    
    @Override
    public final void g() {
        Main.d(this.a.a);
    }
}
