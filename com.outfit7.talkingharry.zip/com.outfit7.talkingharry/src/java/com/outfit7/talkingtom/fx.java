package com.outfit7.talkingtom;

import android.content.SharedPreferences$Editor;
import android.content.Intent;
import android.content.Context;
import android.app.AlertDialog$Builder;
import android.view.View;
import android.widget.EditText;
import android.view.View$OnClickListener;

final class fx implements View$OnClickListener
{
    private EditText a;
    private EditText b;
    private EditText c;
    private EditText d;
    private YouTubeLoginActivity e;
    
    fx(final YouTubeLoginActivity e, final EditText a, final EditText b, final EditText c, final EditText d) {
        this.e = e;
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }
    
    public final void onClick(final View view) {
        final String string = this.a.getText().toString();
        final String string2 = this.b.getText().toString();
        final String string3 = this.c.getText().toString();
        final String string4 = this.d.getText().toString();
        if (string.equals((Object)"")) {
            final AlertDialog$Builder alertDialog$Builder = new AlertDialog$Builder((Context)this.e);
            alertDialog$Builder.setTitle((CharSequence)this.e.getString(2131099654));
            alertDialog$Builder.setMessage((CharSequence)this.e.getString(2131099698));
            alertDialog$Builder.create().show();
        }
        else if (string2.equals((Object)"") || string3.equals((Object)"")) {
            final AlertDialog$Builder alertDialog$Builder2 = new AlertDialog$Builder((Context)this.e);
            alertDialog$Builder2.setTitle((CharSequence)this.e.getString(2131099654));
            alertDialog$Builder2.setMessage((CharSequence)this.e.getString(2131099699));
            alertDialog$Builder2.create().show();
        }
        else {
            final SharedPreferences$Editor edit = this.e.getSharedPreferences("prefs", 0).edit();
            edit.putString("youtubeUsername", string);
            edit.putString("youtubePassword", string2);
            edit.commit();
            final Intent intent = new Intent();
            intent.putExtra("youtubeUsername", string);
            intent.putExtra("youtubePassword", string2);
            intent.putExtra("youtubeVideoTitle", string3);
            intent.putExtra("youtubeVideoDescription", string4);
            this.e.setResult(3, intent);
            this.e.finish();
        }
    }
}
