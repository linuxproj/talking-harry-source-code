package com.outfit7.talkingtom;

final class ba implements Runnable
{
    private KbdImageView a;
    
    ba(final KbdImageView a) {
        this.a = a;
    }
    
    public final void run() {
        this.a.a(null, null);
    }
}
