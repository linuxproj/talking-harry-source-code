package com.outfit7.talkingtom;

final class fe implements Runnable
{
    private int a;
    private long b;
    private fd c;
    
    fe(final fd c, final int a, final long b) {
        this.c = c;
        this.a = a;
        this.b = b;
    }
    
    public final void run() {
        fd.a(this.c);
    }
}
