package com.outfit7.talkingtom;

import java.util.Iterator;
import android.app.Activity;
import android.widget.RelativeLayout$LayoutParams;
import android.view.View$OnLongClickListener;
import android.view.View$OnClickListener;
import android.view.View$OnTouchListener;
import android.content.Context;
import android.view.View;
import android.widget.RelativeLayout;

final class cv extends dt
{
    final Main a;
    
    cv(final Main a) {
        super(this.a = a);
        final RelativeLayout relativeLayout = (RelativeLayout)a.findViewById(2131296263);
        final View view = new View((Context)a);
        relativeLayout.addView(view);
        this.b.add((Object)view);
        view.setHapticFeedbackEnabled(false);
        view.setOnTouchListener((View$OnTouchListener)new bx(a));
        final cx cx = new cx(this);
        view.setOnClickListener((View$OnClickListener)new cw(cx));
        view.setOnLongClickListener((View$OnLongClickListener)new cz(cx));
    }
    
    @Override
    final void a() {
        super.a();
        this.a.c.b.post((Runnable)new dd(this));
    }
    
    @Override
    final void b() {
        final RelativeLayout$LayoutParams relativeLayout$LayoutParams = (RelativeLayout$LayoutParams)((View)this.b.get(0)).getLayoutParams();
        relativeLayout$LayoutParams.width = (int)(130.0 * this.a.f);
        relativeLayout$LayoutParams.height = (int)(180.0 * this.a.f);
        relativeLayout$LayoutParams.topMargin = (int)(this.a.f * 80.0) + this.a.g;
        relativeLayout$LayoutParams.leftMargin = (int)(this.a.f * 80.0) + this.a.h;
    }
    
    @Override
    final boolean c() {
        boolean b;
        if (!super.c()) {
            b = false;
        }
        else {
            final RelativeLayout relativeLayout = (RelativeLayout)this.a.findViewById(2131296263);
            Main.a(this.a, 1);
            for (final View view : this.b) {
                if (view.getParent() == null) {
                    relativeLayout.addView(view);
                }
            }
            this.a.c.a(new da(this));
            this.a.m = new dz(this.a);
            this.a.l = new ch(this.a);
            final Engine a = this.a.c;
            a.getClass();
            final db db = new db(this, a, "gozd/base", this.a);
            db.b = Integer.MAX_VALUE;
            db.d = true;
            db.i();
            this.a.c.c.a().sendMessage(this.a.c.c.a().obtainMessage(0, (Object)db));
            b = true;
        }
        return b;
    }
    
    @Override
    final boolean e() {
        boolean b;
        if (!super.e()) {
            b = false;
        }
        else {
            this.a.l = null;
            this.a.m = null;
            b = true;
        }
        return b;
    }
}
