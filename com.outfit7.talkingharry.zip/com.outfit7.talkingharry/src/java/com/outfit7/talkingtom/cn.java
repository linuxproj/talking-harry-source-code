package com.outfit7.talkingtom;

import android.app.Activity;

final class cn extends n
{
    private cm m;
    
    cn(final cm m, final Engine engine, final String s, final Activity activity) {
        this.m = m;
        engine.getClass();
        super(engine, s, activity);
    }
    
    @Override
    public final void f() {
        super.b = Integer.MAX_VALUE;
    }
    
    @Override
    public final void j() {
        super.j();
        this.g();
        this.a(0).b = "punchFall";
    }
    
    @Override
    public final void k() {
        super.k();
        this.m.a.e();
        this.m.a.a.e();
    }
}
