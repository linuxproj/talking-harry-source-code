package com.outfit7.talkingtom;

import org.apache.http.client.HttpClient;
import org.apache.http.StatusLine;
import org.apache.http.HttpEntity;
import org.apache.http.entity.mime.content.FileBody;
import java.io.File;
import org.apache.http.entity.mime.content.ContentBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.client.methods.HttpPost;
import java.nio.charset.Charset;
import com.outfit7.a.a;
import java.util.Iterator;
import java.util.Map$Entry;
import java.util.TreeMap;
import java.util.SortedMap;
import org.apache.http.HttpResponse;
import java.io.BufferedInputStream;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.BasicHttpParams;
import java.io.ByteArrayOutputStream;
import org.json.JSONArray;
import org.json.JSONObject;
import java.security.MessageDigest;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.InputStream;
import com.a.a.e;
import com.outfit7.a.b;

public final class aw
{
    private String a;
    private String b;
    private String c;
    private b d;
    
    public aw() {
    }
    
    public aw(final e e, final String a, final String b) {
        final String b2 = e.b();
        final int n = b2.indexOf("%7C") + 3;
        this.c = b2.substring(n, b2.indexOf("%7C", n));
        this.a = a;
        this.b = b;
    }
    
    private static String a(final InputStream inputStream) {
        final StringBuilder sb = new StringBuilder();
        final BufferedReader bufferedReader = new BufferedReader((Reader)new InputStreamReader(inputStream), 1000);
        for (String s = bufferedReader.readLine(); s != null; s = bufferedReader.readLine()) {
            sb.append(s);
        }
        inputStream.close();
        return sb.toString();
    }
    
    private static String a(String s) {
        try {
            final MessageDigest instance = MessageDigest.getInstance("MD5");
            instance.reset();
            instance.update(s.getBytes("UTF-8"));
            final byte[] digest = instance.digest();
            final StringBuffer sb = new StringBuffer();
            for (int i = 0; i < digest.length; ++i) {
                s = Integer.toHexString(digest[i] & 0xFF);
                if (s.length() == 1) {
                    sb.append('0');
                }
                sb.append(s);
            }
            s = sb.toString();
            return s;
        }
        catch (final Exception ex) {
            throw new RuntimeException();
        }
    }
    
    public static JSONArray a(JSONObject o, final String s) {
        try {
            o = ((JSONObject)o).getJSONArray(s);
            return (JSONArray)o;
        }
        catch (final Exception ex) {
            try {
                o = new JSONArray().put((Object)((JSONObject)o).getJSONObject(s));
            }
            catch (final Exception ex2) {
                o = new JSONArray();
            }
        }
    }
    
    public static JSONObject a(final String s, final String s2) {
        final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(4096);
        final byte[] array = new byte[4096];
        final BasicHttpParams basicHttpParams = new BasicHttpParams();
        HttpConnectionParams.setConnectionTimeout((HttpParams)basicHttpParams, 5000);
        HttpConnectionParams.setSoTimeout((HttpParams)basicHttpParams, 5000);
        final DefaultHttpClient defaultHttpClient = new DefaultHttpClient((HttpParams)basicHttpParams);
        final HttpGet httpGet = new HttpGet(s);
        if (s.contains((CharSequence)"outfit7-affirmations.appspot.com") && s.contains((CharSequence)"talkingFriends")) {
            ((HttpUriRequest)httpGet).setHeader("Authorization", TalkingTomApplication.b);
        }
        ((HttpUriRequest)httpGet).setHeader("User-Agent", s2);
        final HttpResponse execute = ((HttpClient)defaultHttpClient).execute((HttpUriRequest)httpGet);
        JSONObject jsonObject;
        if (execute.getEntity() == null) {
            jsonObject = null;
        }
        else {
            final InputStream content = execute.getEntity().getContent();
            final BufferedInputStream bufferedInputStream = new BufferedInputStream(content, 4096);
            while (true) {
                final int read = bufferedInputStream.read(array);
                if (read == -1) {
                    break;
                }
                byteArrayOutputStream.write(array, 0, read);
            }
            byteArrayOutputStream.close();
            bufferedInputStream.close();
            content.close();
            jsonObject = new JSONObject(byteArrayOutputStream.toString("UTF-8"));
        }
        return jsonObject;
    }
    
    private SortedMap b(final String s, final String s2) {
        final TreeMap treeMap = new TreeMap();
        ((SortedMap)treeMap).put((Object)"api_key", (Object)this.a);
        ((SortedMap)treeMap).put((Object)"call_id", (Object)Long.toString(System.nanoTime()));
        ((SortedMap)treeMap).put((Object)"description", (Object)s2);
        ((SortedMap)treeMap).put((Object)"format", (Object)"JSON");
        ((SortedMap)treeMap).put((Object)"method", (Object)"facebook.video.upload");
        ((SortedMap)treeMap).put((Object)"session_key", (Object)this.c);
        ((SortedMap)treeMap).put((Object)"title", (Object)s);
        ((SortedMap)treeMap).put((Object)"v", (Object)"1.0");
        final StringBuilder sb = new StringBuilder();
        for (final Map$Entry map$Entry : ((SortedMap)treeMap).entrySet()) {
            sb.append((String)map$Entry.getKey()).append("=").append((String)map$Entry.getValue());
        }
        sb.append(this.b);
        ((SortedMap)treeMap).put((Object)"sig", (Object)a(sb.toString()));
        return (SortedMap)treeMap;
    }
    
    public final String a(final String s, final String s2, final String s3, final String s4, final a a) {
        final Charset forName = Charset.forName("UTF-8");
        final DefaultHttpClient defaultHttpClient = new DefaultHttpClient();
        final HttpPost httpPost = new HttpPost("http://api-video.facebook.com/restserver.php");
        httpPost.addHeader("Content-Type", "multipart/form-data; boundary=3i2ndDfv2rTHiSisAbouNdArYfORhtTPEefj3q2f");
        this.d = new b(HttpMultipartMode.STRICT, "3i2ndDfv2rTHiSisAbouNdArYfORhtTPEefj3q2f", forName, a);
        for (final Map$Entry map$Entry : this.b(s2, s3).entrySet()) {
            this.d.addPart((String)map$Entry.getKey(), (ContentBody)new StringBody((String)map$Entry.getValue(), forName));
        }
        this.d.addPart("data", (ContentBody)new FileBody(new File(s), s4));
        httpPost.setEntity((HttpEntity)this.d);
        final HttpResponse execute = ((HttpClient)defaultHttpClient).execute((HttpUriRequest)httpPost);
        final StatusLine statusLine = execute.getStatusLine();
        if (statusLine.getStatusCode() >= 200) {
            statusLine.getStatusCode();
        }
        return a(execute.getEntity().getContent());
    }
    
    public final void a() {
        if (this.d != null) {
            this.d.a();
        }
    }
}
