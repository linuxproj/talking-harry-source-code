package com.outfit7.talkingtom;

import android.os.Handler;
import android.content.DialogInterface;
import android.content.DialogInterface$OnClickListener;

final class ff implements DialogInterface$OnClickListener
{
    private fd a;
    
    ff(final fd a) {
        this.a = a;
    }
    
    public final void onClick(final DialogInterface dialogInterface, final int n) {
        final Handler a = ((BackgroundActivity)this.a.a).a();
        a.sendMessage(a.obtainMessage(2));
    }
}
