package com.outfit7.talkingtom;

import android.app.Activity;

final class cy extends n
{
    private cx m;
    
    cy(final cx m, final Engine engine, final String s, final Activity activity) {
        this.m = m;
        engine.getClass();
        super(engine, s, activity);
    }
    
    @Override
    public final void j() {
        super.j();
        this.g();
        this.a(0).b = "godrnjanje_0" + this.m.a.a.c.a(4, 6);
        ++this.m.b;
    }
    
    @Override
    public final void k() {
        super.k();
        Main.d(this.m.a.a);
        --this.m.b;
    }
}
