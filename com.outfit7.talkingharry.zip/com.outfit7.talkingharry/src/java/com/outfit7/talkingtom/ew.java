package com.outfit7.talkingtom;

final class ew implements Runnable
{
    private ev a;
    
    ew(final ev a) {
        this.a = a;
    }
    
    public final void run() {
        VideoCommentActivity.c(this.a.a, this.a.b);
    }
}
