package com.outfit7.talkingtom;

import android.app.Activity;

final class be extends bf
{
    private bd n;
    
    be(final bd n, final KbdLayout kbdLayout, final Activity activity) {
        this.n = n;
        kbdLayout.getClass();
        super(activity);
    }
    
    @Override
    public final void b() {
        synchronized (this) {
            super.b();
        }
    }
    
    @Override
    public final void b(final int n) {
        super.b(n);
        if (n == 10 && this.m) {
            this.a = true;
        }
        else if (n == 11) {
            this.b = 10;
        }
    }
    
    @Override
    public final void j() {
        super.j();
        throw new NullPointerException();
    }
}
