package com.outfit7.talkingtom;

import android.content.DialogInterface;
import android.content.DialogInterface$OnDismissListener;

final class el implements DialogInterface$OnDismissListener
{
    private ek a;
    
    el(final ek a) {
        this.a = a;
    }
    
    public final void onDismiss(final DialogInterface dialogInterface) {
        ((BackgroundActivity)this.a.a).a().sendEmptyMessage(2);
    }
}
