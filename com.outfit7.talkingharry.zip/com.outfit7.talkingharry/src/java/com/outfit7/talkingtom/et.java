package com.outfit7.talkingtom;

import com.outfit7.soundtouch.ShortArray;
import com.outfit7.soundtouch.JSoundTouch;
import com.outfit7.soundtouch.SoundTouch;

public class et
{
    private int A;
    private int B;
    private int C;
    private int D;
    private short[] E;
    private short[] F;
    private SoundTouch G;
    private double a;
    private double b;
    private int c;
    private int d;
    private int e;
    private int f;
    private double g;
    private int h;
    private int i;
    private int j;
    private int k;
    private boolean l;
    private boolean m;
    private boolean n;
    private int o;
    private int p;
    private int[] q;
    private int r;
    private int s;
    private int t;
    private short u;
    private short v;
    private int w;
    private int[] x;
    private int y;
    private int z;
    
    static {
        et.class.getName();
    }
    
    public et(int i, final int a, final int n) {
        this.a = 1.3;
        this.b = 1.2;
        this.c = 2000;
        this.d = 1000;
        this.e = 5;
        this.f = 5;
        this.g = 0.2;
        this.h = 10;
        this.j = 32;
        this.k = 32768 / this.j;
        this.q = new int[this.e];
        this.r = 0;
        this.z = i;
        this.A = a;
        this.E = new short[this.z];
        this.F = new short[a];
        this.i = n / this.h;
        (this.G = new SoundTouch()).setPitchSemiTones(1);
        this.G.setRateChange(0.0f);
        this.G.setTempoChange(-30.0f);
        this.G.setSampleRate(n);
        this.G.setChannels(1L);
        this.G.setSetting(JSoundTouch.SETTING_USE_QUICKSEEK, 0);
        this.G.setSetting(JSoundTouch.SETTING_USE_AA_FILTER, 0);
        this.G.setSetting(JSoundTouch.SETTING_SEQUENCE_MS, 40);
        this.G.setSetting(JSoundTouch.SETTING_SEEKWINDOW_MS, 15);
        this.G.setSetting(JSoundTouch.SETTING_OVERLAP_MS, 8);
        this.w = this.h * i / n;
        this.x = new int[this.w];
        this.b();
        for (i = 0; i < this.e; ++i) {
            this.q[i] = 0;
        }
    }
    
    private int a(int n, final int n2, final int n3) {
        n -= n2;
        if (n < 0 || n > n3) {
            n = 0;
        }
        else {
            n = this.E[n];
        }
        return n;
    }
    
    private static int b(final short[] array, final int n) {
        int i = 0;
        int n2 = 0;
        while (i < n) {
            final int abs = Math.abs((int)array[i]);
            int n3;
            if (abs > (n3 = n2)) {
                n3 = abs;
            }
            ++i;
            n2 = n3;
        }
        return n2;
    }
    
    private void c(final short[] array, int i) {
        int n = 0;
        this.e(b(array, i));
        for (i = 0; i < this.e; ++i) {
            n += this.q[i];
        }
        this.v = (short)(n / this.e);
    }
    
    private void e(final int n) {
        for (int i = 1; i < this.e; ++i) {
            this.q[i - 1] = this.q[i];
        }
        this.q[this.e - 1] = n;
    }
    
    private void g() {
        if (this.y < this.w) {
            for (int n = this.r / this.i, i = this.y; i < n; ++i) {
                final int j = this.i;
                if (this.x[i] == -1) {
                    final int[] array = new int[this.j];
                    for (int k = 0; k < this.j; ++k) {
                        array[k] = 0;
                    }
                    int n2 = j * i;
                    for (int l = 0; l < this.i; ++l) {
                        final int abs = Math.abs((int)this.E[n2]);
                        float n3;
                        if ((n3 = 1.0f - this.v * 3.5E-4f) < 0.3f) {
                            n3 = 0.3f;
                        }
                        int n4;
                        if ((n4 = (int)(abs * n3 / this.k)) >= this.j) {
                            n4 = this.j - 1;
                        }
                        ++array[n4];
                        ++n2;
                    }
                    int n5 = 0;
                    int n6 = 0;
                    while (n5 < this.j) {
                        if (array[n5] > this.i / 50) {
                            n6 = n5;
                        }
                        ++n5;
                    }
                    this.x[i] = this.k * n6;
                    this.y = i + 1;
                }
            }
        }
        if (this.l) {
            this.n = true;
        }
    }
    
    public final int a(final short[] array, int b) {
        if (this.n) {
            this.b();
        }
        ++this.p;
        if (this.m) {
            if (!this.l) {
                final short v = this.v;
                short n = (short)(v * this.b);
                if (n < this.d + v) {
                    n = (short)(v + this.d);
                }
                int n2 = 0;
                int n3;
                for (int i = 0; i < b; ++i, n2 = n3) {
                    n3 = n2;
                    if (Math.abs((int)array[i]) > n) {
                        n3 = n2 + 1;
                    }
                }
                int n4;
                if (n2 < 20) {
                    n4 = 1;
                }
                else {
                    n4 = 0;
                }
                if (n4 != 0) {
                    ++this.o;
                    this.s += b;
                    if (this.o >= this.f) {
                        this.l = true;
                        this.t = (int)(this.s * this.g);
                    }
                    if (this.o > 1) {
                        this.e(b(array, b));
                    }
                }
                else {
                    this.o = 0;
                    this.s = 0;
                }
            }
        }
        else if (this.p <= 1) {
            this.c(array, b);
        }
        else {
            final short v2 = this.v;
            short n5 = (short)(v2 * this.a);
            if (n5 < this.c + v2) {
                n5 = (short)(v2 + this.c);
            }
            int n6 = 0;
            long n7 = 0L;
            int n8;
            for (int j = 0; j < b; ++j, n6 = n8) {
                final int abs = Math.abs((int)array[j]);
                n7 += abs;
                n8 = n6;
                if (abs > n5) {
                    n8 = (short)(n6 + 1);
                }
            }
            int n9;
            if (n7 >= b * 50 && n6 > 20) {
                n9 = 1;
            }
            else {
                n9 = 0;
            }
            if (n9 != 0) {
                this.m = true;
                if (this.B != 0) {
                    final ShortArray shortArray = new ShortArray(this.B);
                    for (int k = 0; k < this.B; ++k) {
                        shortArray.setitem(k, this.E[k]);
                    }
                    this.G.putSamples(shortArray.cast(), this.B);
                    shortArray.delete();
                }
            }
            else {
                System.arraycopy((Object)array, 0, (Object)this.E, 0, b);
                this.c(array, this.B = b);
            }
        }
        if (this.m) {
            if (b != 0) {
                final ShortArray shortArray2 = new ShortArray(b);
                for (int l = 0; l < b; ++l) {
                    shortArray2.setitem(l, array[l]);
                }
                this.G.putSamples(shortArray2.cast(), b);
                shortArray2.delete();
            }
            b = 0;
            while (true) {
                while (this.r + this.A <= this.z) {
                    final ShortArray shortArray3 = new ShortArray(this.A);
                    final int n10 = (int)this.G.receiveSamples(shortArray3.cast(), this.A);
                    for (int n11 = 0; n11 < n10; ++n11) {
                        this.F[n11] = shortArray3.getitem(n11);
                        if (this.F[n11] > this.u) {
                            this.u = this.F[n11];
                        }
                    }
                    shortArray3.delete();
                    System.arraycopy((Object)this.F, 0, (Object)this.E, this.r, n10);
                    this.r += n10;
                    final int n12 = b += n10;
                    if (n10 == 0) {
                        b = n12;
                        this.g();
                        return b;
                    }
                }
                this.l = true;
                continue;
            }
        }
        b = 0;
        return b;
    }
    
    public final int a(final short[] array, int a, int i) {
        int r;
        final int n = r = this.r;
        if (this.t > 0 && (r = n - this.t) < 0) {
            a = 0;
        }
        else {
            final int n2 = r + 0 + this.C;
            if (n2 <= 0) {
                a = 0;
            }
            else {
                int n3;
                if ((n3 = n2 - 0) > i) {
                    n3 = i;
                }
                i = 0;
                int n4 = a;
                while (i < n3) {
                    final int n5 = a = this.a(n4, 0, r);
                    if (this.C > 0) {
                        a = (int)(this.a(n4, this.C, r) * 0.3);
                        final float n6 = n5 * 3.0517578E-5f;
                        final float n7 = a * 3.0517578E-5f;
                        float n8;
                        if ((n8 = n6 + n7 - n6 * n7) > 1.0f) {
                            n8 = 1.0f;
                        }
                        float n9 = n8;
                        if (n8 < -1.0f) {
                            n9 = -1.0f;
                        }
                        a = (int)(n9 * 32768.0f);
                    }
                    int n10 = a;
                    if (this.u != 0) {
                        float n11;
                        if ((n11 = a / (float)this.u) > 1.0f) {
                            n11 = 1.0f;
                        }
                        float n12 = n11;
                        if (n11 < -1.0f) {
                            n12 = -1.0f;
                        }
                        n10 = (int)(n12 * 25000.0f);
                    }
                    array[i] = (short)n10;
                    ++n4;
                    ++i;
                }
                a = n3;
            }
        }
        return a;
    }
    
    public final void a() {
        this.D = 0;
    }
    
    public final void a(final double g) {
        this.g = g;
    }
    
    public final void a(final float rateChange) {
        this.G.setRateChange(rateChange);
    }
    
    public final void a(final int pitchSemiTones) {
        this.G.setPitchSemiTones(pitchSemiTones);
    }
    
    public final void b() {
        this.u = 0;
        this.s = 0;
        this.t = 0;
        this.r = 0;
        this.m = false;
        this.l = false;
        this.o = 0;
        this.B = 0;
        for (int i = 0; i < this.w; ++i) {
            this.x[i] = -1;
        }
        this.y = 0;
        this.v = 0;
        this.p = 0;
        this.n = false;
    }
    
    public final void b(final float tempoChange) {
        this.G.setTempoChange(tempoChange);
    }
    
    public final void b(final int c) {
        this.C = c;
    }
    
    public final int c(int n) {
        if (n > this.x.length - 1) {
            n = this.x.length - 1;
        }
        return this.x[n];
    }
    
    public final void c() {
        this.G.flush();
    }
    
    public final void d(final int f) {
        this.f = f;
    }
    
    public final boolean d() {
        return this.l;
    }
    
    public final boolean e() {
        return this.m;
    }
    
    public final int f() {
        return this.r;
    }
}
