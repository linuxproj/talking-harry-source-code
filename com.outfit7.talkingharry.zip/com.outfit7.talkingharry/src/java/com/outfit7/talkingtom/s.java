package com.outfit7.talkingtom;

import android.widget.RelativeLayout$LayoutParams;
import android.os.Message;
import android.widget.TextView;
import android.widget.ImageView;
import android.os.Handler;

final class s extends Handler
{
    ab a;
    private ImageView b;
    private ImageView c;
    private TextView d;
    private Engine e;
    
    public s(final Engine e, final ab a, final ImageView b, final ImageView c, final TextView d) {
        this.e = e;
        this.a = a;
        this.b = b;
        this.d = d;
        this.c = c;
    }
    
    public final void handleMessage(Message message) {
        if (this.a != null) {
            switch (message.what) {
                case 4: {
                    message = (Message)message.obj;
                    if (((at)message).c < this.a.a().a()) {
                        final q a = ((at)message).a;
                        synchronized (a) {
                            ((at)message).a.c = true;
                            ((at)message).a.notify();
                            break;
                        }
                    }
                    while (true) {
                        if (((at)message).h == null) {
                            this.b.setImageBitmap(((at)message).a.a());
                            final q a2;
                            monitorenter(a2 = ((at)message).a);
                            while (true) {
                                Message message2;
                                try {
                                    ((at)message).a.c = true;
                                    ((at)message).a.notify();
                                    monitorexit(a2);
                                    monitorenter(message2 = message);
                                    final Message message3 = message;
                                    final boolean b = true;
                                    ((at)message3).g = b;
                                    final Message message4 = message;
                                    message4.notify();
                                    final Message message5 = message2;
                                    monitorexit(message5);
                                    final s s = this;
                                    final Engine engine = s.e;
                                    final ad ad = engine.t;
                                    final Message message6 = message;
                                    ad.a((at)message6);
                                    break;
                                }
                                finally {
                                    final Message message7;
                                    message = message7;
                                    monitorexit(a2);
                                }
                                try {
                                    final Message message3 = message;
                                    final boolean b = true;
                                    ((at)message3).g = b;
                                    final Message message4 = message;
                                    message4.notify();
                                    final Message message5 = message2;
                                    monitorexit(message5);
                                    final s s = this;
                                    final Engine engine = s.e;
                                    final ad ad = engine.t;
                                    final Message message6 = message;
                                    ad.a((at)message6);
                                    break;
                                    ((at)message).h.setImageBitmap(((at)message).a.a());
                                    ((at)message).a.b = (RelativeLayout$LayoutParams)((at)message).h.getLayoutParams();
                                    continue;
                                }
                                finally {
                                    monitorexit(message2);
                                }
                                break;
                            }
                        }
                        continue;
                    }
                }
                case 10: {
                    final ac ac = (ac)message.obj;
                    this.c.setBackgroundDrawable(ac.a);
                    if (ac.b == null) {
                        this.d.setVisibility(8);
                        break;
                    }
                    final int int1 = Integer.parseInt(ac.b);
                    if (int1 > 10) {
                        this.d.setVisibility(8);
                        break;
                    }
                    this.d.setVisibility(0);
                    this.d.setText((CharSequence)String.format("%2d", new Object[] { int1 }));
                    break;
                }
                case 21: {
                    this.d.setVisibility(0);
                    this.d.setText((CharSequence)"");
                    break;
                }
                case 5: {
                    final as as = (as)message.obj;
                    ((ImageView)this.e.a.findViewById(2131296262)).setImageResource(as.a);
                    this.e.t.a(as.a);
                    break;
                }
                case 22: {
                    this.e.t.a((RelativeLayout$LayoutParams)((ImageView)message.obj).getLayoutParams());
                    break;
                }
            }
        }
    }
}
