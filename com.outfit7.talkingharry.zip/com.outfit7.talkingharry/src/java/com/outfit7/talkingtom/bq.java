package com.outfit7.talkingtom;

import android.app.Activity;
import android.view.View;
import android.view.View$OnClickListener;

final class bq implements View$OnClickListener
{
    final Main a;
    
    bq(final Main a) {
        this.a = a;
    }
    
    public final void onClick(final View view) {
        final Engine a = this.a.c;
        a.getClass();
        final br br = new br(this, a, "gozd/dez", this.a);
        br.b = 5;
        br.d = true;
        this.a.c.c.a().sendMessage(this.a.c.c.a().obtainMessage(0, (Object)br));
    }
}
