package com.outfit7.talkingtom;

import android.view.View;
import android.view.View$OnClickListener;

final class fv implements View$OnClickListener
{
    private YouTubeLoginActivity a;
    
    fv(final YouTubeLoginActivity a) {
        this.a = a;
    }
    
    public final void onClick(final View view) {
        this.a.setResult(2);
        this.a.finish();
    }
}
