package com.outfit7.talkingtom;

final class fu implements Runnable
{
    private ft a;
    
    fu(final ft a) {
        this.a = a;
    }
    
    public final void run() {
        VideoUploadedToFbActivity.a(this.a.a.a);
    }
}
