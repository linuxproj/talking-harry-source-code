package com.outfit7.talkingtom;

import java.util.LinkedList;
import java.util.List;

abstract class dt
{
    private int a;
    protected List b;
    final Main c;
    
    private dt(final Main c, final byte b) {
        this.c = c;
        this.b = (List)new LinkedList();
    }
    
    void a() {
    }
    
    void b() {
    }
    
    boolean c() {
        synchronized (this) {
            boolean b;
            if (this.a != 0) {
                b = false;
            }
            else {
                ++this.a;
                b = true;
            }
            return b;
        }
    }
    
    boolean e() {
        synchronized (this) {
            boolean b;
            if (this.a == 0) {
                b = false;
            }
            else {
                --this.a;
                this.a();
                this.f();
                final Engine a = this.c.c;
                a.getClass();
                final du du = new du(a);
                du.b = Integer.MAX_VALUE;
                this.c.c.c.a().sendMessage(this.c.c.c.a().obtainMessage(0, (Object)du));
                b = true;
            }
            return b;
        }
    }
    
    final void f() {
        this.c.c.b.post((Runnable)new dv(this));
    }
}
