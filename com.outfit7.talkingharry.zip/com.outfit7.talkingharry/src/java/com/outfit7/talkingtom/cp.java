package com.outfit7.talkingtom;

import android.app.Activity;

final class cp extends n
{
    private cl m;
    
    cp(final cl m, final Engine engine, final String s, final Activity activity) {
        this.m = m;
        engine.getClass();
        super(engine, s, activity);
    }
    
    @Override
    public final void j() {
        super.j();
        this.a(0, 19);
        this.a(0).b = "swoosh_0" + this.m.a.c.a(1, 3);
    }
    
    @Override
    public final void k() {
        super.k();
    }
}
