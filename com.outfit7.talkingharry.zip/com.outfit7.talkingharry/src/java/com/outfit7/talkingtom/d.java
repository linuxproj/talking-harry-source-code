package com.outfit7.talkingtom;

import android.app.Activity;

final class d extends Thread
{
    private Activity a;
    private boolean b;
    
    d(final Activity a, final boolean b) {
        this.a = a;
        this.b = b;
    }
    
    public final void run() {
        try {
            com.outfit7.talkingtom.b.a.sendMessage(com.outfit7.talkingtom.b.a.obtainMessage(3, (Object)com.outfit7.talkingtom.b.a(this.b, (TalkingTomApplication)this.a.getApplicationContext(), TalkingTomApplication.j(), TalkingTomApplication.k(), com.outfit7.talkingtom.b.a, TalkingTomApplication.l(), TalkingTomApplication.m(), TalkingTomApplication.n(), this.a)));
        }
        catch (final Exception ex) {
            com.outfit7.talkingtom.b.a.sendMessage(com.outfit7.talkingtom.b.a.obtainMessage(15, (Object)ex));
        }
    }
}
