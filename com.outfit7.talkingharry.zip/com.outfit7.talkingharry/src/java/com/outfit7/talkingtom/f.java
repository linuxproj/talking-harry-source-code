package com.outfit7.talkingtom;

public class f
{
    public void a(final g g) {
    }
    
    public void a(final Throwable t) {
    }
}
