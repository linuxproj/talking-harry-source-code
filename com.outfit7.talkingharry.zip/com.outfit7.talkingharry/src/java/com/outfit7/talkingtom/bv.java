package com.outfit7.talkingtom;

final class bv implements Runnable
{
    private Main a;
    
    bv(final Main a) {
        this.a = a;
    }
    
    public final void run() {
        if (this.a.p == null) {
            this.a.p = new cl(this.a);
        }
        this.a.p.c();
        this.a.n = this.a.p;
    }
}
