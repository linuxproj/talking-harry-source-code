package com.outfit7.talkingtom;

final class aj implements Runnable
{
    private ah a;
    
    aj(final ah a) {
        this.a = a;
    }
    
    public final void run() {
        this.a.i.findViewById(2131296264).bringToFront();
    }
}
