package com.outfit7.talkingtom;

import android.content.DialogInterface;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface$OnClickListener;

final class ex implements DialogInterface$OnClickListener
{
    private fd a;
    private ProgressDialog b;
    private Activity c;
    
    ex(final fd a, final ProgressDialog b, final Activity c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    public final void onClick(final DialogInterface dialogInterface, final int n) {
        this.a.a();
        this.b.cancel();
        ((BackgroundActivity)this.c).a().sendEmptyMessage(2);
    }
}
