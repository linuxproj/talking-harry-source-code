package com.outfit7.talkingtom;

import android.graphics.Bitmap;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

final class am implements Runnable
{
    private ImageView a;
    
    am(final ImageView a) {
        this.a = a;
    }
    
    public final void run() {
        ((ViewGroup)this.a.getParent()).removeView((View)this.a);
        this.a.setImageBitmap((Bitmap)null);
    }
}
