package com.outfit7.talkingtom;

import android.content.Context;
import android.content.SharedPreferences;
import com.a.a.e;
import com.outfit7.a.d;
import com.outfit7.a.a;
import android.os.Handler;
import android.app.Activity;

final class fb extends Thread
{
    private TalkingTomApplication a;
    private Activity b;
    private aw c;
    private String d;
    private Handler e;
    
    fb(final TalkingTomApplication a, final Activity b, final aw c, final String d, final Handler e) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
    }
    
    public final void run() {
        while (true) {
            final String absolutePath = this.a.c().getAbsolutePath();
            while (true) {
                Label_0206: {
                    try {
                        final e a = this.a.a();
                        if (!a.a()) {
                            final SharedPreferences sharedPreferences = ((Context)this.b).getSharedPreferences("facebook-session", 0);
                            a.a(sharedPreferences.getString("access_token", (String)null));
                            a.a(sharedPreferences.getLong("expires_in", 0L));
                        }
                        this.e.sendMessage(this.e.obtainMessage(5, (Object)com.a.a.a.b(this.c.a(absolutePath, this.b.getString(2131099649), this.d, "video/avi", new fc(this.e))).getString("link")));
                        return;
                    }
                    catch (final Throwable t) {
                        String s = this.b.getString(2131099684);
                        if (t.getLocalizedMessage() != null) {
                            s = s + " " + t.getLocalizedMessage();
                            this.e.sendMessage(this.e.obtainMessage(4, (Object)s));
                            return;
                        }
                        break Label_0206;
                    }
                    catch (final d d) {
                        return;
                    }
                }
                continue;
            }
        }
    }
}
