package com.outfit7.talkingtom;

import android.util.Log;
import android.content.Context;

final class ei extends Thread
{
    private Preferences a;
    
    ei(final Preferences a) {
        this.a = a;
    }
    
    public final void run() {
        try {
            ((TalkingTomApplication)this.a.getApplicationContext()).a().a((Context)this.a);
        }
        catch (final Exception ex) {
            Log.w(Preferences.a, ex.getMessage(), (Throwable)ex);
        }
    }
}
