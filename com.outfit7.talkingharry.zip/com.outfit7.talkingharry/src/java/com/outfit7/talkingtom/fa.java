package com.outfit7.talkingtom;

import android.content.DialogInterface;
import android.os.Handler;
import android.content.DialogInterface$OnCancelListener;

final class fa implements DialogInterface$OnCancelListener
{
    private Handler a;
    
    fa(final Handler a) {
        this.a = a;
    }
    
    public final void onCancel(final DialogInterface dialogInterface) {
        this.a.sendEmptyMessage(3);
    }
}
