package com.outfit7.talkingtom;

import android.graphics.drawable.Drawable;
import org.json.JSONObject;
import android.widget.ImageView;
import java.net.URL;
import org.json.JSONArray;

final class dg extends Thread
{
    private boolean a;
    private de b;
    
    dg(final de b, final boolean a) {
        this.b = b;
        this.a = a;
    }
    
    public final void run() {
        while (true) {
            while (true) {
                Label_0233: {
                    while (true) {
                        try {
                            if (this.a) {
                                this.b.a.b();
                            }
                            final JSONArray jsonArray = new JSONArray(this.b.b.getString("gridData", (String)null));
                            de de;
                            if (jsonArray.length() == 0) {
                                de = this.b;
                            }
                            else {
                                int i = 0;
                                String string = null;
                                while (i < jsonArray.length()) {
                                    final JSONObject jsonObject = jsonArray.getJSONObject(i);
                                    if (this.b.a.getPackageName().equals((Object)jsonObject.getString("friendId"))) {
                                        string = jsonObject.getString("gridButtonUrl");
                                    }
                                    ++i;
                                }
                                if (string != null) {
                                    break Label_0233;
                                }
                                final String string2 = jsonArray.getJSONObject(0).getString("gridButtonUrl");
                                final Drawable a = this.b.a.a(new URL(string2.replace((CharSequence)"60.png", (CharSequence)"120.png")));
                                if (a == null) {
                                    de = this.b;
                                }
                                else {
                                    final ImageView imageView = (ImageView)this.b.a.findViewById(2131296273);
                                    imageView.setImageDrawable(a);
                                    imageView.setVisibility(0);
                                    de = this.b;
                                }
                            }
                            de.c = null;
                            return;
                        }
                        catch (final Exception ex) {
                            final de de = this.b;
                            continue;
                        }
                        finally {
                            this.b.c = null;
                        }
                        break;
                    }
                }
                continue;
            }
        }
    }
}
