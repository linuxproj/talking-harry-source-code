package com.outfit7.talkingtom;

final class ah extends m
{
    final AnimationPlayer i;
    final ad j;
    private s k;
    
    ah(final ad j, final AnimationPlayer i, final s k) {
        this.j = j;
        this.i = i;
        this.k = k;
        super(j.b);
    }
    
    public final void a() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getfield        com/outfit7/talkingtom/ah.j:Lcom/outfit7/talkingtom/ad;
        //     4: getfield        com/outfit7/talkingtom/ad.b:Lcom/outfit7/talkingtom/Engine;
        //     7: invokestatic    com/outfit7/talkingtom/Engine.a:(Lcom/outfit7/talkingtom/Engine;)Lcom/outfit7/talkingtom/u;
        //    10: invokevirtual   com/outfit7/talkingtom/u.c:()V
        //    13: new             Ljava/util/HashMap;
        //    16: dup            
        //    17: invokespecial   java/util/HashMap.<init>:()V
        //    20: astore          8
        //    22: bipush          -8
        //    24: invokestatic    android/os/Process.setThreadPriority:(I)V
        //    27: iconst_0       
        //    28: istore_1       
        //    29: aconst_null    
        //    30: astore          4
        //    32: aconst_null    
        //    33: astore_3       
        //    34: iload_1        
        //    35: aload_0        
        //    36: getfield        com/outfit7/talkingtom/ah.j:Lcom/outfit7/talkingtom/ad;
        //    39: invokestatic    com/outfit7/talkingtom/ad.c:(Lcom/outfit7/talkingtom/ad;)I
        //    42: if_icmpge       961
        //    45: new             Lcom/outfit7/talkingtom/r;
        //    48: astore          9
        //    50: aload           9
        //    52: aload_0        
        //    53: getfield        com/outfit7/talkingtom/ah.j:Lcom/outfit7/talkingtom/ad;
        //    56: getfield        com/outfit7/talkingtom/ad.b:Lcom/outfit7/talkingtom/Engine;
        //    59: invokespecial   com/outfit7/talkingtom/r.<init>:(Lcom/outfit7/talkingtom/Engine;)V
        //    62: aload_0        
        //    63: getfield        com/outfit7/talkingtom/ah.a:Z
        //    66: ifne            961
        //    69: aload_0        
        //    70: getfield        com/outfit7/talkingtom/ah.j:Lcom/outfit7/talkingtom/ad;
        //    73: invokestatic    com/outfit7/talkingtom/ad.f:(Lcom/outfit7/talkingtom/ad;)[I
        //    76: iload_1        
        //    77: iaload         
        //    78: ifeq            106
        //    81: aload_0        
        //    82: getfield        com/outfit7/talkingtom/ah.i:Lcom/outfit7/talkingtom/AnimationPlayer;
        //    85: astore          6
        //    87: new             Lcom/outfit7/talkingtom/ai;
        //    90: astore          5
        //    92: aload           5
        //    94: aload_0        
        //    95: iload_1        
        //    96: invokespecial   com/outfit7/talkingtom/ai.<init>:(Lcom/outfit7/talkingtom/ah;I)V
        //    99: aload           6
        //   101: aload           5
        //   103: invokevirtual   com/outfit7/talkingtom/AnimationPlayer.runOnUiThread:(Ljava/lang/Runnable;)V
        //   106: aload_0        
        //   107: getfield        com/outfit7/talkingtom/ah.j:Lcom/outfit7/talkingtom/ad;
        //   110: invokestatic    com/outfit7/talkingtom/ad.g:(Lcom/outfit7/talkingtom/ad;)[Lcom/outfit7/talkingtom/q;
        //   113: iload_1        
        //   114: aaload         
        //   115: ifnull          1044
        //   118: new             Lcom/outfit7/talkingtom/at;
        //   121: astore          5
        //   123: aload           5
        //   125: aload_0        
        //   126: getfield        com/outfit7/talkingtom/ah.j:Lcom/outfit7/talkingtom/ad;
        //   129: invokestatic    com/outfit7/talkingtom/ad.g:(Lcom/outfit7/talkingtom/ad;)[Lcom/outfit7/talkingtom/q;
        //   132: iload_1        
        //   133: aaload         
        //   134: iconst_0       
        //   135: ldc             "playback"
        //   137: sipush          300
        //   140: invokespecial   com/outfit7/talkingtom/at.<init>:(Lcom/outfit7/talkingtom/q;ZLjava/lang/String;I)V
        //   143: aload_0        
        //   144: getfield        com/outfit7/talkingtom/ah.k:Lcom/outfit7/talkingtom/s;
        //   147: aload_0        
        //   148: getfield        com/outfit7/talkingtom/ah.k:Lcom/outfit7/talkingtom/s;
        //   151: iconst_4       
        //   152: aload           5
        //   154: invokevirtual   com/outfit7/talkingtom/s.obtainMessage:(ILjava/lang/Object;)Landroid/os/Message;
        //   157: invokevirtual   com/outfit7/talkingtom/s.sendMessage:(Landroid/os/Message;)Z
        //   160: pop            
        //   161: aload_0        
        //   162: getfield        com/outfit7/talkingtom/ah.j:Lcom/outfit7/talkingtom/ad;
        //   165: invokestatic    com/outfit7/talkingtom/ad.h:(Lcom/outfit7/talkingtom/ad;)[Z
        //   168: iload_1        
        //   169: baload         
        //   170: ifeq            197
        //   173: aload_0        
        //   174: getfield        com/outfit7/talkingtom/ah.i:Lcom/outfit7/talkingtom/AnimationPlayer;
        //   177: astore          6
        //   179: new             Lcom/outfit7/talkingtom/aj;
        //   182: astore          7
        //   184: aload           7
        //   186: aload_0        
        //   187: invokespecial   com/outfit7/talkingtom/aj.<init>:(Lcom/outfit7/talkingtom/ah;)V
        //   190: aload           6
        //   192: aload           7
        //   194: invokevirtual   com/outfit7/talkingtom/AnimationPlayer.runOnUiThread:(Ljava/lang/Runnable;)V
        //   197: aload_0        
        //   198: getfield        com/outfit7/talkingtom/ah.j:Lcom/outfit7/talkingtom/ad;
        //   201: invokestatic    com/outfit7/talkingtom/ad.i:(Lcom/outfit7/talkingtom/ad;)[Ljava/util/List;
        //   204: iload_1        
        //   205: aaload         
        //   206: astore          6
        //   208: aload           6
        //   210: ifnull          553
        //   213: aload           6
        //   215: invokeinterface java/util/List.iterator:()Ljava/util/Iterator;
        //   220: astore          10
        //   222: aload           10
        //   224: invokeinterface java/util/Iterator.hasNext:()Z
        //   229: ifeq            553
        //   232: aload           10
        //   234: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //   239: checkcast       Lcom/outfit7/talkingtom/q;
        //   242: astore          11
        //   244: aload_0        
        //   245: getfield        com/outfit7/talkingtom/ah.i:Lcom/outfit7/talkingtom/AnimationPlayer;
        //   248: ldc             2131296263
        //   250: invokevirtual   com/outfit7/talkingtom/AnimationPlayer.findViewById:(I)Landroid/view/View;
        //   253: checkcast       Landroid/widget/RelativeLayout;
        //   256: astore          12
        //   258: aload           8
        //   260: aload           11
        //   262: getfield        com/outfit7/talkingtom/q.b:Landroid/widget/RelativeLayout$LayoutParams;
        //   265: invokeinterface java/util/Map.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //   270: checkcast       Landroid/widget/ImageView;
        //   273: astore          7
        //   275: aload           11
        //   277: getfield        com/outfit7/talkingtom/q.a:Ljava/lang/String;
        //   280: ifnonnull       402
        //   283: aload           7
        //   285: ifnull          222
        //   288: aload           8
        //   290: aload           11
        //   292: getfield        com/outfit7/talkingtom/q.b:Landroid/widget/RelativeLayout$LayoutParams;
        //   295: invokeinterface java/util/Map.remove:(Ljava/lang/Object;)Ljava/lang/Object;
        //   300: pop            
        //   301: aload_0        
        //   302: getfield        com/outfit7/talkingtom/ah.i:Lcom/outfit7/talkingtom/AnimationPlayer;
        //   305: astore          11
        //   307: new             Lcom/outfit7/talkingtom/ak;
        //   310: astore          6
        //   312: aload           6
        //   314: aload           12
        //   316: aload           7
        //   318: invokespecial   com/outfit7/talkingtom/ak.<init>:(Landroid/widget/RelativeLayout;Landroid/widget/ImageView;)V
        //   321: aload           11
        //   323: aload           6
        //   325: invokevirtual   com/outfit7/talkingtom/AnimationPlayer.runOnUiThread:(Ljava/lang/Runnable;)V
        //   328: goto            222
        //   331: astore          6
        //   333: aload_3        
        //   334: astore          5
        //   336: aload           6
        //   338: astore_3       
        //   339: aload           8
        //   341: invokeinterface java/util/Map.values:()Ljava/util/Collection;
        //   346: invokeinterface java/util/Collection.iterator:()Ljava/util/Iterator;
        //   351: astore          7
        //   353: aload           7
        //   355: invokeinterface java/util/Iterator.hasNext:()Z
        //   360: ifeq            774
        //   363: aload           7
        //   365: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //   370: checkcast       Landroid/widget/ImageView;
        //   373: astore          6
        //   375: aload           6
        //   377: invokevirtual   android/widget/ImageView.getParent:()Landroid/view/ViewParent;
        //   380: ifnull          353
        //   383: aload_0        
        //   384: getfield        com/outfit7/talkingtom/ah.i:Lcom/outfit7/talkingtom/AnimationPlayer;
        //   387: new             Lcom/outfit7/talkingtom/am;
        //   390: dup            
        //   391: aload           6
        //   393: invokespecial   com/outfit7/talkingtom/am.<init>:(Landroid/widget/ImageView;)V
        //   396: invokevirtual   com/outfit7/talkingtom/AnimationPlayer.runOnUiThread:(Ljava/lang/Runnable;)V
        //   399: goto            353
        //   402: aload           7
        //   404: astore          6
        //   406: aload           7
        //   408: ifnonnull       448
        //   411: new             Landroid/widget/ImageView;
        //   414: astore          6
        //   416: aload           6
        //   418: aload_0        
        //   419: getfield        com/outfit7/talkingtom/ah.i:Lcom/outfit7/talkingtom/AnimationPlayer;
        //   422: invokespecial   android/widget/ImageView.<init>:(Landroid/content/Context;)V
        //   425: aload           6
        //   427: getstatic       android/widget/ImageView$ScaleType.FIT_XY:Landroid/widget/ImageView$ScaleType;
        //   430: invokevirtual   android/widget/ImageView.setScaleType:(Landroid/widget/ImageView$ScaleType;)V
        //   433: aload           8
        //   435: aload           11
        //   437: getfield        com/outfit7/talkingtom/q.b:Landroid/widget/RelativeLayout$LayoutParams;
        //   440: aload           6
        //   442: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   447: pop            
        //   448: aload           6
        //   450: invokevirtual   android/widget/ImageView.getParent:()Landroid/view/ViewParent;
        //   453: ifnonnull       499
        //   456: aload           6
        //   458: dup            
        //   459: astore          14
        //   461: monitorenter   
        //   462: aload_0        
        //   463: getfield        com/outfit7/talkingtom/ah.i:Lcom/outfit7/talkingtom/AnimationPlayer;
        //   466: astore          13
        //   468: new             Lcom/outfit7/talkingtom/al;
        //   471: astore          7
        //   473: aload           7
        //   475: aload           6
        //   477: aload           12
        //   479: aload           11
        //   481: invokespecial   com/outfit7/talkingtom/al.<init>:(Landroid/widget/ImageView;Landroid/widget/RelativeLayout;Lcom/outfit7/talkingtom/q;)V
        //   484: aload           13
        //   486: aload           7
        //   488: invokevirtual   com/outfit7/talkingtom/AnimationPlayer.runOnUiThread:(Ljava/lang/Runnable;)V
        //   491: aload           6
        //   493: invokevirtual   java/lang/Object.wait:()V
        //   496: aload           14
        //   498: monitorexit    
        //   499: new             Lcom/outfit7/talkingtom/at;
        //   502: astore          7
        //   504: aload           7
        //   506: aload           11
        //   508: iconst_0       
        //   509: ldc             "playback"
        //   511: sipush          300
        //   514: invokespecial   com/outfit7/talkingtom/at.<init>:(Lcom/outfit7/talkingtom/q;ZLjava/lang/String;I)V
        //   517: aload           7
        //   519: aload           6
        //   521: putfield        com/outfit7/talkingtom/at.h:Landroid/widget/ImageView;
        //   524: aload_0        
        //   525: getfield        com/outfit7/talkingtom/ah.k:Lcom/outfit7/talkingtom/s;
        //   528: aload_0        
        //   529: getfield        com/outfit7/talkingtom/ah.k:Lcom/outfit7/talkingtom/s;
        //   532: iconst_4       
        //   533: aload           7
        //   535: invokevirtual   com/outfit7/talkingtom/s.obtainMessage:(ILjava/lang/Object;)Landroid/os/Message;
        //   538: invokevirtual   com/outfit7/talkingtom/s.sendMessage:(Landroid/os/Message;)Z
        //   541: pop            
        //   542: goto            222
        //   545: astore          5
        //   547: aload           14
        //   549: monitorexit    
        //   550: aload           5
        //   552: athrow         
        //   553: aload_0        
        //   554: getfield        com/outfit7/talkingtom/ah.j:Lcom/outfit7/talkingtom/ad;
        //   557: invokestatic    com/outfit7/talkingtom/ad.j:(Lcom/outfit7/talkingtom/ad;)[Lcom/outfit7/talkingtom/ap;
        //   560: iload_1        
        //   561: aaload         
        //   562: ifnull          689
        //   565: aload           4
        //   567: ifnull          575
        //   570: aload           4
        //   572: invokevirtual   com/outfit7/talkingtom/ap.d:()V
        //   575: aload           5
        //   577: ifnull          604
        //   580: aload           5
        //   582: dup            
        //   583: astore          15
        //   585: monitorenter   
        //   586: aload           5
        //   588: getfield        com/outfit7/talkingtom/at.g:Z
        //   591: istore_2       
        //   592: iload_2        
        //   593: ifne            601
        //   596: aload           5
        //   598: invokevirtual   java/lang/Object.wait:()V
        //   601: aload           15
        //   603: monitorexit    
        //   604: aload_0        
        //   605: getfield        com/outfit7/talkingtom/ah.j:Lcom/outfit7/talkingtom/ad;
        //   608: invokestatic    com/outfit7/talkingtom/ad.j:(Lcom/outfit7/talkingtom/ad;)[Lcom/outfit7/talkingtom/ap;
        //   611: iload_1        
        //   612: aaload         
        //   613: astore          5
        //   615: aload           5
        //   617: getfield        com/outfit7/talkingtom/ap.g:Lcom/outfit7/talkingtom/Engine;
        //   620: invokestatic    com/outfit7/talkingtom/Engine.a:(Lcom/outfit7/talkingtom/Engine;)Lcom/outfit7/talkingtom/u;
        //   623: invokestatic    com/outfit7/talkingtom/u.c:(Lcom/outfit7/talkingtom/u;)Lcom/outfit7/talkingtom/z;
        //   626: aload           5
        //   628: invokevirtual   com/outfit7/talkingtom/z.a:(Lcom/outfit7/talkingtom/ap;)V
        //   631: aload_0        
        //   632: getfield        com/outfit7/talkingtom/ah.j:Lcom/outfit7/talkingtom/ad;
        //   635: invokestatic    com/outfit7/talkingtom/ad.j:(Lcom/outfit7/talkingtom/ad;)[Lcom/outfit7/talkingtom/ap;
        //   638: iload_1        
        //   639: aaload         
        //   640: astore          5
        //   642: aload           5
        //   644: astore          4
        //   646: aload_0        
        //   647: getfield        com/outfit7/talkingtom/ah.j:Lcom/outfit7/talkingtom/ad;
        //   650: invokestatic    com/outfit7/talkingtom/ad.l:(Lcom/outfit7/talkingtom/ad;)[I
        //   653: iload_1        
        //   654: iaload         
        //   655: iconst_m1      
        //   656: if_icmpne       717
        //   659: aload_3        
        //   660: ifnull          1038
        //   663: aload_3        
        //   664: invokevirtual   android/os/Vibrator.cancel:()V
        //   667: aload_3        
        //   668: astore          5
        //   670: aload           9
        //   672: invokevirtual   com/outfit7/talkingtom/r.c:()V
        //   675: iinc            1, 1
        //   678: goto            34
        //   681: astore          6
        //   683: aload           15
        //   685: monitorexit    
        //   686: aload           6
        //   688: athrow         
        //   689: aload_0        
        //   690: getfield        com/outfit7/talkingtom/ah.j:Lcom/outfit7/talkingtom/ad;
        //   693: invokestatic    com/outfit7/talkingtom/ad.k:(Lcom/outfit7/talkingtom/ad;)[Z
        //   696: iload_1        
        //   697: baload         
        //   698: ifeq            1041
        //   701: aload           4
        //   703: ifnull          1041
        //   706: aload           4
        //   708: invokevirtual   com/outfit7/talkingtom/ap.d:()V
        //   711: aconst_null    
        //   712: astore          4
        //   714: goto            646
        //   717: aload_0        
        //   718: getfield        com/outfit7/talkingtom/ah.j:Lcom/outfit7/talkingtom/ad;
        //   721: invokestatic    com/outfit7/talkingtom/ad.l:(Lcom/outfit7/talkingtom/ad;)[I
        //   724: iload_1        
        //   725: iaload         
        //   726: ifle            1038
        //   729: aload_3        
        //   730: ifnonnull       1035
        //   733: aload_0        
        //   734: getfield        com/outfit7/talkingtom/ah.i:Lcom/outfit7/talkingtom/AnimationPlayer;
        //   737: ldc             "vibrator"
        //   739: invokevirtual   com/outfit7/talkingtom/AnimationPlayer.getSystemService:(Ljava/lang/String;)Ljava/lang/Object;
        //   742: checkcast       Landroid/os/Vibrator;
        //   745: astore          5
        //   747: aload           5
        //   749: astore_3       
        //   750: aload_3        
        //   751: astore          5
        //   753: aload_3        
        //   754: aload_0        
        //   755: getfield        com/outfit7/talkingtom/ah.j:Lcom/outfit7/talkingtom/ad;
        //   758: invokestatic    com/outfit7/talkingtom/ad.l:(Lcom/outfit7/talkingtom/ad;)[I
        //   761: iload_1        
        //   762: iaload         
        //   763: i2l            
        //   764: invokevirtual   android/os/Vibrator.vibrate:(J)V
        //   767: goto            667
        //   770: astore_3       
        //   771: goto            339
        //   774: aload           5
        //   776: ifnull          784
        //   779: aload           5
        //   781: invokevirtual   android/os/Vibrator.cancel:()V
        //   784: aload           4
        //   786: ifnull          794
        //   789: aload           4
        //   791: invokevirtual   com/outfit7/talkingtom/ap.d:()V
        //   794: aload_0        
        //   795: getfield        com/outfit7/talkingtom/ah.k:Lcom/outfit7/talkingtom/s;
        //   798: aload_0        
        //   799: getfield        com/outfit7/talkingtom/ah.k:Lcom/outfit7/talkingtom/s;
        //   802: iconst_4       
        //   803: new             Lcom/outfit7/talkingtom/at;
        //   806: dup            
        //   807: new             Lcom/outfit7/talkingtom/q;
        //   810: dup            
        //   811: aload_0        
        //   812: getfield        com/outfit7/talkingtom/ah.j:Lcom/outfit7/talkingtom/ad;
        //   815: getfield        com/outfit7/talkingtom/ad.b:Lcom/outfit7/talkingtom/Engine;
        //   818: aload_0        
        //   819: getfield        com/outfit7/talkingtom/ah.j:Lcom/outfit7/talkingtom/ad;
        //   822: getfield        com/outfit7/talkingtom/ad.b:Lcom/outfit7/talkingtom/Engine;
        //   825: invokestatic    com/outfit7/talkingtom/Engine.f:(Lcom/outfit7/talkingtom/Engine;)Lcom/outfit7/talkingtom/ar;
        //   828: invokeinterface com/outfit7/talkingtom/ar.b:()I
        //   833: invokespecial   com/outfit7/talkingtom/q.<init>:(Lcom/outfit7/talkingtom/Engine;I)V
        //   836: iconst_1       
        //   837: ldc_w           "base"
        //   840: iconst_4       
        //   841: invokespecial   com/outfit7/talkingtom/at.<init>:(Lcom/outfit7/talkingtom/q;ZLjava/lang/String;I)V
        //   844: invokevirtual   com/outfit7/talkingtom/s.obtainMessage:(ILjava/lang/Object;)Landroid/os/Message;
        //   847: invokevirtual   com/outfit7/talkingtom/s.sendMessage:(Landroid/os/Message;)Z
        //   850: pop            
        //   851: aload_0        
        //   852: getfield        com/outfit7/talkingtom/ah.j:Lcom/outfit7/talkingtom/ad;
        //   855: aload_0        
        //   856: getfield        com/outfit7/talkingtom/ah.i:Lcom/outfit7/talkingtom/AnimationPlayer;
        //   859: invokevirtual   com/outfit7/talkingtom/ad.b:(Lcom/outfit7/talkingtom/AnimationPlayer;)V
        //   862: aload_3        
        //   863: athrow         
        //   864: astore          7
        //   866: goto            496
        //   869: astore          6
        //   871: goto            601
        //   874: aload_3        
        //   875: ifnull          882
        //   878: aload_3        
        //   879: invokevirtual   android/os/Vibrator.cancel:()V
        //   882: aload           4
        //   884: ifnull          892
        //   887: aload           4
        //   889: invokevirtual   com/outfit7/talkingtom/ap.d:()V
        //   892: aload_0        
        //   893: getfield        com/outfit7/talkingtom/ah.k:Lcom/outfit7/talkingtom/s;
        //   896: aload_0        
        //   897: getfield        com/outfit7/talkingtom/ah.k:Lcom/outfit7/talkingtom/s;
        //   900: iconst_4       
        //   901: new             Lcom/outfit7/talkingtom/at;
        //   904: dup            
        //   905: new             Lcom/outfit7/talkingtom/q;
        //   908: dup            
        //   909: aload_0        
        //   910: getfield        com/outfit7/talkingtom/ah.j:Lcom/outfit7/talkingtom/ad;
        //   913: getfield        com/outfit7/talkingtom/ad.b:Lcom/outfit7/talkingtom/Engine;
        //   916: aload_0        
        //   917: getfield        com/outfit7/talkingtom/ah.j:Lcom/outfit7/talkingtom/ad;
        //   920: getfield        com/outfit7/talkingtom/ad.b:Lcom/outfit7/talkingtom/Engine;
        //   923: invokestatic    com/outfit7/talkingtom/Engine.f:(Lcom/outfit7/talkingtom/Engine;)Lcom/outfit7/talkingtom/ar;
        //   926: invokeinterface com/outfit7/talkingtom/ar.b:()I
        //   931: invokespecial   com/outfit7/talkingtom/q.<init>:(Lcom/outfit7/talkingtom/Engine;I)V
        //   934: iconst_1       
        //   935: ldc_w           "base"
        //   938: iconst_4       
        //   939: invokespecial   com/outfit7/talkingtom/at.<init>:(Lcom/outfit7/talkingtom/q;ZLjava/lang/String;I)V
        //   942: invokevirtual   com/outfit7/talkingtom/s.obtainMessage:(ILjava/lang/Object;)Landroid/os/Message;
        //   945: invokevirtual   com/outfit7/talkingtom/s.sendMessage:(Landroid/os/Message;)Z
        //   948: pop            
        //   949: aload_0        
        //   950: getfield        com/outfit7/talkingtom/ah.j:Lcom/outfit7/talkingtom/ad;
        //   953: aload_0        
        //   954: getfield        com/outfit7/talkingtom/ah.i:Lcom/outfit7/talkingtom/AnimationPlayer;
        //   957: invokevirtual   com/outfit7/talkingtom/ad.b:(Lcom/outfit7/talkingtom/AnimationPlayer;)V
        //   960: return         
        //   961: aload           8
        //   963: invokeinterface java/util/Map.values:()Ljava/util/Collection;
        //   968: invokeinterface java/util/Collection.iterator:()Ljava/util/Iterator;
        //   973: astore          5
        //   975: aload           5
        //   977: invokeinterface java/util/Iterator.hasNext:()Z
        //   982: ifeq            874
        //   985: aload           5
        //   987: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //   992: checkcast       Landroid/widget/ImageView;
        //   995: astore          6
        //   997: aload           6
        //   999: invokevirtual   android/widget/ImageView.getParent:()Landroid/view/ViewParent;
        //  1002: ifnull          975
        //  1005: aload_0        
        //  1006: getfield        com/outfit7/talkingtom/ah.i:Lcom/outfit7/talkingtom/AnimationPlayer;
        //  1009: new             Lcom/outfit7/talkingtom/am;
        //  1012: dup            
        //  1013: aload           6
        //  1015: invokespecial   com/outfit7/talkingtom/am.<init>:(Landroid/widget/ImageView;)V
        //  1018: invokevirtual   com/outfit7/talkingtom/AnimationPlayer.runOnUiThread:(Ljava/lang/Runnable;)V
        //  1021: goto            975
        //  1024: astore          6
        //  1026: aload_3        
        //  1027: astore          5
        //  1029: aload           6
        //  1031: astore_3       
        //  1032: goto            339
        //  1035: goto            750
        //  1038: goto            667
        //  1041: goto            646
        //  1044: aconst_null    
        //  1045: astore          5
        //  1047: goto            161
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  34     106    331    339    Any
        //  106    161    331    339    Any
        //  161    197    331    339    Any
        //  197    208    331    339    Any
        //  213    222    331    339    Any
        //  222    283    331    339    Any
        //  288    328    331    339    Any
        //  411    448    331    339    Any
        //  448    462    331    339    Any
        //  462    491    545    553    Any
        //  491    496    864    869    Ljava/lang/InterruptedException;
        //  491    496    545    553    Any
        //  496    499    545    553    Any
        //  499    542    331    339    Any
        //  547    553    331    339    Any
        //  553    565    331    339    Any
        //  570    575    331    339    Any
        //  580    586    331    339    Any
        //  586    592    681    689    Any
        //  596    601    869    874    Ljava/lang/InterruptedException;
        //  596    601    681    689    Any
        //  601    604    681    689    Any
        //  604    642    331    339    Any
        //  646    659    1024   1035   Any
        //  663    667    1024   1035   Any
        //  670    675    770    774    Any
        //  683    689    331    339    Any
        //  689    701    331    339    Any
        //  706    711    331    339    Any
        //  717    729    1024   1035   Any
        //  733    747    1024   1035   Any
        //  753    767    770    774    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 469 out of bounds for length 469
        //     at jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at jdk.internal.util.Preconditions.checkIndex(Preconditions.java:266)
        //     at java.util.Objects.checkIndex(Objects.java:359)
        //     at java.util.ArrayList.get(ArrayList.java:434)
        //     at w5.a.o(SourceFile:31)
        //     at w5.a.j(SourceFile:218)
        //     at a6.j.j(SourceFile:23)
        //     at a6.j.i(SourceFile:28)
        //     at a6.i.n(SourceFile:7)
        //     at a6.i.m(SourceFile:174)
        //     at a6.i.c(SourceFile:67)
        //     at a6.i.r(SourceFile:328)
        //     at a6.i.s(SourceFile:17)
        //     at a6.i.q(SourceFile:29)
        //     at a6.i.b(SourceFile:33)
        //     at y5.d.e(SourceFile:6)
        //     at y5.d.b(SourceFile:1)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(SourceFile:306)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:131)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
        //     at e7.a.run(SourceFile:1)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        //     at java.lang.Thread.run(Thread.java:1012)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
