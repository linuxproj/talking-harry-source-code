package com.outfit7.talkingtom;

import java.util.concurrent.locks.Condition;

final class y extends m
{
    private boolean i;
    private u j;
    
    y(final u j) {
        this.j = j;
        super(j.b);
    }
    
    public final void a() {
        this.j.b.t.f();
        this.f.lock();
        while (true) {
            try {
                this.h.signal();
                this.f.unlock();
                try {
                    while (!this.a) {
                        this.j.b.b.sendMessage(this.j.b.b.obtainMessage(4, (Object)new at(new q(this.j.b, this.j.b.k.a()), false, this.c, this.b)));
                        this.f.lock();
                        final y y = this;
                        final u u = y.j;
                        final Engine engine = u.b;
                        final ar ar = engine.k;
                        ar.c();
                        final y y2 = this;
                        final Condition condition = y2.g;
                        condition.await();
                    }
                }
                finally {}
            }
            finally {
                this.f.unlock();
            }
            try {
                final y y = this;
                final u u = y.j;
                final Engine engine = u.b;
                final ar ar = engine.k;
                ar.c();
                final y y2 = this;
                final Condition condition = y2.g;
                condition.await();
                continue;
            }
            catch (final InterruptedException ex) {
                continue;
            }
            finally {
                this.j.b.k.d();
                this.f.unlock();
            }
            break;
        }
    }
    
    @Override
    public final void b() {
        while (true) {
            super.b();
            this.f.lock();
            try {
                this.g.signal();
                this.f.unlock();
                if (this.i) {
                    return;
                }
            }
            finally {
                this.f.unlock();
            }
            this.j.b.t.g();
        }
    }
    
    @Override
    public final void c() {
        super.c();
        this.f.lock();
        try {
            this.h.signal();
        }
        finally {
            this.f.unlock();
        }
    }
    
    @Override
    public final void e() {
        super.e();
        this.f.lock();
        try {
            this.g.signal();
            this.f.unlock();
            this.i = true;
            this.j.b.t.g();
            this.j.b.t.u = 300;
        }
        finally {
            this.f.unlock();
        }
    }
    
    final void g() {
        this.f.lock();
        try {
            this.a = true;
            this.g.signal();
        }
        finally {
            this.f.unlock();
        }
    }
}
