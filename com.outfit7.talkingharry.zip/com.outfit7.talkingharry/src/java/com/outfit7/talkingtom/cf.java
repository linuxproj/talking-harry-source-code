package com.outfit7.talkingtom;

final class cf extends ce
{
    final Main c;
    
    private cf(final Main c, final byte b) {
        super(this.c = c);
        this.b = 1000L;
    }
    
    @Override
    public final n c() {
        final Engine a = this.c.c;
        a.getClass();
        return new cg(this, a, "ninje/mezik");
    }
}
