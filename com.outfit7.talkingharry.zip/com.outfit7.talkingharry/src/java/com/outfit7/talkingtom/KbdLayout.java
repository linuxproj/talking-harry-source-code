package com.outfit7.talkingtom;

import java.util.Iterator;
import android.view.MotionEvent;
import android.os.HandlerThread;
import java.util.ArrayList;
import android.util.AttributeSet;
import android.content.Context;
import java.util.List;
import android.widget.RelativeLayout;

public class KbdLayout extends RelativeLayout
{
    private List a;
    private KbdImageView b;
    
    static {
        KbdLayout.class.getName();
    }
    
    public KbdLayout(final Context context) {
        this(context, null);
    }
    
    public KbdLayout(final Context context, final AttributeSet set) {
        this(context, set, 0);
    }
    
    public KbdLayout(final Context context, final AttributeSet set, final int n) {
        super(context, set, n);
        this.a = (List)new ArrayList();
        final HandlerThread handlerThread = new HandlerThread("kbdTouch");
        handlerThread.start();
        new bg(handlerThread.getLooper());
        context.getApplicationContext();
    }
    
    public boolean onTouchEvent(final MotionEvent motionEvent) {
        final int n = (int)motionEvent.getX();
        final int n2 = (int)motionEvent.getY();
        final Iterator iterator = this.a.iterator();
        if (iterator.hasNext()) {
            final KbdImageView kbdImageView = (KbdImageView)iterator.next();
            throw new NullPointerException();
        }
        final KbdImageView b = null;
        if (motionEvent.getAction() == 0) {
            if (b != null) {
                b.a();
            }
        }
        else if (motionEvent.getAction() == 1 || motionEvent.getAction() == 3) {
            if (this.b != null) {
                this.b.b();
            }
        }
        else if (this.b != null) {
            if (b == null) {
                this.b.b();
            }
            else if (b != null && this.b != b) {
                this.b.b();
                b.a();
            }
        }
        if (b != null) {
            this.b = b;
        }
        return true;
    }
    
    public void onWindowFocusChanged(final boolean b) {
        if (b && this.a.size() != 0) {}
    }
}
