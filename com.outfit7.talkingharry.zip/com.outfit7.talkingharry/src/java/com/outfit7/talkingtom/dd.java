package com.outfit7.talkingtom;

final class dd implements Runnable
{
    private cv a;
    
    dd(final cv a) {
        this.a = a;
    }
    
    public final void run() {
        this.a.a.findViewById(2131296271).setVisibility(8);
        this.a.a.findViewById(2131296274).setVisibility(8);
    }
}
