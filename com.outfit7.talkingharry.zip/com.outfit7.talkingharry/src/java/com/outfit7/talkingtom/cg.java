package com.outfit7.talkingtom;

final class cg extends n
{
    private cf m;
    
    cg(final cf m, final Engine engine, final String s) {
        this.m = m;
        engine.getClass();
        super(engine, s);
    }
    
    @Override
    public final void c() {
        super.c();
        this.m.a();
    }
    
    @Override
    public final void f() {
        super.b = 4;
    }
    
    @Override
    public final void j() {
        super.j();
        this.m.c.p.d();
        this.g();
    }
    
    @Override
    public final void k() {
        super.k();
        this.m.a();
    }
}
