package com.outfit7.talkingtom;

import android.view.View;
import android.view.View$OnClickListener;

final class fq implements View$OnClickListener
{
    private VideoUploadedToYtActivity a;
    
    fq(final VideoUploadedToYtActivity a) {
        this.a = a;
    }
    
    public final void onClick(final View view) {
        this.a.setResult(1);
        this.a.finish();
    }
}
