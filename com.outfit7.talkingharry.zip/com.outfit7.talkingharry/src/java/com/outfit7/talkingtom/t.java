package com.outfit7.talkingtom;

import android.os.Message;
import android.os.Handler;

final class t extends Handler
{
    private Engine a;
    
    t(final Engine a) {
        this.a = a;
        super(a.l.getLooper());
    }
    
    public final void handleMessage(final Message message) {
        switch (message.what) {
            case 0: {
                this.a.r.a();
                break;
            }
        }
    }
}
