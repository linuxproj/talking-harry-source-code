package com.outfit7.talkingtom;

import android.content.pm.PackageManager$NameNotFoundException;
import android.os.Environment;
import java.io.File;
import android.content.Context;
import android.app.Activity;
import android.util.Log;
import java.util.List;
import android.media.AudioRecord;
import android.os.Build$VERSION;
import java.net.URLEncoder;
import android.os.Build;
import com.a.a.e;
import android.app.Application;

public class TalkingTomApplication extends Application
{
    public static String a;
    public static String b;
    private static final String c;
    private static String[] d;
    private e e;
    private int f;
    private g g;
    
    static {
        c = TalkingTomApplication.class.getName();
        TalkingTomApplication.a = "https://outfit7-affirmations.appspot.com/rest/talkingFriends/v1/Android/?appname=TalkingHarryTheHedgehog&model=" + URLEncoder.encode(Build.MODEL) + "&sdk=" + Build$VERSION.SDK;
        TalkingTomApplication.b = "Basic dXNlcjp0YWxraW5nVXNlcg==";
        TalkingTomApplication.d = new String[] { "publish_stream" };
    }
    
    public TalkingTomApplication() {
        this.e = new e();
        final int[] array2;
        final int[] array = array2 = new int[2];
        array2[0] = 11025;
        array2[1] = 8000;
        for (int n = 0, n2 = -2; n2 < 0 && n < array.length; ++n) {
            this.f = array[n];
            final int minBufferSize = AudioRecord.getMinBufferSize(this.f, 2, 2);
            if ((n2 = minBufferSize) > 4096) {
                n2 = minBufferSize;
                if (n != array.length - 1) {
                    n2 = -1;
                }
            }
        }
    }
    
    public static String e() {
        return "com.outfit7.talkingtompro";
    }
    
    public static String f() {
        return "com.outfit7.talkingtom";
    }
    
    public static q[] j() {
        return Engine.a().d().c();
    }
    
    public static ap[] k() {
        return Engine.a().d().d();
    }
    
    public static boolean[] l() {
        return Engine.a().d().e();
    }
    
    public static int[] m() {
        return Engine.a().d().b();
    }
    
    public static List[] n() {
        return Engine.a().d().a();
    }
    
    public final e a() {
        return this.e;
    }
    
    public final String a(final String s) {
        String language = "en";
        try {
            language = this.getResources().getConfiguration().locale.getLanguage();
            return "http://outfit7-affirmations.appspot.com/rest/v1/news/android/talking/" + language + "/?appname=" + "TalkingHarryTheHedgehog" + "&did=" + s;
        }
        catch (final RuntimeException ex) {
            Log.e(TalkingTomApplication.c, ex.getLocalizedMessage(), (Throwable)ex);
            return "http://outfit7-affirmations.appspot.com/rest/v1/news/android/talking/" + language + "/?appname=" + "TalkingHarryTheHedgehog" + "&did=" + s;
        }
    }
    
    public final void a(final Activity activity, final com.a.a.g g) {
        this.e.a((Context)activity, "b3c6850e9db4c44a80f6a9e848297dae", TalkingTomApplication.d, new eu(this, g, activity));
    }
    
    public final void a(final g g) {
        this.g = g;
    }
    
    public final g b() {
        return this.g;
    }
    
    public final File c() {
        return new File(this.getCacheDir(), "TalkingHarry.avi");
    }
    
    public final File d() {
        return new File(Environment.getExternalStorageDirectory(), "/Android/data/" + this.getPackageName() + "/files/" + "TalkingHarry.avi");
    }
    
    public final String g() {
        return "market://details?id=" + this.getPackageName();
    }
    
    public final String h() {
        try {
            final String versionName = this.getPackageManager().getPackageInfo(this.getPackageName(), 0).versionName;
            final int index = versionName.indexOf(" ");
            final int index2 = versionName.indexOf(":");
            int n;
            if (index == -1) {
                n = index2;
            }
            else {
                n = index;
                if (index2 != -1 && index2 < (n = index)) {
                    n = index2;
                }
            }
            String substring = versionName;
            if (n != -1) {
                substring = versionName.substring(0, n);
            }
            return "TalkingHarryTheHedgehogAndroid/" + substring;
        }
        catch (final PackageManager$NameNotFoundException ex) {
            Log.e(TalkingTomApplication.c, ex.getLocalizedMessage(), (Throwable)ex);
            final String substring = "1.0x";
            return "TalkingHarryTheHedgehogAndroid/" + substring;
        }
    }
    
    public final int i() {
        return this.f;
    }
}
