package com.outfit7.talkingtom;

final class bb implements Runnable
{
    private long a;
    private KbdImageView b;
    
    bb(final KbdImageView b, final long a) {
        this.b = b;
        this.a = a;
    }
    
    public final void run() {
        this.b.a(null, null, this.a);
    }
}
