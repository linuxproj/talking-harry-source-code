package com.outfit7.talkingtom;

import android.widget.Toast;
import android.content.Context;
import android.content.Intent;
import android.os.Message;
import android.app.Activity;
import android.os.Handler;

final class ey extends Handler
{
    private Activity a;
    private aw b;
    
    ey(final Activity a, final aw b) {
        this.a = a;
        this.b = b;
    }
    
    public final void handleMessage(final Message message) {
        final Handler a = ((BackgroundActivity)this.a).a();
        switch (message.what) {
            case 1: {
                if (!VideoCommentActivity.c) {
                    VideoCommentActivity.b.setMax((int)message.obj);
                    break;
                }
                break;
            }
            case 2: {
                if (!VideoCommentActivity.c) {
                    VideoCommentActivity.b.setProgress((int)message.obj);
                    break;
                }
                break;
            }
            case 5: {
                if (!VideoCommentActivity.c) {
                    VideoCommentActivity.b.dismiss();
                    final String s = (String)message.obj;
                    final Intent intent = new Intent((Context)this.a, (Class)VideoUploadedToFbActivity.class);
                    intent.putExtra("facebookVideoUrl", s);
                    this.a.startActivityForResult(intent, 6);
                    break;
                }
                break;
            }
            case 4: {
                if (!VideoCommentActivity.c) {
                    VideoCommentActivity.b.dismiss();
                    Toast.makeText((Context)this.a, (CharSequence)message.obj, 1).show();
                    a.sendEmptyMessage(2);
                    break;
                }
                break;
            }
            case 3: {
                if (!VideoCommentActivity.c) {
                    if (this.b != null) {
                        this.b.a();
                    }
                    a.sendEmptyMessage(2);
                }
                break;
            }
            case 111: {
                VideoCommentActivity.b.dismiss();
                break;
            }
        }
    }
}
