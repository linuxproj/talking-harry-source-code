package com.outfit7.talkingtom;

import android.widget.TextView;
import android.widget.ImageView;
import java.util.ArrayList;
import android.widget.RelativeLayout$LayoutParams;
import java.util.List;
import android.graphics.drawable.Drawable;

final class ad
{
    ap a;
    final Engine b;
    private q c;
    private int d;
    private boolean e;
    private boolean f;
    private Drawable g;
    private Drawable h;
    private Drawable[] i;
    private ao j;
    private q[] k;
    private List[] l;
    private ap[] m;
    private boolean[] n;
    private boolean[] o;
    private boolean[] p;
    private int[] q;
    private int[] r;
    private int s;
    private int t;
    private int u;
    private String v;
    private ap w;
    private int x;
    
    ad(final Engine b) {
        this.b = b;
        this.g = this.b.a.getResources().getDrawable(2130837539);
        this.h = this.b.a.getResources().getDrawable(2130837542);
        this.i = new Drawable[] { this.g, this.h };
        this.u = 300;
    }
    
    final void a(final int d) {
        synchronized (this) {
            this.d = d;
            if (this.e && this.s >= 0 && this.s < this.k.length) {
                this.r[this.s] = d;
            }
        }
    }
    
    final void a(final RelativeLayout$LayoutParams b) {
        synchronized (this) {
            if (this.e && this.s >= 0 && this.s < this.k.length) {
                Object o;
                if ((o = this.l[this.s]) == null) {
                    o = new ArrayList();
                    this.l[this.s] = (List)o;
                }
                final q q = new q(this.b);
                q.b = b;
                ((List)o).add((Object)q);
            }
        }
    }
    
    final void a(final AnimationPlayer animationPlayer) {
        synchronized (this) {
            final ah ah = new ah(this, animationPlayer, new s(this.b, this.b.i, (ImageView)animationPlayer.findViewById(2131296264), null, null));
            ah.b = 100;
            ah.c = "playback";
            this.b.i.a().sendMessage(this.b.i.a().obtainMessage(0, (Object)ah));
        }
    }
    
    final void a(ap ap) {
        while (true) {
            Label_0103: {
                synchronized (this) {
                    if (this.e && !this.f && this.s >= 0 && this.s < this.m.length) {
                        if (this.m[this.s] != null) {
                            break Label_0103;
                        }
                        final ap[] m = this.m;
                        final int s = this.s;
                        ap = ap.f;
                        m[s] = (this.a = ap);
                        this.c((ap)null);
                        this.u = 300;
                    }
                    return;
                }
            }
            if (this.m[this.s].c != null && this.m[this.s] instanceof av) {
                final ap[] i = this.m;
                final int s2 = this.s;
                final ap ap2;
                ap = ap2.f;
                i[s2] = (this.a = ap);
                this.c((ap)null);
                this.u = 300;
            }
        }
    }
    
    final void a(final at at) {
        while (true) {
            final q a;
            Label_0121: {
                synchronized (this) {
                    a = at.a;
                    if (a != null && at.b) {
                        this.c = a;
                        if (this.e && this.s >= 0 && this.s < this.k.length && !this.f) {
                            if (at.h == null) {
                                break Label_0121;
                            }
                            Object o;
                            if ((o = this.l[this.s]) == null) {
                                o = new ArrayList();
                                this.l[this.s] = (List)o;
                            }
                            ((List)o).add((Object)a);
                        }
                    }
                    return;
                }
            }
            this.k[this.s] = a;
            final at at2;
            if (this.v != null && this.v.equals((Object)at2.d)) {
                return;
            }
            this.v = at2.d;
            if (at2.e) {
                this.p[this.s] = true;
            }
        }
    }
    
    final void a(final boolean p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getfield        com/outfit7/talkingtom/ad.e:Z
        //     4: ifne            8
        //     7: return         
        //     8: aload_0        
        //     9: getfield        com/outfit7/talkingtom/ad.j:Lcom/outfit7/talkingtom/ao;
        //    12: astore          5
        //    14: aload           5
        //    16: dup            
        //    17: astore          8
        //    19: monitorenter   
        //    20: aload_0        
        //    21: getfield        com/outfit7/talkingtom/ad.j:Lcom/outfit7/talkingtom/ao;
        //    24: invokevirtual   com/outfit7/talkingtom/ao.a:()V
        //    27: iload_1        
        //    28: ifeq            38
        //    31: aload_0        
        //    32: getfield        com/outfit7/talkingtom/ad.j:Lcom/outfit7/talkingtom/ao;
        //    35: invokevirtual   java/lang/Object.wait:()V
        //    38: aload           8
        //    40: monitorexit    
        //    41: aload_0        
        //    42: iconst_0       
        //    43: putfield        com/outfit7/talkingtom/ad.e:Z
        //    46: aload_0        
        //    47: invokevirtual   com/outfit7/talkingtom/ad.g:()V
        //    50: aload_0        
        //    51: getfield        com/outfit7/talkingtom/ad.u:I
        //    54: sipush          300
        //    57: if_icmpeq       352
        //    60: aload_0        
        //    61: getfield        com/outfit7/talkingtom/ad.u:I
        //    64: aload_0        
        //    65: getfield        com/outfit7/talkingtom/ad.t:I
        //    68: if_icmpeq       352
        //    71: aload_0        
        //    72: getfield        com/outfit7/talkingtom/ad.b:Lcom/outfit7/talkingtom/Engine;
        //    75: invokestatic    com/outfit7/talkingtom/Engine.a:(Lcom/outfit7/talkingtom/Engine;)Lcom/outfit7/talkingtom/u;
        //    78: getfield        com/outfit7/talkingtom/u.a:Lcom/outfit7/talkingtom/et;
        //    81: invokevirtual   com/outfit7/talkingtom/et.c:()V
        //    84: aload_0        
        //    85: getfield        com/outfit7/talkingtom/ad.b:Lcom/outfit7/talkingtom/Engine;
        //    88: invokestatic    com/outfit7/talkingtom/Engine.a:(Lcom/outfit7/talkingtom/Engine;)Lcom/outfit7/talkingtom/u;
        //    91: getfield        com/outfit7/talkingtom/u.a:Lcom/outfit7/talkingtom/et;
        //    94: invokevirtual   com/outfit7/talkingtom/et.f:()I
        //    97: istore_2       
        //    98: iload_2        
        //    99: ifeq            352
        //   102: iload_2        
        //   103: newarray        S
        //   105: astore          5
        //   107: aload_0        
        //   108: getfield        com/outfit7/talkingtom/ad.b:Lcom/outfit7/talkingtom/Engine;
        //   111: invokestatic    com/outfit7/talkingtom/Engine.a:(Lcom/outfit7/talkingtom/Engine;)Lcom/outfit7/talkingtom/u;
        //   114: getfield        com/outfit7/talkingtom/u.a:Lcom/outfit7/talkingtom/et;
        //   117: aload           5
        //   119: iconst_0       
        //   120: aload           5
        //   122: arraylength    
        //   123: invokevirtual   com/outfit7/talkingtom/et.a:([SII)I
        //   126: pop            
        //   127: new             Lcom/outfit7/talkingtom/aq;
        //   130: dup            
        //   131: aload_0        
        //   132: getfield        com/outfit7/talkingtom/ad.b:Lcom/outfit7/talkingtom/Engine;
        //   135: aload           5
        //   137: invokespecial   com/outfit7/talkingtom/aq.<init>:(Lcom/outfit7/talkingtom/Engine;[S)V
        //   140: astore          5
        //   142: aload_0        
        //   143: getfield        com/outfit7/talkingtom/ad.m:[Lcom/outfit7/talkingtom/ap;
        //   146: aload_0        
        //   147: getfield        com/outfit7/talkingtom/ad.u:I
        //   150: aaload         
        //   151: ifnonnull       165
        //   154: aload_0        
        //   155: getfield        com/outfit7/talkingtom/ad.m:[Lcom/outfit7/talkingtom/ap;
        //   158: aload_0        
        //   159: getfield        com/outfit7/talkingtom/ad.u:I
        //   162: aload           5
        //   164: aastore        
        //   165: aload           5
        //   167: getfield        com/outfit7/talkingtom/ap.d:I
        //   170: aload_0        
        //   171: getfield        com/outfit7/talkingtom/ad.b:Lcom/outfit7/talkingtom/Engine;
        //   174: invokestatic    com/outfit7/talkingtom/Engine.h:(Lcom/outfit7/talkingtom/Engine;)I
        //   177: bipush          10
        //   179: idiv           
        //   180: idiv           
        //   181: istore_3       
        //   182: iload_3        
        //   183: istore_2       
        //   184: aload           5
        //   186: getfield        com/outfit7/talkingtom/ap.d:I
        //   189: aload_0        
        //   190: getfield        com/outfit7/talkingtom/ad.b:Lcom/outfit7/talkingtom/Engine;
        //   193: invokestatic    com/outfit7/talkingtom/Engine.h:(Lcom/outfit7/talkingtom/Engine;)I
        //   196: bipush          10
        //   198: idiv           
        //   199: irem           
        //   200: ifeq            207
        //   203: iload_3        
        //   204: iconst_1       
        //   205: iadd           
        //   206: istore_2       
        //   207: iconst_0       
        //   208: istore_3       
        //   209: iload_3        
        //   210: iload_2        
        //   211: if_icmpge       331
        //   214: aload_0        
        //   215: getfield        com/outfit7/talkingtom/ad.u:I
        //   218: sipush          300
        //   221: if_icmpeq       331
        //   224: aload_0        
        //   225: getfield        com/outfit7/talkingtom/ad.p:[Z
        //   228: aload_0        
        //   229: getfield        com/outfit7/talkingtom/ad.u:I
        //   232: baload         
        //   233: ifne            331
        //   236: aload_0        
        //   237: getfield        com/outfit7/talkingtom/ad.b:Lcom/outfit7/talkingtom/Engine;
        //   240: invokestatic    com/outfit7/talkingtom/Engine.a:(Lcom/outfit7/talkingtom/Engine;)Lcom/outfit7/talkingtom/u;
        //   243: iload_3        
        //   244: invokestatic    com/outfit7/talkingtom/u.a:(Lcom/outfit7/talkingtom/u;I)I
        //   247: istore          4
        //   249: aload_0        
        //   250: getfield        com/outfit7/talkingtom/ad.k:[Lcom/outfit7/talkingtom/q;
        //   253: aload_0        
        //   254: getfield        com/outfit7/talkingtom/ad.u:I
        //   257: new             Lcom/outfit7/talkingtom/q;
        //   260: dup            
        //   261: aload_0        
        //   262: getfield        com/outfit7/talkingtom/ad.b:Lcom/outfit7/talkingtom/Engine;
        //   265: aload_0        
        //   266: getfield        com/outfit7/talkingtom/ad.b:Lcom/outfit7/talkingtom/Engine;
        //   269: invokestatic    com/outfit7/talkingtom/Engine.f:(Lcom/outfit7/talkingtom/Engine;)Lcom/outfit7/talkingtom/ar;
        //   272: iload           4
        //   274: invokeinterface com/outfit7/talkingtom/ar.a:(I)Ljava/lang/String;
        //   279: invokespecial   com/outfit7/talkingtom/q.<init>:(Lcom/outfit7/talkingtom/Engine;Ljava/lang/String;)V
        //   282: aastore        
        //   283: iload_3        
        //   284: ifeq            297
        //   287: aload_0        
        //   288: getfield        com/outfit7/talkingtom/ad.m:[Lcom/outfit7/talkingtom/ap;
        //   291: aload_0        
        //   292: getfield        com/outfit7/talkingtom/ad.u:I
        //   295: aconst_null    
        //   296: aastore        
        //   297: aload_0        
        //   298: getfield        com/outfit7/talkingtom/ad.n:[Z
        //   301: aload_0        
        //   302: getfield        com/outfit7/talkingtom/ad.u:I
        //   305: iconst_0       
        //   306: bastore        
        //   307: aload_0        
        //   308: aload_0        
        //   309: getfield        com/outfit7/talkingtom/ad.u:I
        //   312: iconst_1       
        //   313: iadd           
        //   314: putfield        com/outfit7/talkingtom/ad.u:I
        //   317: iinc            3, 1
        //   320: goto            209
        //   323: astore          6
        //   325: aload           8
        //   327: monitorexit    
        //   328: aload           6
        //   330: athrow         
        //   331: aload_0        
        //   332: getfield        com/outfit7/talkingtom/ad.u:I
        //   335: aload_0        
        //   336: getfield        com/outfit7/talkingtom/ad.t:I
        //   339: if_icmple       494
        //   342: aload_0        
        //   343: getfield        com/outfit7/talkingtom/ad.u:I
        //   346: istore_2       
        //   347: aload_0        
        //   348: iload_2        
        //   349: putfield        com/outfit7/talkingtom/ad.s:I
        //   352: aload_0        
        //   353: sipush          300
        //   356: putfield        com/outfit7/talkingtom/ad.u:I
        //   359: new             Lcom/outfit7/talkingtom/af;
        //   362: dup            
        //   363: invokespecial   com/outfit7/talkingtom/af.<init>:()V
        //   366: astore          5
        //   368: new             Lcom/outfit7/talkingtom/ae;
        //   371: dup            
        //   372: aload_0        
        //   373: aload           5
        //   375: invokespecial   com/outfit7/talkingtom/ae.<init>:(Lcom/outfit7/talkingtom/ad;Lcom/outfit7/talkingtom/af;)V
        //   378: astore          6
        //   380: aload           6
        //   382: ldc_w           2147483647
        //   385: putfield        com/outfit7/talkingtom/m.b:I
        //   388: aload           6
        //   390: ldc_w           "recordingFinished"
        //   393: putfield        com/outfit7/talkingtom/m.c:Ljava/lang/String;
        //   396: aload           5
        //   398: dup            
        //   399: astore          8
        //   401: monitorenter   
        //   402: aload_0        
        //   403: getfield        com/outfit7/talkingtom/ad.b:Lcom/outfit7/talkingtom/Engine;
        //   406: getfield        com/outfit7/talkingtom/Engine.c:Lcom/outfit7/talkingtom/ab;
        //   409: invokevirtual   com/outfit7/talkingtom/ab.a:()Lcom/outfit7/talkingtom/aa;
        //   412: aload_0        
        //   413: getfield        com/outfit7/talkingtom/ad.b:Lcom/outfit7/talkingtom/Engine;
        //   416: getfield        com/outfit7/talkingtom/Engine.c:Lcom/outfit7/talkingtom/ab;
        //   419: invokevirtual   com/outfit7/talkingtom/ab.a:()Lcom/outfit7/talkingtom/aa;
        //   422: iconst_0       
        //   423: aload           6
        //   425: invokevirtual   com/outfit7/talkingtom/aa.obtainMessage:(ILjava/lang/Object;)Landroid/os/Message;
        //   428: invokevirtual   com/outfit7/talkingtom/aa.sendMessage:(Landroid/os/Message;)Z
        //   431: pop            
        //   432: aload           5
        //   434: invokevirtual   java/lang/Object.wait:()V
        //   437: aload           8
        //   439: monitorexit    
        //   440: aload           6
        //   442: dup            
        //   443: astore          9
        //   445: monitorenter   
        //   446: aload           6
        //   448: invokevirtual   java/lang/Object.notify:()V
        //   451: aload           9
        //   453: monitorexit    
        //   454: aload_0        
        //   455: getfield        com/outfit7/talkingtom/ad.b:Lcom/outfit7/talkingtom/Engine;
        //   458: invokevirtual   com/outfit7/talkingtom/Engine.f:()V
        //   461: iload_1        
        //   462: ifne            7
        //   465: aload           5
        //   467: getfield        com/outfit7/talkingtom/af.a:Z
        //   470: ifne            7
        //   473: aload_0        
        //   474: getfield        com/outfit7/talkingtom/ad.b:Lcom/outfit7/talkingtom/Engine;
        //   477: getfield        com/outfit7/talkingtom/Engine.a:Lcom/outfit7/talkingtom/Main;
        //   480: new             Lcom/outfit7/talkingtom/ag;
        //   483: dup            
        //   484: aload_0        
        //   485: invokespecial   com/outfit7/talkingtom/ag.<init>:(Lcom/outfit7/talkingtom/ad;)V
        //   488: invokevirtual   com/outfit7/talkingtom/Main.runOnUiThread:(Ljava/lang/Runnable;)V
        //   491: goto            7
        //   494: aload_0        
        //   495: getfield        com/outfit7/talkingtom/ad.t:I
        //   498: istore_2       
        //   499: goto            347
        //   502: astore          6
        //   504: aload           8
        //   506: monitorexit    
        //   507: aload           6
        //   509: athrow         
        //   510: astore          5
        //   512: aload           9
        //   514: monitorexit    
        //   515: aload           5
        //   517: athrow         
        //   518: astore          7
        //   520: goto            437
        //   523: astore          6
        //   525: goto            38
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  20     27     323    331    Any
        //  31     38     523    528    Ljava/lang/InterruptedException;
        //  31     38     323    331    Any
        //  38     41     323    331    Any
        //  402    432    502    510    Any
        //  432    437    518    523    Ljava/lang/InterruptedException;
        //  432    437    502    510    Any
        //  437    440    502    510    Any
        //  446    454    510    518    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0038:
        //     at w5.m.a(SourceFile:20)
        //     at w5.f.o(SourceFile:122)
        //     at w5.f.r(SourceFile:571)
        //     at w5.f.q(SourceFile:3)
        //     at a6.j.j(SourceFile:32)
        //     at a6.j.i(SourceFile:28)
        //     at a6.i.n(SourceFile:7)
        //     at a6.i.m(SourceFile:174)
        //     at a6.i.c(SourceFile:67)
        //     at a6.i.r(SourceFile:328)
        //     at a6.i.s(SourceFile:17)
        //     at a6.i.q(SourceFile:29)
        //     at a6.i.b(SourceFile:33)
        //     at y5.d.e(SourceFile:6)
        //     at y5.d.b(SourceFile:1)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(SourceFile:306)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:131)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
        //     at e7.a.run(SourceFile:1)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        //     at java.lang.Thread.run(Thread.java:1012)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    final List[] a() {
        return this.l;
    }
    
    final void b(final int x) {
        synchronized (this) {
            this.x = x;
        }
    }
    
    final void b(final AnimationPlayer animationPlayer) {
        final an an = new an(this);
        an.b = 100;
        an.c = "playback";
        this.b.i.a().sendMessage(this.b.i.a().obtainMessage(0, (Object)an));
        animationPlayer.setResult(2);
        animationPlayer.finish();
    }
    
    final void b(final ap ap) {
        synchronized (this) {
            if (this.e && !this.f && this.a == ap && this.s >= 0 && this.s < this.m.length && this.m[this.s] == null) {
                this.n[this.s] = true;
                this.c((ap)null);
            }
        }
    }
    
    final int[] b() {
        return this.r;
    }
    
    final void c(final ap w) {
        synchronized (this) {
            this.w = w;
        }
    }
    
    final q[] c() {
        Object o;
        if (this.k == null) {
            o = null;
        }
        else if (this.s == 0) {
            o = null;
        }
        else {
            o = new q[this.s];
            System.arraycopy((Object)this.k, 0, o, 0, ((q[])o).length);
        }
        return (q[])o;
    }
    
    final ap[] d() {
        Object o;
        if (this.m == null) {
            o = null;
        }
        else if (this.s == 0) {
            o = null;
        }
        else {
            o = new ap[this.s];
            System.arraycopy((Object)this.m, 0, o, 0, ((ap[])o).length);
        }
        return (ap[])o;
    }
    
    final boolean[] e() {
        Object o;
        if (this.n == null) {
            o = null;
        }
        else if (this.s == 0) {
            o = null;
        }
        else {
            o = new boolean[this.s];
            System.arraycopy((Object)this.n, 0, o, 0, ((boolean[])o).length);
        }
        return (boolean[])o;
    }
    
    final void f() {
        this.f = true;
        int s;
        if (this.e) {
            s = this.s;
        }
        else {
            s = 0;
        }
        this.u = s;
    }
    
    final void g() {
        if (this.f) {
            this.f = false;
            this.s = this.u;
        }
    }
    
    final boolean h() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getfield        com/outfit7/talkingtom/ad.e:Z
        //     4: ifeq            21
        //     7: aload_0        
        //     8: iconst_1       
        //     9: invokevirtual   com/outfit7/talkingtom/ad.a:(Z)V
        //    12: aload_0        
        //    13: aconst_null    
        //    14: putfield        com/outfit7/talkingtom/ad.w:Lcom/outfit7/talkingtom/ap;
        //    17: iconst_1       
        //    18: istore_1       
        //    19: iload_1        
        //    20: ireturn        
        //    21: aload_0        
        //    22: sipush          300
        //    25: anewarray       Lcom/outfit7/talkingtom/q;
        //    28: putfield        com/outfit7/talkingtom/ad.k:[Lcom/outfit7/talkingtom/q;
        //    31: aload_0        
        //    32: getfield        com/outfit7/talkingtom/ad.k:[Lcom/outfit7/talkingtom/q;
        //    35: iconst_0       
        //    36: aload_0        
        //    37: getfield        com/outfit7/talkingtom/ad.c:Lcom/outfit7/talkingtom/q;
        //    40: aastore        
        //    41: aload_0        
        //    42: sipush          300
        //    45: anewarray       Ljava/util/ArrayList;
        //    48: putfield        com/outfit7/talkingtom/ad.l:[Ljava/util/List;
        //    51: aload_0        
        //    52: sipush          300
        //    55: newarray        I
        //    57: putfield        com/outfit7/talkingtom/ad.r:[I
        //    60: aload_0        
        //    61: getfield        com/outfit7/talkingtom/ad.r:[I
        //    64: iconst_0       
        //    65: aload_0        
        //    66: getfield        com/outfit7/talkingtom/ad.d:I
        //    69: iastore        
        //    70: aload_0        
        //    71: sipush          300
        //    74: anewarray       Lcom/outfit7/talkingtom/ap;
        //    77: putfield        com/outfit7/talkingtom/ad.m:[Lcom/outfit7/talkingtom/ap;
        //    80: aload_0        
        //    81: sipush          300
        //    84: newarray        Z
        //    86: putfield        com/outfit7/talkingtom/ad.n:[Z
        //    89: aload_0        
        //    90: sipush          300
        //    93: newarray        Z
        //    95: putfield        com/outfit7/talkingtom/ad.p:[Z
        //    98: aload_0        
        //    99: sipush          300
        //   102: newarray        Z
        //   104: putfield        com/outfit7/talkingtom/ad.o:[Z
        //   107: aload_0        
        //   108: sipush          300
        //   111: newarray        I
        //   113: putfield        com/outfit7/talkingtom/ad.q:[I
        //   116: aload_0        
        //   117: new             Lcom/outfit7/talkingtom/ao;
        //   120: dup            
        //   121: aload_0        
        //   122: invokespecial   com/outfit7/talkingtom/ao.<init>:(Lcom/outfit7/talkingtom/ad;)V
        //   125: putfield        com/outfit7/talkingtom/ad.j:Lcom/outfit7/talkingtom/ao;
        //   128: aload_0        
        //   129: getfield        com/outfit7/talkingtom/ad.j:Lcom/outfit7/talkingtom/ao;
        //   132: astore_2       
        //   133: aload_2        
        //   134: dup            
        //   135: astore          4
        //   137: monitorenter   
        //   138: aload_0        
        //   139: getfield        com/outfit7/talkingtom/ad.j:Lcom/outfit7/talkingtom/ao;
        //   142: invokevirtual   com/outfit7/talkingtom/ao.start:()V
        //   145: aload_0        
        //   146: getfield        com/outfit7/talkingtom/ad.j:Lcom/outfit7/talkingtom/ao;
        //   149: invokevirtual   java/lang/Object.wait:()V
        //   152: aload           4
        //   154: monitorexit    
        //   155: aload_0        
        //   156: getfield        com/outfit7/talkingtom/ad.w:Lcom/outfit7/talkingtom/ap;
        //   159: ifnull          189
        //   162: aload_0        
        //   163: getfield        com/outfit7/talkingtom/ad.m:[Lcom/outfit7/talkingtom/ap;
        //   166: iconst_0       
        //   167: aload_0        
        //   168: getfield        com/outfit7/talkingtom/ad.w:Lcom/outfit7/talkingtom/ap;
        //   171: aload_0        
        //   172: getfield        com/outfit7/talkingtom/ad.x:I
        //   175: invokevirtual   com/outfit7/talkingtom/ap.a:(I)Lcom/outfit7/talkingtom/ap;
        //   178: aastore        
        //   179: aload_0        
        //   180: aconst_null    
        //   181: putfield        com/outfit7/talkingtom/ad.w:Lcom/outfit7/talkingtom/ap;
        //   184: aload_0        
        //   185: iconst_0       
        //   186: putfield        com/outfit7/talkingtom/ad.x:I
        //   189: aload_0        
        //   190: iconst_1       
        //   191: putfield        com/outfit7/talkingtom/ad.e:Z
        //   194: iconst_0       
        //   195: istore_1       
        //   196: goto            19
        //   199: astore_3       
        //   200: aload           4
        //   202: monitorexit    
        //   203: aload_3        
        //   204: athrow         
        //   205: astore_3       
        //   206: goto            152
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  138    145    199    205    Any
        //  145    152    205    209    Ljava/lang/InterruptedException;
        //  145    152    199    205    Any
        //  152    155    199    205    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0152:
        //     at w5.m.a(SourceFile:20)
        //     at w5.f.o(SourceFile:122)
        //     at w5.f.r(SourceFile:571)
        //     at w5.f.q(SourceFile:3)
        //     at a6.j.j(SourceFile:32)
        //     at a6.j.i(SourceFile:28)
        //     at a6.i.n(SourceFile:7)
        //     at a6.i.m(SourceFile:174)
        //     at a6.i.c(SourceFile:67)
        //     at a6.i.r(SourceFile:328)
        //     at a6.i.s(SourceFile:17)
        //     at a6.i.q(SourceFile:29)
        //     at a6.i.b(SourceFile:33)
        //     at y5.d.e(SourceFile:6)
        //     at y5.d.b(SourceFile:1)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(SourceFile:306)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:131)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
        //     at e7.a.run(SourceFile:1)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        //     at java.lang.Thread.run(Thread.java:1012)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
