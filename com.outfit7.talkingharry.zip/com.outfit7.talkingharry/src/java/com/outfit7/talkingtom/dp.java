package com.outfit7.talkingtom;

final class dp extends Thread
{
    private do a;
    
    dp(final do a) {
        this.a = a;
    }
    
    public final void run() {
        dl.b(this.a.a.m);
    }
}
