package com.outfit7.talkingtom;

import com.android.vending.licensing.LicenseCheckerCallback;
import com.android.vending.licensing.Policy;
import com.android.vending.licensing.Obfuscator;
import android.content.Context;
import com.android.vending.licensing.ServerManagedPolicy;
import com.android.vending.licensing.AESObfuscator;
import android.provider.Settings$Secure;
import android.app.Activity;
import com.android.vending.licensing.LicenseChecker;

public class ed
{
    private static final byte[] a;
    private LicenseChecker b;
    
    static {
        ed.class.getName();
        a = new byte[] { -46, 88, -95, 32, -64, 89, 65, 30, -57, 74, -64, -128, -103, 51, -45, 77, -117, -36, -113, -11 };
    }
    
    protected final void a() {
        if (this.b != null) {
            this.b.a();
        }
    }
    
    public final void a(final Activity activity) {
        (this.b = new LicenseChecker((Context)activity, (Policy)new ServerManagedPolicy((Context)activity, (Obfuscator)new AESObfuscator(ed.a, activity.getPackageName(), Settings$Secure.getString(activity.getContentResolver(), "android_id"))), "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAhVUaXDrUx8bVDfB25sgxvkMibpLrNTC4TiAZwUmYbdxM7o5+PnzoBHxvlAW/rjVBimDehYo8gAbRX95NGBHdxKEiJsDISeHxPYmrsZQWjkriFl4B6UhSwrkPHxAXgSnxFMjjF1QRbXwbabnWGcPf7CHxjRvomkrPy5s5VQgIq8K40UKmodflpU1pj4GhTNVx/5hihTckbrMb1MhsOXi0fapkQCnDagpsd0dia7nuXCgo4JNMx3hqv1E5zKXTOImwEuqMtu7fs+In+0G3CbsIkp0cwL4OJnc+sc0CgtmJlr5BcnbcUFni1rhaeydJil+8Yehd5O1HTfPl1x/kDYAc6wIDAQAB")).a((LicenseCheckerCallback)new Misc$1MyLicenseCheckerCallback(activity));
    }
}
