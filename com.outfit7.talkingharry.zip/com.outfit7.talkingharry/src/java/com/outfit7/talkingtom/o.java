package com.outfit7.talkingtom;

import android.view.View;
import android.view.ViewGroup;
import android.graphics.drawable.Drawable;

final class o implements Runnable
{
    private n a;
    
    o(final n a) {
        this.a = a;
    }
    
    public final void run() {
        if (this.a.j != null && this.a.j.getParent() != null) {
            this.a.j.setImageDrawable((Drawable)null);
            ((ViewGroup)this.a.j.getParent()).removeView((View)this.a.j);
        }
    }
}
