package com.outfit7.talkingtom;

final class du extends m
{
    du(final Engine engine) {
        engine.getClass();
        super(engine);
    }
    
    public final void a() {
    }
}
