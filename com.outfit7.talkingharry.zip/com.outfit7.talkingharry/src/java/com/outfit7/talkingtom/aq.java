package com.outfit7.talkingtom;

import java.util.Arrays;

class aq extends ap
{
    aq(final Engine engine) {
        super(engine);
    }
    
    aq(final Engine engine, final short[] array) {
        this(engine, array, array.length);
    }
    
    aq(final Engine engine, final short[] array, final int d) {
        super(engine);
        this.d = d;
        if (array != null) {
            this.c = array.clone();
            if (d < this.c.length) {
                Arrays.fill(this.c, d, this.c.length, (short)0);
            }
        }
    }
}
