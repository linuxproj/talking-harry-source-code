package com.outfit7.talkingtom;

import android.view.View$OnClickListener;
import android.os.Bundle;
import android.content.Intent;
import com.a.a.g;
import android.app.Activity;

public class VideoUploadedToYtActivity extends Activity
{
    static {
        VideoUploadedToYtActivity.class.getName();
    }
    
    protected void onActivityResult(final int n, final int n2, final Intent intent) {
    }
    
    public void onBackPressed() {
        this.setResult(1);
        this.finish();
    }
    
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2130903046);
        this.findViewById(2131296294).setOnClickListener((View$OnClickListener)new fo(this));
        this.findViewById(2131296295).setOnClickListener((View$OnClickListener)new fp(this));
        this.findViewById(2131296296).setOnClickListener((View$OnClickListener)new fq(this));
        this.runOnUiThread((Runnable)new fr(this));
    }
}
