package com.outfit7.talkingtom;

import android.view.ViewGroup$LayoutParams;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.ImageView;

final class al implements Runnable
{
    private ImageView a;
    private RelativeLayout b;
    private q c;
    
    al(final ImageView a, final RelativeLayout b, final q c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    public final void run() {
        final ImageView a = this.a;
        synchronized (a) {
            this.b.addView((View)this.a);
            this.a.setLayoutParams((ViewGroup$LayoutParams)this.c.b);
            this.a.notify();
        }
    }
}
