package com.outfit7.talkingtom;

public interface Engine$IdleAction
{
}
