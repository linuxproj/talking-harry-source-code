package com.outfit7.talkingtom;

import android.os.Message;
import android.os.Handler;

final class aa extends Handler
{
    private m a;
    private Engine b;
    
    aa(final Engine b) {
        this.b = b;
    }
    
    private void b() {
        synchronized (this) {
            this.b.r.b();
        }
    }
    
    public final int a() {
        synchronized (this) {
            int b;
            if (this.a == null) {
                b = Integer.MIN_VALUE;
            }
            else {
                b = this.a.b;
            }
            return b;
        }
    }
    
    public final void a(final m m) {
        synchronized (this) {
            if (this.a == m) {
                this.a = null;
            }
        }
    }
    
    public final void handleMessage(final Message message) {
        while (true) {
            final m a;
            Label_0095: {
                Label_0080: {
                    synchronized (this) {
                        final m m = (m)message.obj;
                        if (this.a != m && m != null) {
                            if (this.a == null) {
                                break Label_0095;
                            }
                            if (this.a.b <= m.b) {
                                break Label_0080;
                            }
                            m.c();
                            synchronized (m) {
                                m.notify();
                            }
                        }
                        return;
                    }
                }
                this.a.e();
                a.a(this.a);
            }
            this.a = a;
            if (a.d) {
                this.b();
            }
            a.f();
            a.start();
        }
    }
}
