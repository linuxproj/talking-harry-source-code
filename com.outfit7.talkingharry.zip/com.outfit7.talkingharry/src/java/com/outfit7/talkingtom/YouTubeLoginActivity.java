package com.outfit7.talkingtom;

import android.content.Intent;
import android.content.SharedPreferences;
import android.view.View$OnClickListener;
import android.widget.EditText;
import android.os.Bundle;
import android.util.Log;
import android.content.DialogInterface$OnCancelListener;
import android.content.DialogInterface$OnClickListener;
import com.outfit7.b.a;
import android.content.Context;
import android.app.ProgressDialog;
import android.os.Handler;
import android.app.Activity;

public class YouTubeLoginActivity extends Activity
{
    static Handler a;
    static ProgressDialog b;
    private static final String c;
    private static boolean d;
    
    static {
        c = YouTubeLoginActivity.class.getName();
    }
    
    static void a() {
        YouTubeLoginActivity.d = true;
        if (YouTubeLoginActivity.a != null) {
            YouTubeLoginActivity.a.sendMessage(YouTubeLoginActivity.a.obtainMessage(111));
        }
    }
    
    public static void a(final Activity activity) {
        com.outfit7.talkingtom.b.a(false, activity, new fy(activity));
    }
    
    public static void a(final Activity activity, final String s, final String s2, final String s3, final String s4) {
        YouTubeLoginActivity.d = false;
        YouTubeLoginActivity.b = new ProgressDialog((Context)activity);
        final a a = new a();
        YouTubeLoginActivity.a = new fw(activity, s3, s4, s, s2, a);
        YouTubeLoginActivity.b.setCancelable(true);
        YouTubeLoginActivity.b.setProgressStyle(1);
        YouTubeLoginActivity.b.setMessage((CharSequence)activity.getString(2131099665));
        YouTubeLoginActivity.b.setButton(-2, (CharSequence)activity.getString(2131099650), (DialogInterface$OnClickListener)new ga());
        YouTubeLoginActivity.b.setOnCancelListener((DialogInterface$OnCancelListener)new gb());
        YouTubeLoginActivity.b.show();
        final gc gc = new gc(activity, a, s, s2, s3, s4, new gd(YouTubeLoginActivity.a));
        fw.a((fw)YouTubeLoginActivity.a, gc);
        gc.start();
    }
    
    public void onBackPressed() {
        this.setResult(2);
        this.finish();
    }
    
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2130903048);
        final EditText editText = (EditText)this.findViewById(2131296303);
        final EditText editText2 = (EditText)this.findViewById(2131296304);
        final EditText editText3 = (EditText)this.findViewById(2131296305);
        final EditText editText4 = (EditText)this.findViewById(2131296306);
        final SharedPreferences sharedPreferences = this.getSharedPreferences("prefs", 0);
        editText.setText((CharSequence)sharedPreferences.getString("youtubeUsername", ""));
        editText2.setText((CharSequence)sharedPreferences.getString("youtubePassword", ""));
        final Intent intent = this.getIntent();
        final String stringExtra = intent.getStringExtra("youtubeVideoTitle");
        final String stringExtra2 = intent.getStringExtra("youtubeVideoDescription");
        if (stringExtra != null) {
            editText3.setText((CharSequence)stringExtra);
        }
        if (stringExtra2 != null) {
            editText4.setText((CharSequence)stringExtra2);
        }
        this.findViewById(2131296308).setOnClickListener((View$OnClickListener)new fv(this));
        this.findViewById(2131296307).setOnClickListener((View$OnClickListener)new fx(this, editText, editText2, editText3, editText4));
    }
    
    protected void onDestroy() {
        super.onDestroy();
    }
    
    protected void onPause() {
        super.onPause();
    }
    
    protected void onRestart() {
        super.onRestart();
    }
    
    protected void onResume() {
        super.onResume();
    }
    
    protected void onStart() {
        super.onStart();
    }
    
    protected void onStop() {
        super.onStop();
    }
}
