package com.outfit7.talkingtom;

import android.app.Activity;

final class bt extends n
{
    private bs m;
    
    bt(final bs m, final Engine engine, final String s, final Activity activity) {
        this.m = m;
        engine.getClass();
        super(engine, s, activity);
    }
    
    @Override
    public final void j() {
        super.j();
        this.g();
        final int a = this.m.a.c.a(0, 2);
        final p a2 = this.a(0);
        final StringBuilder append = new StringBuilder().append("jezik_0");
        String s;
        if (a == 0) {
            s = "1";
        }
        else if (a == 1) {
            s = "3";
        }
        else {
            s = "4";
        }
        a2.b = append.append(s).toString();
    }
    
    @Override
    public final void k() {
        super.k();
        Main.d(this.m.a);
    }
}
