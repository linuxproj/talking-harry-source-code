package com.outfit7.talkingtom;

import android.view.View$OnClickListener;
import android.content.DialogInterface$OnClickListener;
import android.app.AlertDialog$Builder;
import com.a.a.c;
import com.a.a.a;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.content.Intent;
import com.a.a.g;
import android.os.Handler;
import android.app.Activity;

public class VideoUploadedToFbActivity extends Activity
{
    private static final String a;
    
    static {
        a = VideoUploadedToFbActivity.class.getName();
    }
    
    public static void a(final Activity activity) {
        new fm(activity).sendEmptyMessage(2);
    }
    
    public static void a(final Activity activity, final String s) {
        final String string = activity.getString(2131099668);
        final Intent intent = new Intent("android.intent.action.SEND");
        intent.putExtra("android.intent.extra.SUBJECT", string);
        intent.putExtra("android.intent.extra.TEXT", s);
        intent.setType("plain/text");
        activity.getString(2131099667);
        activity.startActivityForResult(intent, 1);
    }
    
    protected void onActivityResult(final int n, final int n2, final Intent intent) {
        switch (n2) {
            case 2: {
                this.setResult(1);
                this.finish();
                break;
            }
        }
    }
    
    public void onBackPressed() {
        this.setResult(1);
        this.finish();
    }
    
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2130903045);
        this.findViewById(2131296292).setOnClickListener((View$OnClickListener)new fg(this, this.getIntent().getStringExtra("facebookVideoUrl")));
        this.findViewById(2131296293).setOnClickListener((View$OnClickListener)new fh(this));
        new fm(this).sendEmptyMessage(2);
    }
}
