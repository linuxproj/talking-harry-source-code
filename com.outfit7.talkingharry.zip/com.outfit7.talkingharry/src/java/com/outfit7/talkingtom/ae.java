package com.outfit7.talkingtom;

final class ae extends m
{
    private af i;
    
    ae(final ad ad, final af i) {
        this.i = i;
        super(ad.b);
    }
    
    public final void a() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     2: invokestatic    android/os/Process.setThreadPriority:(I)V
        //     5: aload_0        
        //     6: dup            
        //     7: astore_3       
        //     8: monitorenter   
        //     9: aload_0        
        //    10: getfield        com/outfit7/talkingtom/ae.i:Lcom/outfit7/talkingtom/af;
        //    13: astore_1       
        //    14: aload_1        
        //    15: dup            
        //    16: astore          4
        //    18: monitorenter   
        //    19: aload_0        
        //    20: getfield        com/outfit7/talkingtom/ae.i:Lcom/outfit7/talkingtom/af;
        //    23: invokevirtual   java/lang/Object.notify:()V
        //    26: aload           4
        //    28: monitorexit    
        //    29: aload_0        
        //    30: invokevirtual   java/lang/Object.wait:()V
        //    33: aload_3        
        //    34: monitorexit    
        //    35: return         
        //    36: astore_2       
        //    37: aload           4
        //    39: monitorexit    
        //    40: aload_2        
        //    41: athrow         
        //    42: astore_1       
        //    43: aload_3        
        //    44: monitorexit    
        //    45: aload_1        
        //    46: athrow         
        //    47: astore_1       
        //    48: aload_1        
        //    49: athrow         
        //    50: astore_1       
        //    51: goto            33
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  5      9      47     50     Any
        //  9      19     42     47     Any
        //  19     29     36     42     Any
        //  29     33     50     54     Ljava/lang/InterruptedException;
        //  29     33     42     47     Any
        //  33     35     42     47     Any
        //  37     42     42     47     Any
        //  43     47     47     50     Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0033:
        //     at w5.m.a(SourceFile:20)
        //     at w5.f.o(SourceFile:122)
        //     at w5.f.r(SourceFile:571)
        //     at w5.f.q(SourceFile:3)
        //     at a6.j.j(SourceFile:32)
        //     at a6.j.i(SourceFile:28)
        //     at a6.i.n(SourceFile:7)
        //     at a6.i.m(SourceFile:174)
        //     at a6.i.c(SourceFile:67)
        //     at a6.i.r(SourceFile:328)
        //     at a6.i.s(SourceFile:17)
        //     at a6.i.q(SourceFile:29)
        //     at a6.i.b(SourceFile:33)
        //     at y5.d.e(SourceFile:6)
        //     at y5.d.b(SourceFile:1)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(SourceFile:306)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:131)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
        //     at e7.a.run(SourceFile:1)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        //     at java.lang.Thread.run(Thread.java:1012)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public final void c() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: dup            
        //     2: astore_3       
        //     3: monitorenter   
        //     4: aload_0        
        //     5: getfield        com/outfit7/talkingtom/ae.i:Lcom/outfit7/talkingtom/af;
        //     8: astore_2       
        //     9: aload_2        
        //    10: dup            
        //    11: astore          4
        //    13: monitorenter   
        //    14: aload_0        
        //    15: getfield        com/outfit7/talkingtom/ae.i:Lcom/outfit7/talkingtom/af;
        //    18: iconst_1       
        //    19: putfield        com/outfit7/talkingtom/af.a:Z
        //    22: aload_0        
        //    23: getfield        com/outfit7/talkingtom/ae.i:Lcom/outfit7/talkingtom/af;
        //    26: invokevirtual   java/lang/Object.notify:()V
        //    29: aload           4
        //    31: monitorexit    
        //    32: aload_0        
        //    33: invokevirtual   java/lang/Object.wait:()V
        //    36: aload_3        
        //    37: monitorexit    
        //    38: return         
        //    39: astore_1       
        //    40: aload           4
        //    42: monitorexit    
        //    43: aload_1        
        //    44: athrow         
        //    45: astore_1       
        //    46: aload_3        
        //    47: monitorexit    
        //    48: aload_1        
        //    49: athrow         
        //    50: astore_1       
        //    51: goto            36
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  4      14     45     50     Any
        //  14     32     39     45     Any
        //  32     36     50     54     Ljava/lang/InterruptedException;
        //  32     36     45     50     Any
        //  36     38     45     50     Any
        //  40     45     45     50     Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0036:
        //     at w5.m.a(SourceFile:20)
        //     at w5.f.o(SourceFile:122)
        //     at w5.f.r(SourceFile:571)
        //     at w5.f.q(SourceFile:3)
        //     at a6.j.j(SourceFile:32)
        //     at a6.j.i(SourceFile:28)
        //     at a6.i.n(SourceFile:7)
        //     at a6.i.m(SourceFile:174)
        //     at a6.i.c(SourceFile:67)
        //     at a6.i.r(SourceFile:328)
        //     at a6.i.s(SourceFile:17)
        //     at a6.i.q(SourceFile:29)
        //     at a6.i.b(SourceFile:33)
        //     at y5.d.e(SourceFile:6)
        //     at y5.d.b(SourceFile:1)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(SourceFile:306)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:131)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
        //     at e7.a.run(SourceFile:1)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        //     at java.lang.Thread.run(Thread.java:1012)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
