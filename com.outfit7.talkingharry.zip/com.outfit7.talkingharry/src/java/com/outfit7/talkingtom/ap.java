package com.outfit7.talkingtom;

import java.util.Arrays;
import android.util.Log;
import java.util.concurrent.locks.ReentrantLock;
import android.media.AudioTrack;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

abstract class ap implements Cloneable
{
    protected Lock a;
    protected Condition b;
    protected short[] c;
    protected int d;
    protected AudioTrack e;
    protected ap f;
    final Engine g;
    private int h;
    private boolean i;
    
    ap(final Engine g) {
        this.g = g;
        this.e();
    }
    
    private void e() {
        this.a = (Lock)new ReentrantLock();
        this.b = this.a.newCondition();
        this.e = null;
        this.h = 0;
    }
    
    public final ap a() {
        try {
            final ap ap = (ap)super.clone();
            ap.e();
            ap.i = true;
            ap.f = this;
            return ap;
        }
        catch (final CloneNotSupportedException ex) {
            Log.e(Engine.e, ex.getMessage(), (Throwable)ex);
            return null;
        }
    }
    
    public final ap a(int n) {
        n = this.g.j * n / 10;
        ap ap;
        if (n >= this.d) {
            ap = null;
        }
        else {
            this.d -= n;
            final short[] c = new short[this.d];
            System.arraycopy((Object)this.c, n, (Object)c, 0, this.d);
            this.c = c;
            ap = this;
        }
        return ap;
    }
    
    final short[] b() {
        short[] array;
        if (this.h >= this.d) {
            array = null;
        }
        else {
            array = new short[this.g.j / 10];
            if (this.h + array.length > this.c.length) {
                System.arraycopy((Object)this.c, this.h, (Object)array, 0, this.c.length - this.h);
                Arrays.fill(array, this.c.length - this.h, array.length, (short)0);
            }
            else {
                System.arraycopy((Object)this.c, this.h, (Object)array, 0, array.length);
            }
            this.h += array.length;
        }
        return array;
    }
    
    final void c() {
        this.h = 0;
    }
    
    final void d() {
        if (this.e != null && this.e.getState() == 1) {
            this.e.stop();
            this.e.release();
            this.g.t.b(this);
        }
    }
    
    @Override
    public final boolean equals(final Object o) {
        return o instanceof ap && ((ap)o).c == this.c;
    }
}
