package com.outfit7.talkingtom;

import android.content.ComponentName;
import android.content.Intent;
import android.view.View;
import android.view.View$OnClickListener;

final class ay implements View$OnClickListener
{
    private String a;
    private Grid b;
    
    ay(final Grid b, final String a) {
        this.b = b;
        this.a = a;
    }
    
    public final void onClick(final View view) {
        final Intent intent = new Intent("android.intent.action.MAIN");
        final String a = this.a;
        final StringBuilder sb = new StringBuilder();
        String s;
        if (this.a.endsWith("pro")) {
            s = this.a.substring(0, this.a.length() - 3);
        }
        else {
            s = this.a;
        }
        intent.setComponent(new ComponentName(a, sb.append(s).append(".Main").toString()));
        intent.putExtra("disableGrid", System.currentTimeMillis());
        this.b.startActivity(intent);
        this.b.finish();
    }
}
