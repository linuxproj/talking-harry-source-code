package com.outfit7.talkingtom;

import android.net.Uri;
import android.content.Intent;
import android.content.DialogInterface;
import android.app.Activity;
import android.content.DialogInterface$OnClickListener;

final class eq implements DialogInterface$OnClickListener
{
    private Activity a;
    private int b;
    
    eq(final Activity a, final int n) {
        this.a = a;
        this.b = 2;
    }
    
    public final void onClick(final DialogInterface dialogInterface, final int n) {
        this.a.startActivityForResult(new Intent("android.intent.action.VIEW").setData(Uri.parse(((TalkingTomApplication)this.a.getApplicationContext()).g())), this.b);
    }
}
