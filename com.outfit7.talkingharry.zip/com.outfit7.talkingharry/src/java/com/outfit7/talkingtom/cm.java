package com.outfit7.talkingtom;

import android.app.Activity;
import android.view.View;
import android.view.View$OnClickListener;

final class cm implements View$OnClickListener
{
    final cl a;
    
    cm(final cl a) {
        this.a = a;
    }
    
    public final void onClick(final View view) {
        if (this.a.a.n == this.a.a.p) {
            if (this.a.e) {
                if (this.a.f++ <= 0) {
                    final Engine a = this.a.a.c;
                    a.getClass();
                    final cn cn = new cn(this, a, "ninje/knockout", this.a.a);
                    cn.b = Integer.MAX_VALUE;
                    cn.d = true;
                    cn.i();
                    this.a.a.c.c.a().sendMessage(this.a.a.c.c.a().obtainMessage(0, (Object)cn));
                }
            }
            else {
                this.a.d = Main.a(this.a.d);
                this.a.b();
                final String a2 = ((dw)Main.b.get((Object)this.a.d)).a();
                final Engine a3 = this.a.a.c;
                a3.getClass();
                final co co = new co(this, a3, a2, this.a.a);
                co.b = 5;
                co.d = true;
                co.i();
                this.a.a.c.c.a().sendMessage(this.a.a.c.c.a().obtainMessage(0, (Object)co));
            }
        }
    }
}
