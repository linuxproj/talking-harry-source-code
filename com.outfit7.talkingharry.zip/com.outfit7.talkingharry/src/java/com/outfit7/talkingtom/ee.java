package com.outfit7.talkingtom;

import android.content.DialogInterface;
import android.content.DialogInterface$OnClickListener;

final class ee implements DialogInterface$OnClickListener
{
    private Misc$1MyLicenseCheckerCallback a;
    
    ee(final Misc$1MyLicenseCheckerCallback a) {
        this.a = a;
    }
    
    public final void onClick(final DialogInterface dialogInterface, final int n) {
        this.a.a.finish();
    }
}
