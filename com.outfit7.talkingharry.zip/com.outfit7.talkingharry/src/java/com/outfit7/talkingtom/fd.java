package com.outfit7.talkingtom;

import java.net.MalformedURLException;
import android.os.Handler;
import org.json.JSONObject;
import java.io.IOException;
import java.io.FileNotFoundException;
import com.outfit7.talkingtom.a.a;
import android.util.Log;
import android.content.DialogInterface$OnClickListener;
import android.content.Context;
import android.app.AlertDialog$Builder;
import android.app.ProgressDialog;
import android.app.Activity;
import com.a.a.c;

final class fd implements c
{
    private Activity a;
    private ProgressDialog b;
    private int c;
    private long d;
    private String e;
    private volatile boolean f;
    
    fd(final Activity a, final ProgressDialog b, final int c, final long d, final String e) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
    }
    
    private void a(Throwable a) {
        while (true) {
            try {
                this.b.dismiss();
                final String string = this.a.getString(2131099679) + a.getLocalizedMessage();
                Log.e(VideoCommentActivity.a, a.getLocalizedMessage(), a);
                a.a(this.a, a, string);
                a = (Throwable)((BackgroundActivity)this.a).a();
                ((Handler)a).sendMessage(((Handler)a).obtainMessage(2));
            }
            catch (final RuntimeException ex) {
                Log.w(VideoCommentActivity.a, ex.getLocalizedMessage(), (Throwable)ex);
                continue;
            }
            break;
        }
    }
    
    public final void a() {
        this.f = true;
    }
    
    @Override
    public final void a(final FileNotFoundException ex) {
        if (!this.f) {
            this.a((Throwable)ex);
        }
    }
    
    @Override
    public final void a(final IOException ex) {
        if (!this.f) {
            this.a((Throwable)ex);
        }
    }
    
    @Override
    public final void a(final String t) {
        if (!this.f) {
            int int1 = 0;
            long long1 = 0L;
        Label_0107:
            while (true) {
                try {
                    this.b.dismiss();
                    try {
                        final JSONObject b = com.a.a.a.b((String)t);
                        int1 = b.getInt("length");
                        long1 = b.getLong("size");
                        if (this.c > int1 || this.d > long1) {
                            break Label_0107;
                        }
                        final Handler a = ((BackgroundActivity)this.a).a();
                        a.sendMessage(a.obtainMessage(5, (Object)this.e));
                    }
                    catch (final Throwable t) {
                        this.a(t);
                    }
                    return;
                }
                catch (final RuntimeException ex) {
                    Log.w(VideoCommentActivity.a, ex.getLocalizedMessage(), (Throwable)ex);
                    continue;
                }
                break;
            }
            this.a.runOnUiThread((Runnable)new fe(this, int1, long1));
        }
    }
    
    @Override
    public final void a(final MalformedURLException ex) {
        if (!this.f) {
            this.a((Throwable)ex);
        }
    }
}
