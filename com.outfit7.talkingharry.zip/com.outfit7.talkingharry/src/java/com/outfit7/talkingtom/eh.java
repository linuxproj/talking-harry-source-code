package com.outfit7.talkingtom;

import android.graphics.Bitmap;
import java.net.URLConnection;
import java.io.InputStream;
import android.graphics.BitmapFactory;
import java.io.BufferedInputStream;
import java.net.URL;
import android.os.Handler;

final class eh extends Thread
{
    private Handler a;
    private News b;
    
    eh(final News b, final Handler a) {
        this.b = b;
        this.a = a;
    }
    
    public final void run() {
        try {
            final URLConnection openConnection = new URL(this.b.a.getString("imageUrl")).openConnection();
            openConnection.setReadTimeout(5000);
            openConnection.connect();
            final InputStream inputStream = openConnection.getInputStream();
            final BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream);
            final Bitmap decodeStream = BitmapFactory.decodeStream((InputStream)bufferedInputStream);
            bufferedInputStream.close();
            inputStream.close();
            this.a.sendMessage(this.a.obtainMessage(0, (Object)decodeStream));
        }
        catch (final Exception ex) {}
    }
}
