package com.outfit7.talkingtom;

import java.io.InputStream;
import android.content.res.AssetManager;
import java.io.IOException;
import android.util.Log;
import java.util.HashMap;
import java.util.Map;

final class au
{
    final Engine a;
    private Map b;
    
    au(final Engine a) {
        this.a = a;
        this.b = (Map)new HashMap();
    }
    
    final ap a(final String s) {
        return new av(this, (av)this.b.get((Object)s));
    }
    
    final void b(final String s) {
        try {
            Object o = this.a.g.getAssets();
            o = ((AssetManager)o).open("sounds/" + this.a.j + "/" + s + ".wav");
            try {
                ((InputStream)o).read(new byte[44]);
                final byte[] array = new byte[((InputStream)o).available()];
                ((InputStream)o).read(array, 0, ((InputStream)o).available());
                final short[] array2 = new short[array.length / 2];
                for (int i = 0; i < array2.length; ++i) {
                    array2[i] = (short)((array[i * 2 + 1] & 0xFF) << 8 | (array[i * 2] & 0xFF));
                }
                this.b.put((Object)s, (Object)new av(this, array2));
            }
            finally {
                ((InputStream)o).close();
            }
        }
        catch (final IOException ex) {
            Log.e(Engine.e, ex.getMessage(), (Throwable)ex);
        }
    }
}
