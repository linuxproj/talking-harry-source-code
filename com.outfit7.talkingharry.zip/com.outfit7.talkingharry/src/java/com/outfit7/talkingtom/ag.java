package com.outfit7.talkingtom;

final class ag extends Thread
{
    private ad a;
    
    ag(final ad a) {
        this.a = a;
    }
    
    public final void run() {
        this.a.b.a.a();
    }
}
