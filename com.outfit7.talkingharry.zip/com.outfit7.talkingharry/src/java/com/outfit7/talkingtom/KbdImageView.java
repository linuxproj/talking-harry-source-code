package com.outfit7.talkingtom;

import android.graphics.PorterDuff$Mode;
import android.util.AttributeSet;
import android.content.Context;
import android.widget.ImageView;

public class KbdImageView extends ImageView
{
    String a;
    private long b;
    private bd c;
    
    static {
        KbdImageView.class.getName();
    }
    
    public KbdImageView(final Context context) {
        this(context, null);
    }
    
    public KbdImageView(final Context context, final AttributeSet set) {
        this(context, set, 0);
    }
    
    public KbdImageView(final Context context, final AttributeSet set, final int n) {
        super(context, set, n);
        this.a = context.obtainStyledAttributes(set, es.a).getString(0);
    }
    
    final void a() {
        ++this.b;
        this.setColorFilter(-7829368, PorterDuff$Mode.MULTIPLY);
        throw new NullPointerException();
    }
    
    public final void a(final Engine engine, final Main main) {
        (this.c = new bd(this, engine, main)).a();
    }
    
    public final void a(final Engine engine, final Main main, final long n) {
        throw new NullPointerException();
    }
    
    final void b() {
        if (this.b > 0L) {
            --this.b;
        }
        throw new NullPointerException();
    }
}
