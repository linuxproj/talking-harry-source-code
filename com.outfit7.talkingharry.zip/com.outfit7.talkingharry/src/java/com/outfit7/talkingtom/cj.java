package com.outfit7.talkingtom;

final class cj extends ce
{
    private Main c;
    
    private cj(final Main c, final byte b) {
        super(this.c = c);
        this.b = 3000L;
    }
    
    @Override
    public final n c() {
        final Engine a = this.c.c;
        a.getClass();
        return new ck(this, a, "stolpnica/ocala");
    }
}
