package com.outfit7.talkingtom;

import java.util.Iterator;
import java.util.Map;
import java.io.IOException;
import android.util.Log;
import java.util.Collection;
import java.util.ArrayList;
import android.app.Activity;
import android.widget.ImageView;
import java.util.List;

class n extends m
{
    protected List i;
    protected ImageView j;
    protected List k;
    protected List l;
    private String m;
    private int n;
    private boolean o;
    private Engine p;
    
    public n(final Engine engine, final Activity activity) {
        this(engine, null, activity);
    }
    
    public n(final Engine engine, final String s) {
        this(engine, s, null);
    }
    
    public n(final Engine p3, final String m, final Activity activity) {
        super(this.p = p3);
        this.m = m;
        if (activity != null) {
            activity.getSystemService("vibrator");
        }
        this.k = (List)new ArrayList();
        this.i = (List)new ArrayList();
        this.a(m);
    }
    
    private p l() {
        p p;
        if (this.n < this.k.size()) {
            p = (p)this.k.get(this.n++);
        }
        else {
            if (this.n == this.k.size()) {
                this.h();
            }
            ++this.n;
            p = null;
        }
        return p;
    }
    
    final n a(final int n, final int n2) {
        for (int i = 0; i < n2; ++i) {
            this.b(n, n);
        }
        return this;
    }
    
    final n a(final ImageView j) {
        this.j = j;
        return this;
    }
    
    public final n a(final String s) {
        if (s != null) {
            while (true) {
                try {
                    final Map d = this.p.o;
                    synchronized (d) {
                        Object o;
                        if ((o = this.p.o.get((Object)s)) == null) {
                            o = new ArrayList();
                            final String[] list = this.p.h.list("animations/" + s);
                            for (int length = list.length, i = 0; i < length; ++i) {
                                ((List)o).add((Object)("animations/" + s + "/" + list[i]));
                            }
                            this.p.o.put((Object)s, o);
                        }
                        this.i.addAll((Collection)o);
                    }
                }
                catch (final IOException ex) {
                    Log.e(Engine.e, ex.getMessage(), (Throwable)ex);
                    continue;
                }
                break;
            }
        }
        return this;
    }
    
    final p a(final int n) {
        return (p)this.k.get(n);
    }
    
    public final void a() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     2: invokestatic    android/os/Process.setThreadPriority:(I)V
        //     5: aload_0        
        //     6: invokevirtual   com/outfit7/talkingtom/n.j:()V
        //     9: new             Lcom/outfit7/talkingtom/r;
        //    12: astore          8
        //    14: aload           8
        //    16: aload_0        
        //    17: getfield        com/outfit7/talkingtom/n.p:Lcom/outfit7/talkingtom/Engine;
        //    20: invokespecial   com/outfit7/talkingtom/r.<init>:(Lcom/outfit7/talkingtom/Engine;)V
        //    23: iconst_0       
        //    24: istore_2       
        //    25: iconst_0       
        //    26: istore          4
        //    28: iconst_0       
        //    29: istore_1       
        //    30: iload           4
        //    32: aload_0        
        //    33: getfield        com/outfit7/talkingtom/n.k:Ljava/util/List;
        //    36: invokeinterface java/util/List.size:()I
        //    41: if_icmpge       76
        //    44: aload_0        
        //    45: getfield        com/outfit7/talkingtom/n.k:Ljava/util/List;
        //    48: iload           4
        //    50: invokeinterface java/util/List.get:(I)Ljava/lang/Object;
        //    55: checkcast       Lcom/outfit7/talkingtom/p;
        //    58: astore          6
        //    60: aload_0        
        //    61: getfield        com/outfit7/talkingtom/n.a:Z
        //    64: istore          5
        //    66: iload           5
        //    68: ifeq            88
        //    71: aload_0        
        //    72: invokevirtual   com/outfit7/talkingtom/n.k:()V
        //    75: return         
        //    76: aload_0        
        //    77: ldc             -2147483648
        //    79: putfield        com/outfit7/talkingtom/n.b:I
        //    82: aconst_null    
        //    83: astore          6
        //    85: goto            60
        //    88: aload           8
        //    90: invokevirtual   com/outfit7/talkingtom/r.a:()Z
        //    93: ifeq            185
        //    96: iload           4
        //    98: aload_0        
        //    99: getfield        com/outfit7/talkingtom/n.k:Ljava/util/List;
        //   102: invokeinterface java/util/List.size:()I
        //   107: iconst_1       
        //   108: isub           
        //   109: if_icmpeq       185
        //   112: aload           6
        //   114: ifnull          125
        //   117: aload           6
        //   119: getfield        com/outfit7/talkingtom/p.b:Ljava/lang/String;
        //   122: ifnonnull       185
        //   125: aload_0        
        //   126: getfield        com/outfit7/talkingtom/n.l:Ljava/util/List;
        //   129: ifnull          738
        //   132: aload_0        
        //   133: getfield        com/outfit7/talkingtom/n.l:Ljava/util/List;
        //   136: invokeinterface java/util/List.iterator:()Ljava/util/Iterator;
        //   141: astore          6
        //   143: aload           6
        //   145: invokeinterface java/util/Iterator.hasNext:()Z
        //   150: ifeq            179
        //   153: aload           6
        //   155: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //   160: checkcast       Lcom/outfit7/talkingtom/n;
        //   163: invokespecial   com/outfit7/talkingtom/n.l:()Lcom/outfit7/talkingtom/p;
        //   166: pop            
        //   167: goto            143
        //   170: astore          6
        //   172: aload_0        
        //   173: invokevirtual   com/outfit7/talkingtom/n.k:()V
        //   176: aload           6
        //   178: athrow         
        //   179: iinc            4, 1
        //   182: goto            30
        //   185: aload_0        
        //   186: getfield        com/outfit7/talkingtom/n.a:Z
        //   189: istore          5
        //   191: iload           5
        //   193: ifeq            203
        //   196: aload_0        
        //   197: invokevirtual   com/outfit7/talkingtom/n.k:()V
        //   200: goto            75
        //   203: aload_0        
        //   204: iload_2        
        //   205: invokevirtual   com/outfit7/talkingtom/n.b:(I)V
        //   208: aload_0        
        //   209: getfield        com/outfit7/talkingtom/n.a:Z
        //   212: istore          5
        //   214: iload           5
        //   216: ifeq            226
        //   219: aload_0        
        //   220: invokevirtual   com/outfit7/talkingtom/n.k:()V
        //   223: goto            75
        //   226: aload           6
        //   228: ifnonnull       463
        //   231: aload_0        
        //   232: getfield        com/outfit7/talkingtom/n.o:Z
        //   235: istore          5
        //   237: iload           5
        //   239: ifeq            249
        //   242: aload_0        
        //   243: invokevirtual   com/outfit7/talkingtom/n.k:()V
        //   246: goto            75
        //   249: new             Lcom/outfit7/talkingtom/q;
        //   252: astore          7
        //   254: aload           7
        //   256: aload_0        
        //   257: getfield        com/outfit7/talkingtom/n.p:Lcom/outfit7/talkingtom/Engine;
        //   260: aload_0        
        //   261: getfield        com/outfit7/talkingtom/n.p:Lcom/outfit7/talkingtom/Engine;
        //   264: invokestatic    com/outfit7/talkingtom/Engine.f:(Lcom/outfit7/talkingtom/Engine;)Lcom/outfit7/talkingtom/ar;
        //   267: invokeinterface com/outfit7/talkingtom/ar.b:()I
        //   272: invokespecial   com/outfit7/talkingtom/q.<init>:(Lcom/outfit7/talkingtom/Engine;I)V
        //   275: aload_0        
        //   276: getfield        com/outfit7/talkingtom/n.p:Lcom/outfit7/talkingtom/Engine;
        //   279: getfield        com/outfit7/talkingtom/Engine.b:Lcom/outfit7/talkingtom/s;
        //   282: astore          9
        //   284: aload_0        
        //   285: getfield        com/outfit7/talkingtom/n.p:Lcom/outfit7/talkingtom/Engine;
        //   288: getfield        com/outfit7/talkingtom/Engine.b:Lcom/outfit7/talkingtom/s;
        //   291: astore          11
        //   293: new             Lcom/outfit7/talkingtom/at;
        //   296: astore          10
        //   298: aload           10
        //   300: aload           7
        //   302: iconst_1       
        //   303: ldc             "base"
        //   305: aload_0        
        //   306: getfield        com/outfit7/talkingtom/n.b:I
        //   309: invokespecial   com/outfit7/talkingtom/at.<init>:(Lcom/outfit7/talkingtom/q;ZLjava/lang/String;I)V
        //   312: aload           9
        //   314: aload           11
        //   316: iconst_4       
        //   317: aload           10
        //   319: invokevirtual   com/outfit7/talkingtom/s.obtainMessage:(ILjava/lang/Object;)Landroid/os/Message;
        //   322: invokevirtual   com/outfit7/talkingtom/s.sendMessage:(Landroid/os/Message;)Z
        //   325: pop            
        //   326: aload_0        
        //   327: getfield        com/outfit7/talkingtom/n.l:Ljava/util/List;
        //   330: ifnull          538
        //   333: aload_0        
        //   334: getfield        com/outfit7/talkingtom/n.l:Ljava/util/List;
        //   337: invokeinterface java/util/List.iterator:()Ljava/util/Iterator;
        //   342: astore          11
        //   344: aload           11
        //   346: invokeinterface java/util/Iterator.hasNext:()Z
        //   351: ifeq            538
        //   354: aload           11
        //   356: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //   361: checkcast       Lcom/outfit7/talkingtom/n;
        //   364: astore          9
        //   366: aload           9
        //   368: invokespecial   com/outfit7/talkingtom/n.l:()Lcom/outfit7/talkingtom/p;
        //   371: astore          12
        //   373: aload           12
        //   375: ifnull          344
        //   378: new             Lcom/outfit7/talkingtom/q;
        //   381: astore          10
        //   383: aload           10
        //   385: aload_0        
        //   386: getfield        com/outfit7/talkingtom/n.p:Lcom/outfit7/talkingtom/Engine;
        //   389: aload           12
        //   391: getfield        com/outfit7/talkingtom/p.a:Ljava/lang/String;
        //   394: invokespecial   com/outfit7/talkingtom/q.<init>:(Lcom/outfit7/talkingtom/Engine;Ljava/lang/String;)V
        //   397: aload_0        
        //   398: getfield        com/outfit7/talkingtom/n.p:Lcom/outfit7/talkingtom/Engine;
        //   401: getfield        com/outfit7/talkingtom/Engine.b:Lcom/outfit7/talkingtom/s;
        //   404: astore          13
        //   406: aload_0        
        //   407: getfield        com/outfit7/talkingtom/n.p:Lcom/outfit7/talkingtom/Engine;
        //   410: getfield        com/outfit7/talkingtom/Engine.b:Lcom/outfit7/talkingtom/s;
        //   413: astore          12
        //   415: new             Lcom/outfit7/talkingtom/at;
        //   418: astore          14
        //   420: aload           14
        //   422: aload           10
        //   424: iconst_1       
        //   425: aload_0        
        //   426: getfield        com/outfit7/talkingtom/n.m:Ljava/lang/String;
        //   429: aload_0        
        //   430: getfield        com/outfit7/talkingtom/n.b:I
        //   433: invokespecial   com/outfit7/talkingtom/at.<init>:(Lcom/outfit7/talkingtom/q;ZLjava/lang/String;I)V
        //   436: aload           14
        //   438: aload           9
        //   440: getfield        com/outfit7/talkingtom/n.j:Landroid/widget/ImageView;
        //   443: putfield        com/outfit7/talkingtom/at.h:Landroid/widget/ImageView;
        //   446: aload           13
        //   448: aload           12
        //   450: iconst_4       
        //   451: aload           14
        //   453: invokevirtual   com/outfit7/talkingtom/s.obtainMessage:(ILjava/lang/Object;)Landroid/os/Message;
        //   456: invokevirtual   com/outfit7/talkingtom/s.sendMessage:(Landroid/os/Message;)Z
        //   459: pop            
        //   460: goto            344
        //   463: new             Lcom/outfit7/talkingtom/q;
        //   466: astore          7
        //   468: aload           7
        //   470: aload_0        
        //   471: getfield        com/outfit7/talkingtom/n.p:Lcom/outfit7/talkingtom/Engine;
        //   474: aload           6
        //   476: getfield        com/outfit7/talkingtom/p.a:Ljava/lang/String;
        //   479: invokespecial   com/outfit7/talkingtom/q.<init>:(Lcom/outfit7/talkingtom/Engine;Ljava/lang/String;)V
        //   482: aload_0        
        //   483: getfield        com/outfit7/talkingtom/n.p:Lcom/outfit7/talkingtom/Engine;
        //   486: getfield        com/outfit7/talkingtom/Engine.b:Lcom/outfit7/talkingtom/s;
        //   489: astore          9
        //   491: aload_0        
        //   492: getfield        com/outfit7/talkingtom/n.p:Lcom/outfit7/talkingtom/Engine;
        //   495: getfield        com/outfit7/talkingtom/Engine.b:Lcom/outfit7/talkingtom/s;
        //   498: astore          10
        //   500: new             Lcom/outfit7/talkingtom/at;
        //   503: astore          11
        //   505: aload           11
        //   507: aload           7
        //   509: iconst_1       
        //   510: aload_0        
        //   511: getfield        com/outfit7/talkingtom/n.m:Ljava/lang/String;
        //   514: aload_0        
        //   515: getfield        com/outfit7/talkingtom/n.b:I
        //   518: invokespecial   com/outfit7/talkingtom/at.<init>:(Lcom/outfit7/talkingtom/q;ZLjava/lang/String;I)V
        //   521: aload           9
        //   523: aload           10
        //   525: iconst_4       
        //   526: aload           11
        //   528: invokevirtual   com/outfit7/talkingtom/s.obtainMessage:(ILjava/lang/Object;)Landroid/os/Message;
        //   531: invokevirtual   com/outfit7/talkingtom/s.sendMessage:(Landroid/os/Message;)Z
        //   534: pop            
        //   535: goto            326
        //   538: aload           6
        //   540: ifnonnull       557
        //   543: aload_0        
        //   544: getfield        com/outfit7/talkingtom/n.e:Lcom/outfit7/talkingtom/ap;
        //   547: ifnull          557
        //   550: aload_0        
        //   551: getfield        com/outfit7/talkingtom/n.e:Lcom/outfit7/talkingtom/ap;
        //   554: invokevirtual   com/outfit7/talkingtom/ap.d:()V
        //   557: aload           6
        //   559: ifnull          733
        //   562: aload           6
        //   564: getfield        com/outfit7/talkingtom/p.b:Ljava/lang/String;
        //   567: ifnull          733
        //   570: aload_0        
        //   571: getfield        com/outfit7/talkingtom/n.e:Lcom/outfit7/talkingtom/ap;
        //   574: ifnull          584
        //   577: aload_0        
        //   578: getfield        com/outfit7/talkingtom/n.e:Lcom/outfit7/talkingtom/ap;
        //   581: invokevirtual   com/outfit7/talkingtom/ap.d:()V
        //   584: aload_0        
        //   585: aload_0        
        //   586: getfield        com/outfit7/talkingtom/n.p:Lcom/outfit7/talkingtom/Engine;
        //   589: getfield        com/outfit7/talkingtom/Engine.d:Lcom/outfit7/talkingtom/au;
        //   592: aload           6
        //   594: getfield        com/outfit7/talkingtom/p.b:Ljava/lang/String;
        //   597: invokevirtual   com/outfit7/talkingtom/au.a:(Ljava/lang/String;)Lcom/outfit7/talkingtom/ap;
        //   600: putfield        com/outfit7/talkingtom/n.e:Lcom/outfit7/talkingtom/ap;
        //   603: aload_0        
        //   604: getfield        com/outfit7/talkingtom/n.e:Lcom/outfit7/talkingtom/ap;
        //   607: astore          6
        //   609: aload           6
        //   611: getfield        com/outfit7/talkingtom/ap.g:Lcom/outfit7/talkingtom/Engine;
        //   614: invokestatic    com/outfit7/talkingtom/Engine.a:(Lcom/outfit7/talkingtom/Engine;)Lcom/outfit7/talkingtom/u;
        //   617: invokestatic    com/outfit7/talkingtom/u.c:(Lcom/outfit7/talkingtom/u;)Lcom/outfit7/talkingtom/z;
        //   620: aload           6
        //   622: invokevirtual   com/outfit7/talkingtom/z.a:(Lcom/outfit7/talkingtom/ap;)V
        //   625: aload_0        
        //   626: getfield        com/outfit7/talkingtom/n.p:Lcom/outfit7/talkingtom/Engine;
        //   629: invokestatic    com/outfit7/talkingtom/Engine.b:(Lcom/outfit7/talkingtom/Engine;)Lcom/outfit7/talkingtom/ad;
        //   632: aload_0        
        //   633: getfield        com/outfit7/talkingtom/n.e:Lcom/outfit7/talkingtom/ap;
        //   636: invokevirtual   com/outfit7/talkingtom/ad.c:(Lcom/outfit7/talkingtom/ap;)V
        //   639: iconst_0       
        //   640: istore_3       
        //   641: iload_3        
        //   642: istore_1       
        //   643: aload_0        
        //   644: getfield        com/outfit7/talkingtom/n.e:Lcom/outfit7/talkingtom/ap;
        //   647: ifnull          665
        //   650: aload_0        
        //   651: getfield        com/outfit7/talkingtom/n.p:Lcom/outfit7/talkingtom/Engine;
        //   654: invokestatic    com/outfit7/talkingtom/Engine.b:(Lcom/outfit7/talkingtom/Engine;)Lcom/outfit7/talkingtom/ad;
        //   657: iload_3        
        //   658: invokevirtual   com/outfit7/talkingtom/ad.b:(I)V
        //   661: iload_3        
        //   662: iconst_1       
        //   663: iadd           
        //   664: istore_1       
        //   665: aload           7
        //   667: dup            
        //   668: astore          15
        //   670: monitorenter   
        //   671: aload           7
        //   673: getfield        com/outfit7/talkingtom/q.c:Z
        //   676: istore          5
        //   678: iload           5
        //   680: ifne            688
        //   683: aload           7
        //   685: invokevirtual   java/lang/Object.wait:()V
        //   688: aload           15
        //   690: monitorexit    
        //   691: aload_0        
        //   692: getfield        com/outfit7/talkingtom/n.a:Z
        //   695: istore          5
        //   697: iload           5
        //   699: ifeq            717
        //   702: aload_0        
        //   703: invokevirtual   com/outfit7/talkingtom/n.k:()V
        //   706: goto            75
        //   709: astore          6
        //   711: aload           15
        //   713: monitorexit    
        //   714: aload           6
        //   716: athrow         
        //   717: aload           8
        //   719: invokevirtual   com/outfit7/talkingtom/r.b:()V
        //   722: iinc            2, 1
        //   725: goto            179
        //   728: astore          6
        //   730: goto            688
        //   733: iload_1        
        //   734: istore_3       
        //   735: goto            641
        //   738: goto            179
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  9      23     170    179    Any
        //  30     60     170    179    Any
        //  60     66     170    179    Any
        //  76     82     170    179    Any
        //  88     112    170    179    Any
        //  117    125    170    179    Any
        //  125    143    170    179    Any
        //  143    167    170    179    Any
        //  185    191    170    179    Any
        //  203    214    170    179    Any
        //  231    237    170    179    Any
        //  249    326    170    179    Any
        //  326    344    170    179    Any
        //  344    373    170    179    Any
        //  378    460    170    179    Any
        //  463    535    170    179    Any
        //  543    557    170    179    Any
        //  562    584    170    179    Any
        //  584    639    170    179    Any
        //  643    661    170    179    Any
        //  665    671    170    179    Any
        //  671    678    709    717    Any
        //  683    688    728    733    Ljava/lang/InterruptedException;
        //  683    688    709    717    Any
        //  688    691    709    717    Any
        //  691    697    170    179    Any
        //  711    717    170    179    Any
        //  717    722    170    179    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0688:
        //     at w5.m.a(SourceFile:20)
        //     at w5.f.o(SourceFile:122)
        //     at w5.f.r(SourceFile:571)
        //     at w5.f.q(SourceFile:3)
        //     at a6.j.j(SourceFile:32)
        //     at a6.j.i(SourceFile:28)
        //     at a6.i.n(SourceFile:7)
        //     at a6.i.m(SourceFile:174)
        //     at a6.i.c(SourceFile:67)
        //     at a6.i.r(SourceFile:328)
        //     at a6.i.s(SourceFile:17)
        //     at a6.i.q(SourceFile:29)
        //     at a6.i.b(SourceFile:33)
        //     at y5.d.e(SourceFile:6)
        //     at y5.d.b(SourceFile:1)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(SourceFile:306)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:131)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
        //     at e7.a.run(SourceFile:1)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        //     at java.lang.Thread.run(Thread.java:1012)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public final void a(final m m) {
        if (m instanceof n) {
            final n n = (n)m;
            if (n.l != null) {
                for (final n n2 : n.l) {
                    if (n2.n <= n2.k.size()) {
                        if (n2.n == n2.k.size()) {
                            n2.h();
                        }
                        else {
                            if (this.l == null) {
                                this.l = (List)new ArrayList();
                            }
                            this.l.add((Object)n2);
                        }
                    }
                }
            }
        }
    }
    
    public final void a(final n n) {
        if (this.l == null) {
            this.l = (List)new ArrayList();
        }
        this.l.add((Object)n);
    }
    
    final n b(final int n, final int n2) {
        int n3;
        if (n2 < n) {
            n3 = -1;
        }
        else {
            n3 = 1;
        }
        int n4 = n;
        while (true) {
            if (n2 < n) {
                if (n4 < n2) {
                    break;
                }
            }
            else if (n4 > n2) {
                break;
            }
            this.k.add((Object)new p(this).a(n4));
            n4 += n3;
        }
        return this;
    }
    
    public void b(final int n) {
        if (this.k == null || n == this.k.size()) {
            this.d();
            this.b = Integer.MIN_VALUE;
        }
    }
    
    @Override
    public void c() {
        super.c();
        if (this.l != null) {
            final Iterator iterator = this.l.iterator();
            while (iterator.hasNext()) {
                ((n)iterator.next()).h();
            }
        }
    }
    
    final n g() {
        return this.b(0, this.i.size() - 1);
    }
    
    final void h() {
        this.p.a.runOnUiThread((Runnable)new o(this));
        this.p.b.sendMessage(this.p.b.obtainMessage(22, (Object)this.j));
    }
    
    final n i() {
        this.o = true;
        return this;
    }
    
    public void j() {
    }
    
    public void k() {
        if (!this.a && this.l != null) {
            for (final n n : this.l) {
                if (n.n == n.k.size()) {
                    n.h();
                }
            }
        }
    }
}
