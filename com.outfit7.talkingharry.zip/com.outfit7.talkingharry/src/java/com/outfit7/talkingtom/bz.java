package com.outfit7.talkingtom;

final class bz implements Runnable
{
    private by a;
    
    bz(final by a) {
        this.a = a;
    }
    
    public final void run() {
        if (this.a.c >= this.a.b.j) {
            this.a.b.a.j = this.a.b.b;
            this.a.b.a.k = this.a.b.c;
            this.a.a.performClick();
        }
    }
}
