package com.outfit7.talkingtom;

import android.app.Activity;

final class bp extends n
{
    private bo m;
    
    bp(final bo m, final Engine engine, final String s, final Activity activity) {
        this.m = m;
        engine.getClass();
        super(engine, s, activity);
    }
    
    @Override
    public final void f() {
        super.b = Integer.MAX_VALUE;
    }
    
    @Override
    public final void j() {
        super.j();
        this.g();
        this.a(15).b = "energyDrink";
        this.m.a.q.a();
    }
    
    @Override
    public final void k() {
        super.k();
        Main.d(this.m.a);
        if (this.a) {
            this.m.a.q.e();
        }
        else {
            this.m.a.q.e();
            Main.f(this.m.a);
        }
    }
}
