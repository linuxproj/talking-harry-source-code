package com.outfit7.talkingtom;

import android.os.Handler;
import com.outfit7.a.a;

final class gd implements a
{
    private Handler a;
    
    public gd(final Handler a) {
        this.a = a;
    }
    
    @Override
    public final void a(final float n) {
        this.a.sendMessage(this.a.obtainMessage(4, (Object)n));
    }
    
    @Override
    public final void b(final float n) {
        this.a.sendMessage(this.a.obtainMessage(7, (Object)n));
    }
}
