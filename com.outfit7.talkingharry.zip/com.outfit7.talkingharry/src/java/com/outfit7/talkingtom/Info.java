package com.outfit7.talkingtom;

import android.os.Bundle;
import android.view.View;
import android.view.View$OnClickListener;
import android.app.Activity;

public class Info extends Activity implements View$OnClickListener
{
    static {
        Info.class.getName();
    }
    
    public void onClick(final View view) {
        this.finish();
    }
    
    public void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2130903041);
        this.findViewById(2131296258).setOnClickListener((View$OnClickListener)this);
        this.findViewById(2131296259).setOnClickListener((View$OnClickListener)this);
    }
    
    protected void onDestroy() {
        super.onDestroy();
    }
    
    protected void onPause() {
        super.onPause();
    }
    
    protected void onRestart() {
        super.onRestart();
    }
    
    protected void onResume() {
        super.onResume();
    }
    
    protected void onStart() {
        super.onStart();
    }
    
    protected void onStop() {
        super.onStop();
    }
}
