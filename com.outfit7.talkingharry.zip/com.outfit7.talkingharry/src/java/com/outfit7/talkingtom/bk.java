package com.outfit7.talkingtom;

import android.content.SharedPreferences;

final class bk
{
    String a;
    private SharedPreferences b;
    
    bk(final SharedPreferences b) {
        this.b = b;
        this.a = this.b.getString("gridData", (String)null);
    }
}
