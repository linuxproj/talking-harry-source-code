package com.outfit7.talkingtom;

import android.content.DialogInterface;
import android.content.DialogInterface$OnClickListener;

final class fk implements DialogInterface$OnClickListener
{
    public final void onClick(final DialogInterface dialogInterface, final int n) {
        dialogInterface.cancel();
    }
}
