package com.outfit7.talkingtom;

import android.os.Handler;
import android.content.Context;
import android.app.ProgressDialog;
import android.widget.TextView;
import android.widget.ImageView;
import android.app.Activity;
import java.util.concurrent.locks.ReentrantLock;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.Map;
import android.os.HandlerThread;
import android.content.res.AssetManager;
import java.util.Random;

public class Engine
{
    private static final String e;
    private static Engine n;
    Main a;
    s b;
    ab c;
    au d;
    private Random f;
    private TalkingTomApplication g;
    private AssetManager h;
    private ab i;
    private int j;
    private ar k;
    private HandlerThread l;
    private t m;
    private Map o;
    private Lock p;
    private Condition q;
    private u r;
    private Object s;
    private ad t;
    private boolean u;
    private m v;
    private boolean w;
    
    static {
        e = Engine.class.getName();
        Engine.n = null;
    }
    
    private Engine(final Main a) {
        this.f = new Random();
        (this.l = new HandlerThread("internalMsgHandler")).start();
        this.m = new t(this);
        new ArrayList();
        this.o = (Map)new HashMap();
        this.p = (Lock)new ReentrantLock();
        this.q = this.p.newCondition();
        this.s = new Object();
        this.u = false;
        this.g = (TalkingTomApplication)a.getApplicationContext();
        (this.a = a).findViewById(2131296264);
        a.findViewById(2131296270);
        a.findViewById(2131296269);
        this.h = a.getAssets();
        this.j = this.g.i();
        this.d = new au(this);
    }
    
    public static Engine a() {
        if (Engine.n == null) {
            throw new RuntimeException("No engine available.");
        }
        return Engine.n;
    }
    
    public static Engine a(final Main main) {
        synchronized (Engine.class) {
            if (Engine.n == null) {
                Engine.n = new Engine(main);
            }
            return Engine.n;
        }
    }
    
    private void i() {
        synchronized (this) {
            this.t = new ad(this);
        }
    }
    
    public final int a(final int n, final int n2) {
        return this.f.nextInt(n2 - n + 1) + n;
    }
    
    final void a(final double n) {
        if (this.r != null) {
            this.r.a.a(n);
        }
    }
    
    final void a(final int n) {
        if (this.r != null) {
            this.r.a.d(n);
        }
    }
    
    final void a(final Activity activity) {
        this.b = new s(this, this.c, (ImageView)activity.findViewById(2131296264), (ImageView)activity.findViewById(2131296269), (TextView)activity.findViewById(2131296270));
    }
    
    public final void a(final ar k) {
        this.k = k;
    }
    
    public final et b() {
        this.p.lock();
        try {
            while (this.r == null) {
                try {
                    this.q.await();
                }
                catch (final InterruptedException ex) {}
            }
            return this.r.a;
        }
        finally {
            this.p.unlock();
        }
    }
    
    public final void c() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: new             Lcom/outfit7/talkingtom/u;
        //     4: dup            
        //     5: aload_0        
        //     6: invokespecial   com/outfit7/talkingtom/u.<init>:(Lcom/outfit7/talkingtom/Engine;)V
        //     9: putfield        com/outfit7/talkingtom/Engine.r:Lcom/outfit7/talkingtom/u;
        //    12: aload_0        
        //    13: getfield        com/outfit7/talkingtom/Engine.p:Ljava/util/concurrent/locks/Lock;
        //    16: invokeinterface java/util/concurrent/locks/Lock.lock:()V
        //    21: aload_0        
        //    22: getfield        com/outfit7/talkingtom/Engine.q:Ljava/util/concurrent/locks/Condition;
        //    25: invokeinterface java/util/concurrent/locks/Condition.signal:()V
        //    30: aload_0        
        //    31: getfield        com/outfit7/talkingtom/Engine.p:Ljava/util/concurrent/locks/Lock;
        //    34: invokeinterface java/util/concurrent/locks/Lock.unlock:()V
        //    39: aload_0        
        //    40: getfield        com/outfit7/talkingtom/Engine.s:Ljava/lang/Object;
        //    43: astore_1       
        //    44: aload_1        
        //    45: dup            
        //    46: astore_3       
        //    47: monitorenter   
        //    48: aload_0        
        //    49: getfield        com/outfit7/talkingtom/Engine.w:Z
        //    52: ifne            62
        //    55: aload_0        
        //    56: getfield        com/outfit7/talkingtom/Engine.s:Ljava/lang/Object;
        //    59: invokevirtual   java/lang/Object.wait:()V
        //    62: aload_3        
        //    63: monitorexit    
        //    64: aload_0        
        //    65: getfield        com/outfit7/talkingtom/Engine.r:Lcom/outfit7/talkingtom/u;
        //    68: astore_1       
        //    69: aload_1        
        //    70: dup            
        //    71: astore_3       
        //    72: monitorenter   
        //    73: aload_0        
        //    74: getfield        com/outfit7/talkingtom/Engine.r:Lcom/outfit7/talkingtom/u;
        //    77: invokevirtual   com/outfit7/talkingtom/u.start:()V
        //    80: aload_0        
        //    81: getfield        com/outfit7/talkingtom/Engine.r:Lcom/outfit7/talkingtom/u;
        //    84: invokevirtual   java/lang/Object.wait:()V
        //    87: aload_3        
        //    88: monitorexit    
        //    89: return         
        //    90: astore_1       
        //    91: aload_0        
        //    92: getfield        com/outfit7/talkingtom/Engine.p:Ljava/util/concurrent/locks/Lock;
        //    95: invokeinterface java/util/concurrent/locks/Lock.unlock:()V
        //   100: aload_1        
        //   101: athrow         
        //   102: astore_2       
        //   103: aload_3        
        //   104: monitorexit    
        //   105: aload_2        
        //   106: athrow         
        //   107: astore_2       
        //   108: aload_3        
        //   109: monitorexit    
        //   110: aload_2        
        //   111: athrow         
        //   112: astore_2       
        //   113: goto            87
        //   116: astore_2       
        //   117: goto            62
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  21     30     90     102    Any
        //  48     62     116    120    Ljava/lang/InterruptedException;
        //  48     62     102    107    Any
        //  62     64     102    107    Any
        //  73     80     107    112    Any
        //  80     87     112    116    Ljava/lang/InterruptedException;
        //  80     87     107    112    Any
        //  87     89     107    112    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 66 out of bounds for length 66
        //     at jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at jdk.internal.util.Preconditions.checkIndex(Preconditions.java:266)
        //     at java.util.Objects.checkIndex(Objects.java:359)
        //     at java.util.ArrayList.get(ArrayList.java:434)
        //     at w5.a.o(SourceFile:31)
        //     at w5.a.o(SourceFile:323)
        //     at w5.a.j(SourceFile:218)
        //     at a6.j.j(SourceFile:23)
        //     at a6.j.i(SourceFile:28)
        //     at a6.i.n(SourceFile:7)
        //     at a6.i.m(SourceFile:174)
        //     at a6.i.c(SourceFile:67)
        //     at a6.i.r(SourceFile:328)
        //     at a6.i.s(SourceFile:17)
        //     at a6.i.q(SourceFile:29)
        //     at a6.i.b(SourceFile:33)
        //     at y5.d.e(SourceFile:6)
        //     at y5.d.b(SourceFile:1)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(SourceFile:306)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:131)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
        //     at e7.a.run(SourceFile:1)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        //     at java.lang.Thread.run(Thread.java:1012)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    final ad d() {
        return this.t;
    }
    
    public final void e() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getfield        com/outfit7/talkingtom/Engine.u:Z
        //     4: ifeq            8
        //     7: return         
        //     8: aload_0        
        //     9: iconst_1       
        //    10: putfield        com/outfit7/talkingtom/Engine.u:Z
        //    13: aload_0        
        //    14: getfield        com/outfit7/talkingtom/Engine.c:Lcom/outfit7/talkingtom/ab;
        //    17: ifnonnull       124
        //    20: aload_0        
        //    21: new             Lcom/outfit7/talkingtom/ab;
        //    24: dup            
        //    25: aload_0        
        //    26: iconst_1       
        //    27: invokespecial   com/outfit7/talkingtom/ab.<init>:(Lcom/outfit7/talkingtom/Engine;Z)V
        //    30: putfield        com/outfit7/talkingtom/Engine.c:Lcom/outfit7/talkingtom/ab;
        //    33: aload_0        
        //    34: getfield        com/outfit7/talkingtom/Engine.b:Lcom/outfit7/talkingtom/s;
        //    37: aload_0        
        //    38: getfield        com/outfit7/talkingtom/Engine.c:Lcom/outfit7/talkingtom/ab;
        //    41: putfield        com/outfit7/talkingtom/s.a:Lcom/outfit7/talkingtom/ab;
        //    44: aload_0        
        //    45: getfield        com/outfit7/talkingtom/Engine.c:Lcom/outfit7/talkingtom/ab;
        //    48: astore_1       
        //    49: aload_1        
        //    50: dup            
        //    51: astore_3       
        //    52: monitorenter   
        //    53: aload_0        
        //    54: getfield        com/outfit7/talkingtom/Engine.c:Lcom/outfit7/talkingtom/ab;
        //    57: invokevirtual   com/outfit7/talkingtom/ab.start:()V
        //    60: aload_0        
        //    61: getfield        com/outfit7/talkingtom/Engine.c:Lcom/outfit7/talkingtom/ab;
        //    64: invokevirtual   java/lang/Object.wait:()V
        //    67: aload_3        
        //    68: monitorexit    
        //    69: aload_0        
        //    70: new             Lcom/outfit7/talkingtom/ab;
        //    73: dup            
        //    74: aload_0        
        //    75: iconst_0       
        //    76: invokespecial   com/outfit7/talkingtom/ab.<init>:(Lcom/outfit7/talkingtom/Engine;Z)V
        //    79: putfield        com/outfit7/talkingtom/Engine.i:Lcom/outfit7/talkingtom/ab;
        //    82: aload_0        
        //    83: getfield        com/outfit7/talkingtom/Engine.i:Lcom/outfit7/talkingtom/ab;
        //    86: astore_1       
        //    87: aload_1        
        //    88: dup            
        //    89: astore_3       
        //    90: monitorenter   
        //    91: aload_0        
        //    92: getfield        com/outfit7/talkingtom/Engine.i:Lcom/outfit7/talkingtom/ab;
        //    95: invokevirtual   com/outfit7/talkingtom/ab.start:()V
        //    98: aload_0        
        //    99: getfield        com/outfit7/talkingtom/Engine.i:Lcom/outfit7/talkingtom/ab;
        //   102: invokevirtual   java/lang/Object.wait:()V
        //   105: aload_3        
        //   106: monitorexit    
        //   107: aload_0        
        //   108: invokespecial   com/outfit7/talkingtom/Engine.i:()V
        //   111: goto            7
        //   114: astore_2       
        //   115: aload_3        
        //   116: monitorexit    
        //   117: aload_2        
        //   118: athrow         
        //   119: astore_2       
        //   120: aload_3        
        //   121: monitorexit    
        //   122: aload_2        
        //   123: athrow         
        //   124: aload_0        
        //   125: getfield        com/outfit7/talkingtom/Engine.v:Lcom/outfit7/talkingtom/m;
        //   128: ifnull          154
        //   131: aload_0        
        //   132: getfield        com/outfit7/talkingtom/Engine.v:Lcom/outfit7/talkingtom/m;
        //   135: astore_1       
        //   136: aload_1        
        //   137: dup            
        //   138: astore_3       
        //   139: monitorenter   
        //   140: aload_0        
        //   141: getfield        com/outfit7/talkingtom/Engine.v:Lcom/outfit7/talkingtom/m;
        //   144: invokevirtual   java/lang/Object.notify:()V
        //   147: aload_3        
        //   148: monitorexit    
        //   149: aload_0        
        //   150: aconst_null    
        //   151: putfield        com/outfit7/talkingtom/Engine.v:Lcom/outfit7/talkingtom/m;
        //   154: aload_0        
        //   155: getfield        com/outfit7/talkingtom/Engine.r:Lcom/outfit7/talkingtom/u;
        //   158: invokevirtual   com/outfit7/talkingtom/u.d:()V
        //   161: goto            7
        //   164: astore_2       
        //   165: aload_3        
        //   166: monitorexit    
        //   167: aload_2        
        //   168: athrow         
        //   169: astore_2       
        //   170: goto            105
        //   173: astore_2       
        //   174: goto            67
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  53     60     114    119    Any
        //  60     67     173    177    Ljava/lang/InterruptedException;
        //  60     67     114    119    Any
        //  67     69     114    119    Any
        //  91     98     119    124    Any
        //  98     105    169    173    Ljava/lang/InterruptedException;
        //  98     105    119    124    Any
        //  105    107    119    124    Any
        //  140    149    164    169    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0067:
        //     at w5.m.a(SourceFile:20)
        //     at w5.f.o(SourceFile:122)
        //     at w5.f.r(SourceFile:571)
        //     at w5.f.q(SourceFile:3)
        //     at a6.j.j(SourceFile:32)
        //     at a6.j.i(SourceFile:28)
        //     at a6.i.n(SourceFile:7)
        //     at a6.i.m(SourceFile:174)
        //     at a6.i.c(SourceFile:67)
        //     at a6.i.r(SourceFile:328)
        //     at a6.i.s(SourceFile:17)
        //     at a6.i.q(SourceFile:29)
        //     at a6.i.b(SourceFile:33)
        //     at y5.d.e(SourceFile:6)
        //     at y5.d.b(SourceFile:1)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(SourceFile:306)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:131)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
        //     at e7.a.run(SourceFile:1)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        //     at java.lang.Thread.run(Thread.java:1012)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public final void f() {
        if (this.v == null && this.c != null) {
            this.v = new j(this);
            this.v.b = 200;
            this.v.c = "stopThread";
            this.c.a().sendMessage(this.c.a().obtainMessage(0, (Object)this.v));
            this.r.c();
            this.u = false;
            this.t.a(false);
        }
    }
    
    public final void g() {
        if (this.d.b.isEmpty()) {
            final ProgressDialog progressDialog = new ProgressDialog((Context)this.a);
            progressDialog.setProgressStyle(1);
            progressDialog.setMessage((CharSequence)"Please wait...");
            progressDialog.setCancelable(false);
            final l l = new l(this, new k(progressDialog));
            this.w = false;
            progressDialog.show();
            l.start();
        }
    }
}
