package com.outfit7.talkingtom;

import android.app.Activity;
import android.widget.RelativeLayout;
import android.view.View;
import java.util.ArrayList;
import java.util.List;
import android.view.View$OnClickListener;

final class dq implements View$OnClickListener
{
    final dl a;
    private String b;
    private List c;
    private List d;
    private List e;
    private List f;
    
    dq(final dl a, final String b) {
        this.a = a;
        this.c = (List)new ArrayList();
        this.d = (List)new ArrayList();
        this.e = (List)new ArrayList();
        this.f = (List)new ArrayList();
        this.b = b;
    }
    
    final dq a(final String s, final String s2, final int n, final int n2) {
        this.c.add((Object)s);
        this.d.add((Object)s2);
        this.e.add((Object)n);
        this.f.add((Object)n2);
        return this;
    }
    
    public final void onClick(final View view) {
        if (this.a.a.n == this.a.a.o) {
            Main.d(this.a.a);
            final RelativeLayout relativeLayout = (RelativeLayout)this.a.a.findViewById(2131296263);
            final int a = this.a.a.c.a(0, this.c.size() - 1);
            final String s = (String)this.c.get(a);
            final int intValue = (int)this.f.get(a);
            final String s2 = (String)this.d.get(a);
            final int intValue2 = (int)this.e.get(a);
            final Engine a2 = this.a.a.c;
            a2.getClass();
            final dr dr = new dr(this, a2, this.b, this.a.a, s2, relativeLayout, intValue, s, intValue2);
            dr.b = 5;
            dr.d = true;
            this.a.a.c.c.a().sendMessage(this.a.a.c.c.a().obtainMessage(0, (Object)dr));
        }
    }
}
