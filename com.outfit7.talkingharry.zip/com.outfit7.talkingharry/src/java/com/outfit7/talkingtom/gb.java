package com.outfit7.talkingtom;

import android.content.DialogInterface;
import android.content.DialogInterface$OnCancelListener;

final class gb implements DialogInterface$OnCancelListener
{
    public final void onCancel(final DialogInterface dialogInterface) {
        YouTubeLoginActivity.a.sendEmptyMessage(6);
    }
}
