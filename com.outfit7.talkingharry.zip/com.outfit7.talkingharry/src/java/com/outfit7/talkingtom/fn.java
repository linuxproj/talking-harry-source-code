package com.outfit7.talkingtom;

import java.net.MalformedURLException;
import java.io.IOException;
import java.io.FileNotFoundException;
import android.util.Log;
import android.app.ProgressDialog;
import android.os.Handler;
import com.a.a.c;

final class fn implements c
{
    private Handler a;
    private ProgressDialog b;
    
    fn(final Handler a, final ProgressDialog b) {
        this.a = a;
        this.b = b;
    }
    
    private void a(final Throwable t) {
        Log.e(VideoUploadedToFbActivity.a, t.getLocalizedMessage(), t);
        while (true) {
            try {
                this.b.dismiss();
                this.a.sendEmptyMessage(3);
            }
            catch (final RuntimeException ex) {
                Log.w(VideoUploadedToFbActivity.a, ex.getLocalizedMessage(), (Throwable)ex);
                continue;
            }
            break;
        }
    }
    
    @Override
    public final void a(final FileNotFoundException ex) {
        this.a((Throwable)ex);
    }
    
    @Override
    public final void a(final IOException ex) {
        this.a((Throwable)ex);
    }
    
    @Override
    public final void a(final String p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getfield        com/outfit7/talkingtom/fn.b:Landroid/app/ProgressDialog;
        //     4: invokevirtual   android/app/ProgressDialog.dismiss:()V
        //     7: iconst_1       
        //     8: istore_3       
        //     9: aload_1        
        //    10: ldc             "false"
        //    12: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //    15: ifne            27
        //    18: aload_1        
        //    19: ldc             "true"
        //    21: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //    24: ifeq            65
        //    27: aload_1        
        //    28: invokestatic    java/lang/Boolean.parseBoolean:(Ljava/lang/String;)Z
        //    31: istore_2       
        //    32: iload_2        
        //    33: ifeq            97
        //    36: aload_0        
        //    37: getfield        com/outfit7/talkingtom/fn.a:Landroid/os/Handler;
        //    40: iconst_3       
        //    41: invokevirtual   android/os/Handler.sendEmptyMessage:(I)Z
        //    44: pop            
        //    45: return         
        //    46: astore          4
        //    48: invokestatic    com/outfit7/talkingtom/VideoUploadedToFbActivity.a:()Ljava/lang/String;
        //    51: aload           4
        //    53: invokevirtual   java/lang/RuntimeException.getLocalizedMessage:()Ljava/lang/String;
        //    56: aload           4
        //    58: invokestatic    android/util/Log.w:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
        //    61: pop            
        //    62: goto            7
        //    65: aload_1        
        //    66: invokestatic    com/a/a/a.b:(Ljava/lang/String;)Lorg/json/JSONObject;
        //    69: pop            
        //    70: iload_3        
        //    71: istore_2       
        //    72: goto            32
        //    75: astore_1       
        //    76: aload_0        
        //    77: aload_1        
        //    78: invokespecial   com/outfit7/talkingtom/fn.a:(Ljava/lang/Throwable;)V
        //    81: iload_3        
        //    82: istore_2       
        //    83: goto            32
        //    86: astore_1       
        //    87: aload_0        
        //    88: aload_1        
        //    89: invokespecial   com/outfit7/talkingtom/fn.a:(Ljava/lang/Throwable;)V
        //    92: iload_3        
        //    93: istore_2       
        //    94: goto            32
        //    97: aload_0        
        //    98: getfield        com/outfit7/talkingtom/fn.a:Landroid/os/Handler;
        //   101: iconst_4       
        //   102: invokevirtual   android/os/Handler.sendEmptyMessage:(I)Z
        //   105: pop            
        //   106: goto            45
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  0      7      46     65     Ljava/lang/RuntimeException;
        //  9      27     75     86     Lcom/a/a/h;
        //  9      27     86     97     Lorg/json/JSONException;
        //  27     32     75     86     Lcom/a/a/h;
        //  27     32     86     97     Lorg/json/JSONException;
        //  65     70     75     86     Lcom/a/a/h;
        //  65     70     86     97     Lorg/json/JSONException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0027:
        //     at w5.m.a(SourceFile:20)
        //     at w5.f.o(SourceFile:122)
        //     at w5.f.r(SourceFile:571)
        //     at w5.f.q(SourceFile:3)
        //     at a6.j.j(SourceFile:32)
        //     at a6.j.i(SourceFile:28)
        //     at a6.i.n(SourceFile:7)
        //     at a6.i.m(SourceFile:174)
        //     at a6.i.c(SourceFile:67)
        //     at a6.i.r(SourceFile:328)
        //     at a6.i.s(SourceFile:17)
        //     at a6.i.q(SourceFile:29)
        //     at a6.i.b(SourceFile:33)
        //     at y5.d.e(SourceFile:6)
        //     at y5.d.b(SourceFile:1)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(SourceFile:306)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:131)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
        //     at e7.a.run(SourceFile:1)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        //     at java.lang.Thread.run(Thread.java:1012)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public final void a(final MalformedURLException ex) {
        this.a((Throwable)ex);
    }
}
