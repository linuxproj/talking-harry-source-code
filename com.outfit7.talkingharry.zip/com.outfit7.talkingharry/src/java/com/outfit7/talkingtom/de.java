package com.outfit7.talkingtom;

import android.view.View$OnClickListener;
import android.view.View$OnTouchListener;
import android.widget.ImageView;
import android.content.SharedPreferences;

final class de
{
    final Main a;
    private SharedPreferences b;
    private dg c;
    
    private de(final Main a, final byte b) {
        this.a = a;
    }
    
    final void a() {
        while (true) {
            while (true) {
                Label_0134: {
                    synchronized (this) {
                        if (this.c == null) {
                            this.b = this.a.getSharedPreferences("prefs", 0);
                            final ImageView imageView = (ImageView)this.a.findViewById(2131296273);
                            imageView.setOnTouchListener((View$OnTouchListener)new cu());
                            imageView.setOnClickListener((View$OnClickListener)new df(this));
                            if (System.currentTimeMillis() - this.b.getLong("lastGridDownload", 0L) >= 86400000L) {
                                break Label_0134;
                            }
                            this.c = new dg(this, false);
                            this.c.start();
                        }
                        return;
                    }
                }
                this.c = new dg(this, true);
                continue;
            }
        }
    }
}
