package com.outfit7.talkingtom;

import android.content.DialogInterface;
import android.app.Activity;
import android.content.DialogInterface$OnClickListener;

final class fj implements DialogInterface$OnClickListener
{
    private Activity a;
    
    fj(final Activity a) {
        this.a = a;
    }
    
    public final void onClick(final DialogInterface dialogInterface, final int n) {
        dialogInterface.cancel();
        VideoUploadedToFbActivity.b(this.a);
    }
}
