package com.outfit7.talkingtom;

import com.a.a.h;
import com.a.a.d;
import android.os.Bundle;
import android.app.Activity;
import android.os.Handler;
import com.a.a.g;

final class fi implements g
{
    private Handler a;
    private Activity b;
    
    fi(final Handler a, final Activity b) {
        this.a = a;
        this.b = b;
    }
    
    @Override
    public final void a() {
        this.a.sendEmptyMessage(3);
    }
    
    @Override
    public final void a(final Bundle bundle) {
        new fm(this.b).sendEmptyMessage(2);
    }
    
    @Override
    public final void a(final d d) {
        this.a.sendEmptyMessage(3);
    }
    
    @Override
    public final void a(final h h) {
        this.a.sendEmptyMessage(3);
    }
}
