package com.outfit7.talkingtom;

import android.view.View;
import android.view.View$OnLongClickListener;

final class cz implements View$OnLongClickListener
{
    private cx a;
    
    cz(final cx a) {
        this.a = a;
    }
    
    public final boolean onLongClick(final View view) {
        this.a.a();
        return true;
    }
}
