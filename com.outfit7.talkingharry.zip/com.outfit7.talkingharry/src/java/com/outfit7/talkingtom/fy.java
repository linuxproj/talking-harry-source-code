package com.outfit7.talkingtom;

import android.content.DialogInterface$OnDismissListener;
import android.util.Log;
import android.app.Activity;

final class fy extends f
{
    final Activity a;
    
    fy(final Activity a) {
        this.a = a;
    }
    
    @Override
    public final void a(final g g) {
        ((TalkingTomApplication)this.a.getApplicationContext()).a(g);
        ((BackgroundActivity)this.a).a().sendEmptyMessage(4);
    }
    
    @Override
    public final void a(final Throwable t) {
        Log.e(YouTubeLoginActivity.c, t.getLocalizedMessage(), t);
        b.a(this.a, (DialogInterface$OnDismissListener)new fz(this));
    }
}
