package com.outfit7.talkingtom;

final class ca implements Runnable
{
    final bx a;
    private long b;
    
    ca(final bx a) {
        this.a = a;
        this.b = this.a.j;
    }
    
    public final void run() {
        this.a.g.lock();
        try {
            this.a.a.runOnUiThread((Runnable)new cb(this));
        }
        finally {
            this.a.g.unlock();
        }
    }
}
