package com.outfit7.talkingtom;

final class af
{
    boolean a;
}
