package com.outfit7.talkingtom;

final class bd
{
    final KbdImageView a;
    private Engine b;
    private Main c;
    
    bd(final KbdImageView a, final Engine b, final Main c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    final void a() {
        new(com.outfit7.talkingtom.be.class)();
        throw new NullPointerException();
    }
}
