package com.outfit7.talkingtom;

import android.app.Activity;

class bf extends n
{
    protected boolean m;
    
    public bf(final Activity activity) {
        throw new NullPointerException();
    }
    
    public final void l() {
        this.m = true;
    }
}
