package com.outfit7.talkingtom;

import android.content.SharedPreferences$Editor;
import org.json.JSONObject;
import android.content.SharedPreferences;
import android.util.Log;
import java.net.URL;
import org.json.JSONArray;

final class bj extends Thread
{
    private String a;
    private String b;
    private Main c;
    
    bj(final Main c, final String b) {
        this.c = c;
        this.b = b;
        this.a = this.b;
    }
    
    public final void run() {
        try {
            final SharedPreferences sharedPreferences = this.c.getSharedPreferences("prefs", 0);
            this.a = aw.a(aw.a(TalkingTomApplication.a, ((TalkingTomApplication)this.c.getApplicationContext()).h()), "friendsList").toString();
            final JSONArray jsonArray = new JSONArray(this.a);
            for (int i = 0; i < jsonArray.length(); ++i) {
                final JSONObject jsonObject = jsonArray.getJSONObject(i);
                Main.a(this.c, new URL(jsonObject.getString("gridButtonUrl").replace((CharSequence)"60.png", (CharSequence)"120.png")));
                Main.a(this.c, new URL(jsonObject.getString("iconUrl")));
            }
            final SharedPreferences$Editor edit = sharedPreferences.edit();
            edit.putString("gridData", this.a);
            edit.putLong("lastCheckOfGrid", System.currentTimeMillis());
            edit.putLong("lastGridDownload", System.currentTimeMillis());
            edit.commit();
        }
        catch (final Exception ex) {
            Log.w(Main.a, ex.getMessage(), (Throwable)ex);
        }
    }
}
