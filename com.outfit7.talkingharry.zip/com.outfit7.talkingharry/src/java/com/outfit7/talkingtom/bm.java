package com.outfit7.talkingtom;

import android.app.Activity;
import android.view.View;
import android.view.View$OnClickListener;

final class bm implements View$OnClickListener
{
    final Main a;
    
    bm(final Main a) {
        this.a = a;
    }
    
    public final void onClick(final View view) {
        final Engine a = this.a.c;
        a.getClass();
        final bn bn = new bn(this, a, "gozd/modro_kungfu_brezozadja", this.a);
        bn.b = 5;
        bn.d = true;
        bn.i();
        this.a.c.c.a().sendMessage(this.a.c.c.a().obtainMessage(0, (Object)bn));
    }
}
