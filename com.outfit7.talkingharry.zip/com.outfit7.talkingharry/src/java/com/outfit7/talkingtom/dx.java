package com.outfit7.talkingtom;

import android.app.Activity;

final class dx extends ce
{
    final Main c;
    
    dx(final Main c) {
        super(this.c = c);
        this.a();
    }
    
    @Override
    public final void a() {
        this.a = System.currentTimeMillis() + this.c.c.a(0, 1000) + 3000L;
    }
    
    @Override
    public final boolean b() {
        return this != this.c.m;
    }
    
    @Override
    public final n c() {
        final Engine a = this.c.c;
        a.getClass();
        final dy dy = new dy(this, a, this.c);
        dy.d = true;
        return dy;
    }
}
