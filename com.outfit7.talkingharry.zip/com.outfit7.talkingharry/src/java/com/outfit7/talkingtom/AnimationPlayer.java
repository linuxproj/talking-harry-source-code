package com.outfit7.talkingtom;

import android.widget.RelativeLayout$LayoutParams;
import android.view.View$OnClickListener;
import android.os.Bundle;
import android.app.Activity;

public class AnimationPlayer extends Activity
{
    public void onBackPressed() {
        Engine.a().d().b(this);
    }
    
    public void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2130903042);
        this.findViewById(2131296267).setVisibility(0);
        this.findViewById(2131296267).setOnClickListener((View$OnClickListener)new a(this));
        this.findViewById(2131296264).setKeepScreenOn(true);
        Engine.a().d().a(this);
    }
    
    protected void onPause() {
        super.onPause();
        Engine.a().d().b(this);
    }
    
    public void onWindowFocusChanged(final boolean b) {
        if (b) {
            final RelativeLayout$LayoutParams relativeLayout$LayoutParams = (RelativeLayout$LayoutParams)this.findViewById(2131296261).getLayoutParams();
            relativeLayout$LayoutParams.topMargin = 0;
            relativeLayout$LayoutParams.bottomMargin = 0;
        }
    }
}
