package com.outfit7.talkingtom;

final class cc implements Runnable
{
    private bx a;
    
    cc(final bx a) {
        this.a = a;
    }
    
    public final void run() {
        if (this.a.e.isShown()) {
            this.a.e.performLongClick();
        }
    }
}
