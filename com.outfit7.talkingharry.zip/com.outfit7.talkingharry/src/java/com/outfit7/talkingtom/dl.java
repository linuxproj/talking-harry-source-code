package com.outfit7.talkingtom;

import java.util.Iterator;
import android.app.Activity;
import android.widget.RelativeLayout$LayoutParams;
import android.view.View$OnClickListener;
import android.view.View$OnTouchListener;
import android.content.Context;
import android.view.View;
import android.widget.RelativeLayout;

final class dl extends dt
{
    final Main a;
    private int d;
    
    dl(final Main a) {
        super(this.a = a);
        this.d = 0;
        final RelativeLayout relativeLayout = (RelativeLayout)a.findViewById(2131296263);
        final View view = new View((Context)a);
        relativeLayout.addView(view);
        this.b.add((Object)view);
        view.setHapticFeedbackEnabled(false);
        view.setOnTouchListener((View$OnTouchListener)new bx(a));
        view.setOnClickListener((View$OnClickListener)new dq(this, "stolpnica/ocala").a("stolpnica/bullet", "shoot2", 5, 30));
        final RelativeLayout$LayoutParams relativeLayout$LayoutParams = (RelativeLayout$LayoutParams)view.getLayoutParams();
        relativeLayout$LayoutParams.width = -1;
        relativeLayout$LayoutParams.height = (int)(200.0 * a.f);
        final View view2 = new View((Context)a);
        relativeLayout.addView(view2);
        this.b.add((Object)view2);
        view2.setHapticFeedbackEnabled(false);
        view2.setOnTouchListener((View$OnTouchListener)new bx(a));
        view2.setOnClickListener((View$OnClickListener)new dq(this, "stolpnica/ocala").a("stolpnica/bullet", "shoot2", 5, 30));
        final RelativeLayout$LayoutParams relativeLayout$LayoutParams2 = (RelativeLayout$LayoutParams)view2.getLayoutParams();
        relativeLayout$LayoutParams2.width = -1;
        relativeLayout$LayoutParams2.height = -1;
        relativeLayout$LayoutParams2.topMargin = (int)(200.0 * a.f) + a.g;
        final View view3 = new View((Context)a);
        relativeLayout.addView(view3);
        this.b.add((Object)view3);
        view3.setHapticFeedbackEnabled(false);
        view3.setOnTouchListener((View$OnTouchListener)new bx(a));
        view3.setOnClickListener((View$OnClickListener)new dq(this, "stolpnica/izmikanje_glava_efekt").a("stolpnica/bullet", "shoot2", 5, 30).a("stolpnica/bullet", "shoot2", 5, 30).a("stolpnica/raketa", "bazooka3", 12, 60));
        final RelativeLayout$LayoutParams relativeLayout$LayoutParams3 = (RelativeLayout$LayoutParams)view3.getLayoutParams();
        relativeLayout$LayoutParams3.width = (int)(30.0 * a.f);
        relativeLayout$LayoutParams3.height = (int)(130.0 * a.f);
        relativeLayout$LayoutParams3.topMargin = (int)(70.0 * a.f) + a.g;
        relativeLayout$LayoutParams3.leftMargin = (int)(120.0 * a.f) + a.h;
        final View view4 = new View((Context)a);
        relativeLayout.addView(view4);
        this.b.add((Object)view4);
        view4.setHapticFeedbackEnabled(false);
        view4.setOnTouchListener((View$OnTouchListener)new bx(a));
        view4.setOnClickListener((View$OnClickListener)new dq(this, "stolpnica/izmikanje_roka_levo").a("stolpnica/bullet", "shoot2", 5, 30));
        final RelativeLayout$LayoutParams relativeLayout$LayoutParams4 = (RelativeLayout$LayoutParams)view4.getLayoutParams();
        relativeLayout$LayoutParams4.width = (int)(40.0 * a.f);
        relativeLayout$LayoutParams4.height = (int)(130.0 * a.f);
        relativeLayout$LayoutParams4.topMargin = (int)(70.0 * a.f) + a.g;
        relativeLayout$LayoutParams4.leftMargin = (int)(80.0 * a.f) + a.h;
        final View view5 = new View((Context)a);
        relativeLayout.addView(view5);
        this.b.add((Object)view5);
        view5.setHapticFeedbackEnabled(false);
        view5.setOnTouchListener((View$OnTouchListener)new bx(a));
        view5.setOnClickListener((View$OnClickListener)new dq(this, "stolpnica/izmikanje_roka_desno").a("stolpnica/bullet", "shoot2", 5, 30));
        final RelativeLayout$LayoutParams relativeLayout$LayoutParams5 = (RelativeLayout$LayoutParams)view5.getLayoutParams();
        relativeLayout$LayoutParams5.width = (int)(40.0 * a.f);
        relativeLayout$LayoutParams5.height = (int)(130.0 * a.f);
        relativeLayout$LayoutParams5.topMargin = (int)(70.0 * a.f) + a.g;
        relativeLayout$LayoutParams5.leftMargin = (int)(150.0 * a.f) + a.h;
        final View view6 = new View((Context)a);
        relativeLayout.addView(view6);
        this.b.add((Object)view6);
        view6.setHapticFeedbackEnabled(false);
        view6.setOnTouchListener((View$OnTouchListener)new bx(a));
        view6.setOnClickListener((View$OnClickListener)new dq(this, "stolpnica/izmikanje_noga_levo").a("stolpnica/bullet", "shoot2", 5, 30));
        final RelativeLayout$LayoutParams relativeLayout$LayoutParams6 = (RelativeLayout$LayoutParams)view6.getLayoutParams();
        relativeLayout$LayoutParams6.width = (int)(55.0 * a.f);
        relativeLayout$LayoutParams6.height = (int)(70.0 * a.f);
        relativeLayout$LayoutParams6.topMargin = (int)(200.0 * a.f) + a.g;
        relativeLayout$LayoutParams6.leftMargin = (int)(80.0 * a.f) + a.h;
        final View view7 = new View((Context)a);
        relativeLayout.addView(view7);
        this.b.add((Object)view7);
        view7.setHapticFeedbackEnabled(false);
        view7.setOnTouchListener((View$OnTouchListener)new bx(a));
        view7.setOnClickListener((View$OnClickListener)new dq(this, "stolpnica/izmikanje_noga_desno").a("stolpnica/bullet", "shoot2", 5, 30));
        final RelativeLayout$LayoutParams relativeLayout$LayoutParams7 = (RelativeLayout$LayoutParams)view7.getLayoutParams();
        relativeLayout$LayoutParams7.width = (int)(55.0 * a.f);
        relativeLayout$LayoutParams7.height = (int)(70.0 * a.f);
        relativeLayout$LayoutParams7.topMargin = (int)(200.0 * a.f) + a.g;
        relativeLayout$LayoutParams7.leftMargin = (int)(135.0 * a.f) + a.h;
    }
    
    @Override
    final boolean c() {
        boolean b;
        if (!super.c()) {
            b = false;
        }
        else {
            final RelativeLayout relativeLayout = (RelativeLayout)this.a.findViewById(2131296263);
            Main.a(this.a, 3);
            for (final View view : this.b) {
                if (view.getParent() == null) {
                    relativeLayout.addView(view);
                }
            }
            this.a.c.a(new dm(this));
            this.a.l = new cj(this.a);
            this.a.l.start();
            this.a.m = null;
            this.a.r.a();
            final Engine a = this.a.c;
            a.getClass();
            final dn dn = new dn(this, a, "stolpnica/pritece_efekt", this.a);
            dn.b = Integer.MAX_VALUE;
            dn.d = true;
            this.a.c.c.a().sendMessage(this.a.c.c.a().obtainMessage(0, (Object)dn));
            b = true;
        }
        return b;
    }
    
    @Override
    final boolean e() {
        boolean b;
        if (!super.e()) {
            b = false;
        }
        else {
            this.a.l = null;
            this.a.m = null;
            this.a.r.b();
            b = true;
        }
        return b;
    }
}
