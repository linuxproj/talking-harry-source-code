package com.outfit7.talkingtom;

import android.app.Activity;
import android.view.View;
import android.view.View$OnClickListener;

final class bs implements View$OnClickListener
{
    final Main a;
    
    bs(final Main a) {
        this.a = a;
    }
    
    public final void onClick(final View view) {
        final Engine a = this.a.c;
        a.getClass();
        final bt bt = new bt(this, a, "gozd/jezik", this.a);
        bt.b = 5;
        bt.d = true;
        this.a.c.c.a().sendMessage(this.a.c.c.a().obtainMessage(0, (Object)bt));
    }
}
