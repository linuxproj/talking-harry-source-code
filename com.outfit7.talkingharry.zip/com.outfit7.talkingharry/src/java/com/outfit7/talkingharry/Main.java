package com.outfit7.talkingharry;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;

public class Main extends Activity
{
    static {
        Main.class.getName();
    }
    
    public void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.startActivity(new Intent((Context)this, (Class)com.outfit7.talkingtom.Main.class));
        this.finish();
    }
}
