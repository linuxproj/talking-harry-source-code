package com.outfit7.a;

public interface a
{
    void a(final float p0);
    
    void b(final float p0);
}
