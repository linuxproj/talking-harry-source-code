package com.outfit7.a;

import android.graphics.BitmapFactory;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory$Options;
import android.content.res.Resources;

final class f extends e
{
    private f(final byte b) {
    }
    
    @Override
    final Bitmap a(final Resources resources, final int n, BitmapFactory$Options bitmapFactory$Options) {
        bitmapFactory$Options = new BitmapFactory$Options();
        bitmapFactory$Options.inScaled = false;
        return BitmapFactory.decodeResource(resources, n, bitmapFactory$Options);
    }
}
