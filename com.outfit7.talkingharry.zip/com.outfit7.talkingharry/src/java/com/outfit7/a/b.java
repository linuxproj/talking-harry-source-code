package com.outfit7.a;

import java.io.OutputStream;
import java.nio.charset.Charset;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;

public final class b extends MultipartEntity
{
    private a a;
    private volatile boolean b;
    
    public b(final HttpMultipartMode httpMultipartMode, final String s, final Charset charset, final a a) {
        super(httpMultipartMode, s, charset);
        this.a = a;
    }
    
    public final void a() {
        this.b = true;
    }
    
    public final void writeTo(final OutputStream outputStream) {
        super.writeTo((OutputStream)new c(this, outputStream));
    }
}
