package com.outfit7.a;

import android.graphics.BitmapFactory;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory$Options;
import android.content.res.Resources;

final class g extends e
{
    private g(final byte b) {
    }
    
    @Override
    final Bitmap a(final Resources resources, final int n, final BitmapFactory$Options bitmapFactory$Options) {
        return BitmapFactory.decodeResource(resources, n, (BitmapFactory$Options)null);
    }
}
