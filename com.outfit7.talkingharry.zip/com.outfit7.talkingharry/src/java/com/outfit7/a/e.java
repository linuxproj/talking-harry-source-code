package com.outfit7.a;

import android.graphics.BitmapFactory$Options;
import android.graphics.Bitmap;
import android.content.res.Resources;
import android.os.Build$VERSION;

public abstract class e
{
    private static e a;
    
    static {
        e a;
        if (Integer.parseInt(Build$VERSION.SDK) < 4) {
            a = new g();
        }
        else {
            a = new f();
        }
        e.a = a;
    }
    
    public static Bitmap a(final Resources resources, final int n) {
        return e.a.a(resources, n, null);
    }
    
    abstract Bitmap a(final Resources p0, final int p1, final BitmapFactory$Options p2);
}
