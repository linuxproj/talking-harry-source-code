package com.outfit7.a;

import java.io.IOException;

public final class d extends IOException
{
}
