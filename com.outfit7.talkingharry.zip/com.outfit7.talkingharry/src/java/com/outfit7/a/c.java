package com.outfit7.a;

import java.io.OutputStream;
import java.io.FilterOutputStream;

final class c extends FilterOutputStream
{
    private long a;
    private long b;
    private float c;
    private float d;
    private b e;
    
    public c(final b e, final OutputStream outputStream) {
        this.e = e;
        super(outputStream);
        this.d = 1.0f;
        this.b = e.getContentLength();
        final long b = this.b;
        this.d = (float)(Math.min(b / 1024.0, 10000.0) / b);
        e.a.b(this.b * this.d);
    }
    
    public final void write(final int n) {
        if (this.e.b) {
            throw new d();
        }
        super.write(n);
        ++this.a;
        if (this.a / (float)this.b - 0.01 > this.c || this.a == this.b) {
            this.c = this.a / (float)this.b;
            if (this.e.a != null) {
                this.e.a.a(this.a * this.d);
            }
        }
    }
}
