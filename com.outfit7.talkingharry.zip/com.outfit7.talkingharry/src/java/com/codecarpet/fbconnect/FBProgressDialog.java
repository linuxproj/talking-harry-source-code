package com.codecarpet.fbconnect;

import android.content.DialogInterface$OnDismissListener;
import android.content.DialogInterface;
import android.content.DialogInterface$OnCancelListener;
import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.os.Handler;
import android.app.ProgressDialog;

public class FBProgressDialog
{
    private static ProgressDialog instance;
    
    static {
        FBProgressDialog.instance = null;
    }
    
    static /* synthetic */ void access$1(final ProgressDialog instance) {
        FBProgressDialog.instance = instance;
    }
    
    private static void cancelProgressDialog() {
        synchronized (FBProgressDialog.class) {
            new Handler().post((Runnable)new Runnable() {
                public void run() {
                    while (true) {
                        if (FBProgressDialog.instance == null || !FBProgressDialog.instance.isShowing() || FBProgressDialog.instance == null) {
                            break Label_0027;
                        }
                        try {
                            FBProgressDialog.instance.cancel();
                            FBProgressDialog.access$1(null);
                        }
                        catch (final Exception ex) {
                            Log.e("FBProgressDialog", "Error while canceling progress dialog", (Throwable)ex);
                            continue;
                        }
                        break;
                    }
                }
            });
        }
    }
    
    public static void hide(final Context context) {
        hideProgressDialog();
    }
    
    private static void hideProgressDialog() {
        synchronized (FBProgressDialog.class) {
            new Handler().post((Runnable)new Runnable() {
                public void run() {
                    if (FBProgressDialog.instance == null) {
                        return;
                    }
                    final ProgressDialog access$0 = FBProgressDialog.instance;
                    synchronized (access$0) {
                        if (FBProgressDialog.instance == null) {
                            return;
                        }
                        try {
                            FBProgressDialog.instance.dismiss();
                        }
                        catch (final Exception ex) {
                            Log.e("FBProgressDialog", "Error while hiding progress dialog", (Throwable)ex);
                        }
                    }
                }
            });
        }
    }
    
    public static void show(final Context context, final Activity activity) {
        if (FBProgressDialog.instance != null && !FBProgressDialog.instance.isShowing()) {
            showProgressDialog(activity);
        }
        else if (FBProgressDialog.instance == null) {
            if (FBProgressDialog.instance != null && !context.equals(FBProgressDialog.instance.getContext())) {
                cancelProgressDialog();
            }
            (FBProgressDialog.instance = ProgressDialog.show(context, (CharSequence)"", (CharSequence)"Loading...", true, true)).setOnCancelListener((DialogInterface$OnCancelListener)new DialogInterface$OnCancelListener() {
                public void onCancel(final DialogInterface dialogInterface) {
                    if (FBProgressDialog.instance == null) {
                        return;
                    }
                    final ProgressDialog access$0 = FBProgressDialog.instance;
                    synchronized (access$0) {
                        FBProgressDialog.access$1(null);
                    }
                }
            });
            FBProgressDialog.instance.setOnDismissListener((DialogInterface$OnDismissListener)new DialogInterface$OnDismissListener() {
                public void onDismiss(final DialogInterface dialogInterface) {
                    if (FBProgressDialog.instance == null) {
                        return;
                    }
                    final ProgressDialog access$0 = FBProgressDialog.instance;
                    synchronized (access$0) {
                        FBProgressDialog.access$1(null);
                    }
                }
            });
            showProgressDialog(activity);
        }
        else {
            cancelProgressDialog();
        }
    }
    
    private static void showProgressDialog(final Activity activity) {
        final Class<FBProgressDialog> clazz;
        monitorenter(clazz = FBProgressDialog.class);
        Label_0025: {
            if (activity == null) {
                break Label_0025;
            }
            try {
                activity.runOnUiThread((Runnable)new Runnable() {
                    public void run() {
                        if (FBProgressDialog.instance == null || FBProgressDialog.instance == null) {
                            return;
                        }
                        try {
                            FBProgressDialog.instance.show();
                        }
                        catch (final Exception ex) {
                            Log.e("FBProgressDialog", "Error while showing progress dialog", (Throwable)ex);
                        }
                    }
                });
                return;
                new Handler().post((Runnable)new Runnable() {
                    public void run() {
                        if (FBProgressDialog.instance == null || FBProgressDialog.instance == null) {
                            return;
                        }
                        try {
                            FBProgressDialog.instance.show();
                        }
                        catch (final Exception ex) {
                            Log.e("FBProgressDialog", "Error while showing progress dialog", (Throwable)ex);
                        }
                    }
                });
            }
            finally {
                monitorexit(clazz);
            }
        }
    }
}
