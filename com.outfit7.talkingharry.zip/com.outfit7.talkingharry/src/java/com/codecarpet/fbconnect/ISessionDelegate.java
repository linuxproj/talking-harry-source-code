package com.codecarpet.fbconnect;

public interface ISessionDelegate
{
    void sessionDidLogin(final FBSession p0, final Long p1);
    
    void sessionDidLogout(final FBSession p0);
    
    void sessionWillLogout(final FBSession p0, final Long p1);
}
