package com.codecarpet.fbconnect;

import java.io.InputStream;
import java.io.Closeable;
import java.net.HttpURLConnection;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.Comparator;
import java.util.Collections;
import java.util.Collection;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.io.OutputStream;
import android.graphics.Bitmap$CompressFormat;
import android.graphics.Bitmap;
import java.io.ByteArrayOutputStream;
import java.util.Iterator;
import java.net.MalformedURLException;
import android.util.Log;
import java.util.List;
import temporary.CcUtil;
import java.util.Map$Entry;
import java.util.ArrayList;
import java.net.URL;
import java.util.HashMap;
import java.util.Date;
import java.util.Map;

public class FBRequest
{
    static final String API_FORMAT = "JSON";
    static final String API_VERSION = "1.0";
    static final String ENCODING = "UTF-8";
    private static final String LOG;
    static final String STRING_BOUNDARY = "3i2ndDfv2rTHiSisAbouNdArYfORhtTPEefj3q2f";
    static final long TIMEOUT_INTERVAL = 180L;
    static final String USER_AGENT = "FacebookConnect";
    private Object mData;
    private FBRequestDelegate mDelegate;
    private boolean mLoading;
    private String mMethod;
    private Map<String, String> mParams;
    private FBSession mSession;
    private Date mTimestamp;
    private String mUrl;
    
    static {
        LOG = FBRequest.class.getSimpleName();
    }
    
    private FBRequest(final FBSession mSession, final FBRequestDelegate mDelegate) {
        this.mUrl = null;
        this.mMethod = null;
        this.mParams = null;
        this.mData = null;
        this.mTimestamp = null;
        this.mLoading = false;
        this.mSession = mSession;
        this.mDelegate = mDelegate;
    }
    
    private void callWithAnyData(final String mMethod, final Map<String, String> map, final Object mData) {
        this.mUrl = this.urlForMethod(mMethod);
        this.mMethod = mMethod;
        HashMap mParams;
        if (map != null) {
            mParams = new HashMap((Map)map);
        }
        else {
            mParams = new HashMap();
        }
        this.mParams = (Map<String, String>)mParams;
        this.mData = mData;
        this.mParams.put((Object)"method", (Object)this.mMethod);
        this.mParams.put((Object)"api_key", (Object)this.mSession.getApiKey());
        this.mParams.put((Object)"v", (Object)"1.0");
        this.mParams.put((Object)"format", (Object)"JSON");
        if (!this.isSpecialMethod()) {
            this.mParams.put((Object)"session_key", (Object)this.mSession.getSessionKey());
            this.mParams.put((Object)"call_id", (Object)this.generateCallId());
            if (this.mSession.getSessionSecret() != null) {
                this.mParams.put((Object)"ss", (Object)"1");
            }
        }
        this.mParams.put((Object)"sig", (Object)this.generateSig());
        this.mSession.send(this);
    }
    
    private void failWithError(final Throwable t) {
        if (this.mDelegate != null) {
            this.mDelegate.requestDidFailWithError(this, t);
        }
    }
    
    private String generateCallId() {
        return String.format(Long.toString(System.currentTimeMillis()), new Object[0]);
    }
    
    private String generateGetUrl() {
        try {
            String s;
            if (new URL(this.mUrl).getPath().contains((CharSequence)"?")) {
                s = "&";
            }
            else {
                s = "?";
            }
            final ArrayList list = new ArrayList();
            for (final Map$Entry map$Entry : this.mParams.entrySet()) {
                ((List)list).add((Object)(String.valueOf((Object)map$Entry.getKey()) + "=" + (String)map$Entry.getValue()));
            }
            return String.valueOf((Object)this.mUrl) + s + CcUtil.componentsJoinedByString((List<String>)list, "&");
        }
        catch (final MalformedURLException ex) {
            Log.e(FBRequest.LOG, "Invalid URL", (Throwable)ex);
            return null;
        }
    }
    
    private byte[] generatePostBody() throws UnsupportedEncodingException, IOException {
        final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byteArrayOutputStream.write("--3i2ndDfv2rTHiSisAbouNdArYfORhtTPEefj3q2f\r\n".getBytes("UTF-8"));
        for (final Map$Entry map$Entry : this.mParams.entrySet()) {
            final String s = (String)map$Entry.getKey();
            final String s2 = (String)map$Entry.getValue();
            byteArrayOutputStream.write(("Content-Disposition: form-data; name=\"" + s + "\"\r\n\r\n").getBytes("UTF-8"));
            byteArrayOutputStream.write(s2.getBytes("UTF-8"));
            byteArrayOutputStream.write("\r\n--3i2ndDfv2rTHiSisAbouNdArYfORhtTPEefj3q2f\r\n".getBytes("UTF-8"));
        }
        if (this.mData != null) {
            if (this.mData instanceof Bitmap) {
                final Bitmap bitmap = (Bitmap)this.mData;
                byteArrayOutputStream.write("Content-Disposition: form-data; filename=\"photo\"\r\n".getBytes("UTF-8"));
                byteArrayOutputStream.write("Content-Type: image/png\r\n\r\n".getBytes("UTF-8"));
                bitmap.compress(Bitmap$CompressFormat.PNG, 0, (OutputStream)byteArrayOutputStream);
                byteArrayOutputStream.write("\r\n--3i2ndDfv2rTHiSisAbouNdArYfORhtTPEefj3q2f\r\n".getBytes("UTF-8"));
            }
            else if (this.mData instanceof byte[]) {
                final byte[] array = (byte[])this.mData;
                byteArrayOutputStream.write("Content-Disposition: form-data; filename=\"data\"\r\n".getBytes("UTF-8"));
                byteArrayOutputStream.write("Content-Type: content/unknown\r\n\r\n".getBytes("UTF-8"));
                byteArrayOutputStream.write(array);
                byteArrayOutputStream.write("\r\n--3i2ndDfv2rTHiSisAbouNdArYfORhtTPEefj3q2f\r\n".getBytes("UTF-8"));
            }
        }
        return byteArrayOutputStream.toByteArray();
    }
    
    private String generateSig() {
        final StringBuilder sb = new StringBuilder();
        final ArrayList list = new ArrayList((Collection)this.mParams.keySet());
        Collections.sort((List)list, (Comparator)CcUtil.CASE_INSENSITIVE_COMPARATOR);
        for (final String s : list) {
            sb.append(s);
            sb.append("=");
            final Object value = this.mParams.get((Object)s);
            if (value instanceof String) {
                sb.append(value);
            }
        }
        if (this.isSpecialMethod()) {
            if (this.mSession.getApiSecret() != null) {
                sb.append(this.mSession.getApiSecret());
            }
        }
        else if (this.mSession.getSessionSecret() != null) {
            sb.append(this.mSession.getSessionSecret());
        }
        else if (this.mSession.getApiSecret() != null) {
            sb.append(this.mSession.getApiSecret());
        }
        return CcUtil.generateMD5(sb.toString());
    }
    
    private void handleResponseData(String string) {
        try {
            final Object jsonResponse = this.parseJsonResponse(string);
            Label_0138: {
                if (!(jsonResponse instanceof JSONObject)) {
                    break Label_0138;
                }
                final JSONObject jsonObject = (JSONObject)jsonResponse;
                if (!jsonObject.has("error_code")) {
                    break Label_0138;
                }
                final int int1 = jsonObject.getInt("error_code");
                string = jsonObject.getString("error_msg");
                final JSONArray jsonArray = jsonObject.getJSONArray("request_args");
                final HashMap hashMap = new HashMap();
                for (int i = 0; i < jsonArray.length(); ++i) {
                    final JSONObject jsonObject2 = jsonArray.getJSONObject(i);
                    ((Map)hashMap).put((Object)jsonObject2.getString("key"), (Object)jsonObject2.getString("value"));
                }
                this.failWithError((Throwable)new FBRequestError(int1, string, (Map<String, String>)hashMap));
                return;
            }
            this.succeedWithResult(jsonResponse);
        }
        catch (final JSONException ex) {
            this.failWithError((Throwable)ex);
        }
    }
    
    private boolean isSpecialMethod() {
        return this.mMethod.equals((Object)"facebook.auth.getSession") || this.mMethod.equals((Object)"facebook.auth.createToken");
    }
    
    private Object parseJsonResponse(final String s) throws JSONException {
        Object o;
        if (s.startsWith("[")) {
            o = new JSONArray(s);
        }
        else if (s.startsWith("{")) {
            o = new JSONObject(s);
        }
        else {
            o = new JSONArray("[" + s + "]");
        }
        return o;
    }
    
    public static FBRequest request() {
        return requestWithSession(FBSession.getSession());
    }
    
    public static FBRequest requestWithDelegate(final FBRequestDelegate fbRequestDelegate) {
        return requestWithSession(FBSession.getSession(), fbRequestDelegate);
    }
    
    public static FBRequest requestWithSession(final FBSession fbSession) {
        return requestWithSession(fbSession, null);
    }
    
    public static FBRequest requestWithSession(final FBSession fbSession, final FBRequestDelegate fbRequestDelegate) {
        return new FBRequest(fbSession, fbRequestDelegate);
    }
    
    private void succeedWithResult(final Object o) {
        if (this.mDelegate != null) {
            this.mDelegate.requestDidLoad(this, o);
        }
    }
    
    private String urlForMethod(final String s) {
        return this.mSession.getApiURL();
    }
    
    public void call(final String s, final Map<String, String> map) {
        this.callWithAnyData(s, map, null);
    }
    
    public void call(final String s, final Map<String, String> map, final Bitmap bitmap) {
        this.callWithAnyData(s, map, bitmap);
    }
    
    public void call(final String s, final Map<String, String> map, final byte[] array) {
        this.callWithAnyData(s, map, array);
    }
    
    public void cancel() {
        if (this.loading() && this.mDelegate != null) {
            this.mDelegate.requestWasCancelled(this);
        }
    }
    
    public void connect() throws IOException {
        this.mLoading = true;
        try {
            if (this.mDelegate != null) {
                this.mDelegate.requestLoading(this);
            }
            Label_0354: {
                if (this.mMethod == null) {
                    break Label_0354;
                }
                Object mTimestamp = this.mUrl;
                Object string = mTimestamp;
                if (!((String)mTimestamp).endsWith("/")) {
                    string = String.valueOf(mTimestamp) + "/";
                }
                final URL url = new URL((String)string);
                HttpURLConnection httpURLConnection = null;
                final Date date = null;
                Object outputStream = null;
                Object o2;
                final Object o = o2 = null;
                mTimestamp = date;
                try {
                    final HttpURLConnection httpURLConnection2 = httpURLConnection = (HttpURLConnection)url.openConnection();
                    o2 = o;
                    mTimestamp = date;
                    httpURLConnection2.setRequestProperty("User-Agent", "FacebookConnect");
                    httpURLConnection = httpURLConnection2;
                    o2 = o;
                    mTimestamp = date;
                    byte[] generatePostBody = null;
                    httpURLConnection = httpURLConnection2;
                    o2 = o;
                    mTimestamp = date;
                    if (this.mMethod != null) {
                        httpURLConnection = httpURLConnection2;
                        o2 = o;
                        mTimestamp = date;
                        httpURLConnection2.setRequestMethod("POST");
                        httpURLConnection = httpURLConnection2;
                        o2 = o;
                        mTimestamp = date;
                        httpURLConnection2.setRequestProperty("Content-Type", "multipart/form-data; boundary=3i2ndDfv2rTHiSisAbouNdArYfORhtTPEefj3q2f");
                        httpURLConnection = httpURLConnection2;
                        o2 = o;
                        mTimestamp = date;
                        generatePostBody = this.generatePostBody();
                    }
                    httpURLConnection = httpURLConnection2;
                    o2 = o;
                    mTimestamp = date;
                    httpURLConnection2.setDoOutput(true);
                    httpURLConnection = httpURLConnection2;
                    o2 = o;
                    mTimestamp = date;
                    httpURLConnection2.connect();
                    if (generatePostBody != null) {
                        httpURLConnection = httpURLConnection2;
                        o2 = o;
                        mTimestamp = date;
                        outputStream = httpURLConnection2.getOutputStream();
                        httpURLConnection = httpURLConnection2;
                        o2 = o;
                        mTimestamp = outputStream;
                        ((OutputStream)outputStream).write(generatePostBody);
                    }
                    httpURLConnection = httpURLConnection2;
                    o2 = o;
                    mTimestamp = outputStream;
                    final InputStream inputStream = httpURLConnection2.getInputStream();
                    httpURLConnection = httpURLConnection2;
                    o2 = inputStream;
                    mTimestamp = outputStream;
                    final String string2 = CcUtil.getResponse(inputStream).toString();
                    CcUtil.close((Closeable)inputStream);
                    CcUtil.close((Closeable)outputStream);
                    CcUtil.disconnect(httpURLConnection2);
                    mTimestamp = new Date();
                    this.mTimestamp = (Date)mTimestamp;
                    this.handleResponseData(string2);
                    return;
                    mTimestamp = this.generateGetUrl();
                }
                finally {
                    CcUtil.close((Closeable)o2);
                    CcUtil.close((Closeable)mTimestamp);
                    CcUtil.disconnect(httpURLConnection);
                }
            }
        }
        finally {
            this.mLoading = false;
        }
    }
    
    public FBRequestDelegate getDelegate() {
        return this.mDelegate;
    }
    
    public String getMethod() {
        return this.mMethod;
    }
    
    public Map<String, String> getParams() {
        return this.mParams;
    }
    
    public Date getTimestamp() {
        return this.mTimestamp;
    }
    
    public String getUrl() {
        return this.mUrl;
    }
    
    public boolean loading() {
        return this.mLoading;
    }
    
    public void post(final String mUrl, final Map<String, String> map) {
        this.mUrl = mUrl;
        HashMap mParams;
        if (map != null) {
            mParams = new HashMap((Map)map);
        }
        else {
            mParams = new HashMap();
        }
        this.mParams = (Map<String, String>)mParams;
        this.mSession.send(this);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("<FBRequest ");
        String s;
        if (this.mMethod != null) {
            s = this.mMethod;
        }
        else {
            s = this.mUrl;
        }
        return sb.append(s).append(">").toString();
    }
    
    public abstract static class FBRequestDelegate implements IRequestDelegate
    {
        @Override
        public void requestDidFailWithError(final FBRequest fbRequest, final Throwable t) {
        }
        
        @Override
        public void requestDidLoad(final FBRequest fbRequest, final Object o) {
        }
        
        @Override
        public void requestLoading(final FBRequest fbRequest) {
        }
        
        @Override
        public void requestWasCancelled(final FBRequest fbRequest) {
        }
    }
}
