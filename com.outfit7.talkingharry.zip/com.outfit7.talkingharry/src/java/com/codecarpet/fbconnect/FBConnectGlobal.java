package com.codecarpet.fbconnect;

import java.util.List;

public class FBConnectGlobal
{
    public static List FBCreateNonRetainingArray() {
        return null;
    }
}
