package com.codecarpet.fbconnect;

import android.graphics.Bitmap;
import android.app.Dialog;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.net.URISyntaxException;
import android.util.Log;
import java.net.HttpURLConnection;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import java.net.URI;
import java.net.MalformedURLException;
import java.util.Iterator;
import java.util.Map$Entry;
import java.util.Map;
import android.graphics.RectF;
import android.graphics.Paint$Style;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Canvas;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation$AnimationListener;
import android.view.animation.ScaleAnimation;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.widget.RelativeLayout$LayoutParams;
import android.view.MotionEvent;
import android.view.View$OnTouchListener;
import android.view.View;
import android.graphics.drawable.Drawable;
import android.graphics.Typeface;
import android.view.ViewGroup$LayoutParams;
import android.widget.FrameLayout$LayoutParams;
import android.content.Context;
import temporary.CcUtil;
import android.webkit.WebView;
import android.widget.TextView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import java.net.URL;
import android.widget.ImageView;
import android.app.Activity;
import android.widget.LinearLayout;
import android.widget.ImageButton;
import android.widget.FrameLayout;

public class FBDialog extends FrameLayout
{
    private static final int BORDER_BLACK;
    private static final int BORDER_BLUE;
    private static final int BORDER_GRAY;
    private static final String DEFAULT_TITLE = "Connect to Facebook";
    private static final int FACEBOOK_BLUE;
    private static final String LOG;
    private static final String STRING_BOUNDARY = "3i2ndDfv2rTHiSisAbouNdArYfORhtTPEefj3q2f";
    private static final int kBorderWidth = 10;
    private static final int kPadding = 10;
    private static final int kTitleMarginX = 8;
    private static final int kTitleMarginY = 4;
    private static final int kTransitionDuration = 200;
    private ImageButton mCloseButton;
    private LinearLayout mContent;
    protected Activity mContext;
    private IDialogDelegate mDelegate;
    private ImageView mIconView;
    private URL mLoadingURL;
    private int mOrientation;
    private RelativeLayout mProgressWrapper;
    protected FBSession mSession;
    private boolean mShowingKeyboard;
    private ProgressBar mSpinner;
    private TextView mTitleLabel;
    protected WebView mWebView;
    
    static {
        LOG = FBDialog.class.getSimpleName();
        FACEBOOK_BLUE = CcUtil.rgbFloatToInt(0.42578125f, 0.515625f, 0.703125f, 1.0f);
        BORDER_GRAY = CcUtil.rgbFloatToInt(0.3f, 0.3f, 0.3f, 0.8f);
        BORDER_BLACK = CcUtil.rgbFloatToInt(0.3f, 0.3f, 0.3f, 1.0f);
        BORDER_BLUE = CcUtil.rgbFloatToInt(0.23f, 0.35f, 0.6f, 1.0f);
    }
    
    public FBDialog(final Activity mContext, final FBSession mSession) {
        super((Context)mContext);
        this.mContext = mContext;
        this.mDelegate = null;
        this.mSession = mSession;
        this.mLoadingURL = null;
        this.mOrientation = -1;
        this.setWillNotDraw(this.mShowingKeyboard = false);
        this.setPadding(20, 20, 20, 20);
        (this.mContent = new LinearLayout((Context)mContext)).setOrientation(1);
        this.mContent.setBackgroundColor(-1);
        this.mContent.setLayoutParams((ViewGroup$LayoutParams)new FrameLayout$LayoutParams(-1, -1));
        final RelativeLayout relativeLayout = new RelativeLayout((Context)mContext);
        relativeLayout.setLayoutParams((ViewGroup$LayoutParams)new FrameLayout$LayoutParams(-1, -2));
        (this.mTitleLabel = new TextView((Context)mContext)).setText((CharSequence)"Connect to Facebook");
        this.mTitleLabel.setBackgroundColor(FBDialog.FACEBOOK_BLUE);
        this.mTitleLabel.setTextColor(-1);
        this.mTitleLabel.setTypeface(Typeface.DEFAULT_BOLD);
        this.mTitleLabel.setPadding(8, 4, 8, 4);
        this.mTitleLabel.setLayoutParams((ViewGroup$LayoutParams)new FrameLayout$LayoutParams(-1, -2));
        final Drawable drawable = CcUtil.getDrawable(this.getClass(), "com/codecarpet/fbconnect/resources/fbicon.png");
        final Drawable drawable2 = CcUtil.getDrawable(this.getClass(), "com/codecarpet/fbconnect/resources/close.png");
        this.mTitleLabel.setCompoundDrawablePadding(5);
        this.mTitleLabel.setCompoundDrawablesWithIntrinsicBounds(drawable, (Drawable)null, (Drawable)null, (Drawable)null);
        relativeLayout.addView((View)this.mTitleLabel);
        (this.mCloseButton = new ImageButton((Context)mContext)).setBackgroundColor(0);
        this.mCloseButton.setImageDrawable(drawable2);
        this.mCloseButton.setOnTouchListener((View$OnTouchListener)new View$OnTouchListener(this) {
            final FBDialog this$0;
            
            public boolean onTouch(final View view, final MotionEvent motionEvent) {
                boolean b = false;
                switch (motionEvent.getAction()) {
                    default: {
                        b = false;
                        break;
                    }
                    case 0: {
                        this.this$0.mTitleLabel.setBackgroundColor(FBDialog.BORDER_GRAY);
                        b = true;
                        break;
                    }
                    case 1: {
                        this.this$0.mTitleLabel.setBackgroundColor(FBDialog.FACEBOOK_BLUE);
                        this.this$0.dismiss(true);
                        b = true;
                        break;
                    }
                }
                return b;
            }
        });
        final RelativeLayout$LayoutParams relativeLayout$LayoutParams = new RelativeLayout$LayoutParams(-2, -2);
        relativeLayout$LayoutParams.addRule(11);
        relativeLayout.addView((View)this.mCloseButton, (ViewGroup$LayoutParams)relativeLayout$LayoutParams);
        this.mContent.addView((View)relativeLayout);
        (this.mWebView = new WebView((Context)mContext)).setLayoutParams((ViewGroup$LayoutParams)new FrameLayout$LayoutParams(-1, -1));
        this.mWebView.setWebViewClient((WebViewClient)new WebViewClientImpl((WebViewClientImpl)null));
        final WebSettings settings = this.mWebView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDefaultTextEncodingName("UTF-8");
        this.mContent.addView((View)this.mWebView);
        this.addView((View)this.mContent);
    }
    
    private void bounce1AnimationStopped() {
        final ScaleAnimation scaleAnimation = new ScaleAnimation(1.1f, 0.9f, 1.1f, 0.9f, 1, 0.5f, 1, 0.5f);
        scaleAnimation.setDuration(100L);
        scaleAnimation.setAnimationListener((Animation$AnimationListener)new Animation$AnimationListener(this) {
            final FBDialog this$0;
            
            public void onAnimationEnd(final Animation animation) {
                this.this$0.bounce2AnimationStopped();
            }
            
            public void onAnimationRepeat(final Animation animation) {
            }
            
            public void onAnimationStart(final Animation animation) {
            }
        });
        this.startAnimation((Animation)scaleAnimation);
    }
    
    private void bounce2AnimationStopped() {
        final ScaleAnimation scaleAnimation = new ScaleAnimation(0.9f, 1.0f, 0.9f, 1.0f, 1, 0.5f, 1, 0.5f);
        scaleAnimation.setDuration(100L);
        this.startAnimation((Animation)scaleAnimation);
    }
    
    private void cancel() {
        this.dismissWithSuccess(false, true);
    }
    
    private void dismiss(final boolean b) {
        this.dialogWillDisappear();
        this.mLoadingURL = null;
        if (b) {
            final AlphaAnimation alphaAnimation = new AlphaAnimation(1.0f, 0.0f);
            alphaAnimation.setDuration(200L);
            this.postDismissCleanup();
            this.startAnimation((Animation)alphaAnimation);
        }
        else {
            this.postDismissCleanup();
        }
    }
    
    private void drawRect(final Canvas canvas, final Rect rect, final int color, final float n) {
        final Paint paint = new Paint();
        paint.setStyle(Paint$Style.FILL);
        paint.setColor(color);
        paint.setAntiAlias(true);
        if (n > 0.0f) {
            canvas.drawRoundRect(new RectF(rect), n, n, paint);
        }
        else {
            canvas.drawRect(rect, paint);
        }
    }
    
    private String generatePostBody(final Map<String, String> map) {
        final StringBuilder sb = new StringBuilder();
        final StringBuilder append = new StringBuilder("\r\n--").append("3i2ndDfv2rTHiSisAbouNdArYfORhtTPEefj3q2f").append("\r\n");
        sb.append("--").append("3i2ndDfv2rTHiSisAbouNdArYfORhtTPEefj3q2f").append("\r\n");
        for (final Map$Entry map$Entry : map.entrySet()) {
            sb.append("Content-Disposition: form-data; name=\"").append((String)map$Entry.getKey()).append("\"\r\n\r\n");
            final String s = (String)map$Entry.getValue();
            if ("user_message_prompt".equals(map$Entry.getKey())) {
                sb.append(s);
            }
            else {
                sb.append(CcUtil.encode((CharSequence)s));
            }
            sb.append((CharSequence)append);
        }
        return sb.toString();
    }
    
    private URL generateURL(final String s, final Map<String, String> map) throws MalformedURLException {
        final StringBuilder sb = new StringBuilder(s);
        final Iterator iterator = map.entrySet().iterator();
        if (iterator.hasNext()) {
            sb.append('?');
        }
        while (iterator.hasNext()) {
            final Map$Entry map$Entry = (Map$Entry)iterator.next();
            sb.append((String)map$Entry.getKey());
            sb.append('=');
            sb.append(CcUtil.encode((CharSequence)map$Entry.getValue()));
            if (iterator.hasNext()) {
                sb.append('&');
            }
        }
        return new URL(sb.toString());
    }
    
    private void postDismissCleanup() {
        this.mContext.finish();
    }
    
    private void strokeLines(final Canvas canvas, final RectF rectF, final int color) {
        final Paint paint = new Paint();
        paint.setStyle(Paint$Style.STROKE);
        paint.setColor(color);
        paint.setStrokeWidth(1.0f);
        canvas.drawRect(0.5f, 0.5f, 0.5f, 0.5f, paint);
    }
    
    protected void dialogDidSucceed(final URI uri) {
        this.dismissWithSuccess(true, true);
    }
    
    protected void dialogWillAppear() {
    }
    
    protected void dialogWillDisappear() {
    }
    
    protected void dismissWithError(final Throwable t, final boolean b) {
        this.mDelegate.dialogDidFailWithError(this, t);
        this.dismiss(b);
    }
    
    protected void dismissWithSuccess(final boolean b, final boolean b2) {
        if (this.mDelegate != null) {
            if (b) {
                this.mDelegate.dialogDidSucceed(this);
            }
            else {
                this.mDelegate.dialogDidCancel(this);
            }
        }
        this.dismiss(b2);
    }
    
    public IDialogDelegate getDelegate() {
        return this.mDelegate;
    }
    
    public FBSession getSession() {
        return this.mSession;
    }
    
    public String getTitle() {
        return this.mTitleLabel.getText().toString();
    }
    
    protected void load() {
    }
    
    protected void loadURL(final String s, final String s2, final Map<String, String> map, final Map<String, String> map2) throws MalformedURLException {
        this.loadURL(s, s2, map, map2, true);
    }
    
    protected void loadURL(final String ex, final String requestMethod, final Map<String, String> map, final Map<String, String> map2, final boolean b) throws MalformedURLException {
        final CookieSyncManager instance = CookieSyncManager.createInstance((Context)this.mContext);
        final CookieManager instance2 = CookieManager.getInstance();
        instance2.setAcceptCookie(true);
        this.mLoadingURL = this.generateURL((String)ex, map);
        HttpURLConnection httpURLConnection = null;
        HttpURLConnection httpURLConnection2 = null;
        HttpURLConnection httpURLConnection3 = null;
        final Closeable closeable = null;
        final Closeable closeable2 = null;
        final Closeable closeable3 = null;
        final Closeable closeable4 = null;
        final Closeable closeable5 = null;
        final Closeable closeable6 = null;
        final Closeable closeable7 = null;
        final Closeable closeable8 = null;
        Object o = closeable5;
        Object o2 = closeable;
        Object o3 = closeable6;
        Object o4 = closeable2;
        Object o5 = closeable7;
        Object o6 = closeable3;
        try {
            final HttpURLConnection httpURLConnection4 = httpURLConnection3 = (HttpURLConnection)this.mLoadingURL.openConnection();
            o = closeable5;
            o2 = closeable;
            httpURLConnection = httpURLConnection4;
            o3 = closeable6;
            o4 = closeable2;
            httpURLConnection2 = httpURLConnection4;
            o5 = closeable7;
            o6 = closeable3;
            httpURLConnection4.setDoOutput(true);
            httpURLConnection3 = httpURLConnection4;
            o = closeable5;
            o2 = closeable;
            httpURLConnection = httpURLConnection4;
            o3 = closeable6;
            o4 = closeable2;
            httpURLConnection2 = httpURLConnection4;
            o5 = closeable7;
            o6 = closeable3;
            httpURLConnection4.setDoInput(true);
            o6 = closeable8;
            o5 = closeable4;
            if (requestMethod != null) {
                httpURLConnection3 = httpURLConnection4;
                o = closeable5;
                o2 = closeable;
                httpURLConnection = httpURLConnection4;
                o3 = closeable6;
                o4 = closeable2;
                httpURLConnection2 = httpURLConnection4;
                o5 = closeable7;
                o6 = closeable3;
                httpURLConnection4.setRequestMethod(requestMethod);
                httpURLConnection3 = httpURLConnection4;
                o = closeable5;
                o2 = closeable;
                httpURLConnection = httpURLConnection4;
                o3 = closeable6;
                o4 = closeable2;
                httpURLConnection2 = httpURLConnection4;
                o5 = closeable7;
                o6 = closeable3;
                if ("POST".equals((Object)requestMethod)) {
                    httpURLConnection3 = httpURLConnection4;
                    o = closeable5;
                    o2 = closeable;
                    httpURLConnection = httpURLConnection4;
                    o3 = closeable6;
                    o4 = closeable2;
                    httpURLConnection2 = httpURLConnection4;
                    o5 = closeable7;
                    o6 = closeable3;
                    httpURLConnection4.setRequestProperty("Content-Type", "multipart/form-data; boundary=3i2ndDfv2rTHiSisAbouNdArYfORhtTPEefj3q2f");
                }
                if (b) {
                    httpURLConnection3 = httpURLConnection4;
                    o = closeable5;
                    o2 = closeable;
                    httpURLConnection = httpURLConnection4;
                    o3 = closeable6;
                    o4 = closeable2;
                    httpURLConnection2 = httpURLConnection4;
                    o5 = closeable7;
                    o6 = closeable3;
                    httpURLConnection4.setRequestProperty("Cookie", instance2.getCookie((String)ex));
                }
                httpURLConnection3 = httpURLConnection4;
                o = closeable5;
                o2 = closeable;
                httpURLConnection = httpURLConnection4;
                o3 = closeable6;
                o4 = closeable2;
                httpURLConnection2 = httpURLConnection4;
                o5 = closeable7;
                o6 = closeable3;
                httpURLConnection4.connect();
                httpURLConnection3 = httpURLConnection4;
                o = closeable5;
                o2 = closeable;
                httpURLConnection = httpURLConnection4;
                o3 = closeable6;
                o4 = closeable2;
                httpURLConnection2 = httpURLConnection4;
                o5 = closeable7;
                o6 = closeable3;
                final OutputStream outputStream = httpURLConnection4.getOutputStream();
                httpURLConnection3 = httpURLConnection4;
                o = closeable5;
                o2 = outputStream;
                httpURLConnection = httpURLConnection4;
                o3 = closeable6;
                o4 = outputStream;
                httpURLConnection2 = httpURLConnection4;
                o5 = closeable7;
                o6 = outputStream;
                if ("POST".equals((Object)requestMethod)) {
                    httpURLConnection3 = httpURLConnection4;
                    o = closeable5;
                    o2 = outputStream;
                    httpURLConnection = httpURLConnection4;
                    o3 = closeable6;
                    o4 = outputStream;
                    httpURLConnection2 = httpURLConnection4;
                    o5 = closeable7;
                    o6 = outputStream;
                    final String generatePostBody = this.generatePostBody(map2);
                    if (generatePostBody != null) {
                        httpURLConnection3 = httpURLConnection4;
                        o = closeable5;
                        o2 = outputStream;
                        httpURLConnection = httpURLConnection4;
                        o3 = closeable6;
                        o4 = outputStream;
                        httpURLConnection2 = httpURLConnection4;
                        o5 = closeable7;
                        o6 = outputStream;
                        outputStream.write(generatePostBody.getBytes("UTF-8"));
                    }
                }
                httpURLConnection3 = httpURLConnection4;
                o = closeable5;
                o2 = outputStream;
                httpURLConnection = httpURLConnection4;
                o3 = closeable6;
                o4 = outputStream;
                httpURLConnection2 = httpURLConnection4;
                o5 = closeable7;
                o6 = outputStream;
                final InputStream inputStream = httpURLConnection4.getInputStream();
                httpURLConnection3 = httpURLConnection4;
                o = inputStream;
                o2 = outputStream;
                httpURLConnection = httpURLConnection4;
                o3 = inputStream;
                o4 = outputStream;
                httpURLConnection2 = httpURLConnection4;
                o5 = inputStream;
                o6 = outputStream;
                final String string = CcUtil.getResponse(inputStream).toString();
                if (string != "") {
                    int n = 0;
                    while (true) {
                        httpURLConnection3 = httpURLConnection4;
                        o = inputStream;
                        o2 = outputStream;
                        httpURLConnection = httpURLConnection4;
                        o3 = inputStream;
                        o4 = outputStream;
                        httpURLConnection2 = httpURLConnection4;
                        o5 = inputStream;
                        o6 = outputStream;
                        final String headerFieldKey = httpURLConnection4.getHeaderFieldKey(n);
                        httpURLConnection3 = httpURLConnection4;
                        o = inputStream;
                        o2 = outputStream;
                        httpURLConnection = httpURLConnection4;
                        o3 = inputStream;
                        o4 = outputStream;
                        httpURLConnection2 = httpURLConnection4;
                        o5 = inputStream;
                        o6 = outputStream;
                        final String headerField = httpURLConnection4.getHeaderField(n);
                        if (headerFieldKey == null) {
                            if (headerField == null) {
                                break;
                            }
                        }
                        else {
                            httpURLConnection3 = httpURLConnection4;
                            o = inputStream;
                            o2 = outputStream;
                            httpURLConnection = httpURLConnection4;
                            o3 = inputStream;
                            o4 = outputStream;
                            httpURLConnection2 = httpURLConnection4;
                            o5 = inputStream;
                            o6 = outputStream;
                            final String log = FBDialog.LOG;
                            httpURLConnection3 = httpURLConnection4;
                            o = inputStream;
                            o2 = outputStream;
                            httpURLConnection = httpURLConnection4;
                            o3 = inputStream;
                            o4 = outputStream;
                            httpURLConnection2 = httpURLConnection4;
                            o5 = inputStream;
                            o6 = outputStream;
                            httpURLConnection3 = httpURLConnection4;
                            o = inputStream;
                            o2 = outputStream;
                            httpURLConnection = httpURLConnection4;
                            o3 = inputStream;
                            o4 = outputStream;
                            httpURLConnection2 = httpURLConnection4;
                            o5 = inputStream;
                            o6 = outputStream;
                            final StringBuilder sb = new StringBuilder("url header: ");
                            httpURLConnection3 = httpURLConnection4;
                            o = inputStream;
                            o2 = outputStream;
                            httpURLConnection = httpURLConnection4;
                            o3 = inputStream;
                            o4 = outputStream;
                            httpURLConnection2 = httpURLConnection4;
                            o5 = inputStream;
                            o6 = outputStream;
                            Log.i(log, sb.append(headerFieldKey).append("=").append(headerField).toString());
                            httpURLConnection3 = httpURLConnection4;
                            o = inputStream;
                            o2 = outputStream;
                            httpURLConnection = httpURLConnection4;
                            o3 = inputStream;
                            o4 = outputStream;
                            httpURLConnection2 = httpURLConnection4;
                            o5 = inputStream;
                            o6 = outputStream;
                            if (headerFieldKey.equalsIgnoreCase("set-cookie")) {
                                httpURLConnection3 = httpURLConnection4;
                                o = inputStream;
                                o2 = outputStream;
                                httpURLConnection = httpURLConnection4;
                                o3 = inputStream;
                                o4 = outputStream;
                                httpURLConnection2 = httpURLConnection4;
                                o5 = inputStream;
                                o6 = outputStream;
                                instance2.setCookie((String)ex, headerField);
                            }
                        }
                        ++n;
                    }
                    httpURLConnection3 = httpURLConnection4;
                    o = inputStream;
                    o2 = outputStream;
                    httpURLConnection = httpURLConnection4;
                    o3 = inputStream;
                    o4 = outputStream;
                    httpURLConnection2 = httpURLConnection4;
                    o5 = inputStream;
                    o6 = outputStream;
                    instance.sync();
                    httpURLConnection3 = httpURLConnection4;
                    o = inputStream;
                    o2 = outputStream;
                    httpURLConnection = httpURLConnection4;
                    o3 = inputStream;
                    o4 = outputStream;
                    httpURLConnection2 = httpURLConnection4;
                    o5 = inputStream;
                    o6 = outputStream;
                    httpURLConnection3 = httpURLConnection4;
                    o = inputStream;
                    o2 = outputStream;
                    httpURLConnection = httpURLConnection4;
                    o3 = inputStream;
                    o4 = outputStream;
                    httpURLConnection2 = httpURLConnection4;
                    o5 = inputStream;
                    o6 = outputStream;
                    final URI uri = new URI((String)ex);
                    httpURLConnection3 = httpURLConnection4;
                    o = inputStream;
                    o2 = outputStream;
                    httpURLConnection = httpURLConnection4;
                    o3 = inputStream;
                    o4 = outputStream;
                    httpURLConnection2 = httpURLConnection4;
                    o5 = inputStream;
                    o6 = outputStream;
                    final WebView mWebView = this.mWebView;
                    httpURLConnection3 = httpURLConnection4;
                    o = inputStream;
                    o2 = outputStream;
                    httpURLConnection = httpURLConnection4;
                    o3 = inputStream;
                    o4 = outputStream;
                    httpURLConnection2 = httpURLConnection4;
                    o5 = inputStream;
                    o6 = outputStream;
                    httpURLConnection3 = httpURLConnection4;
                    o = inputStream;
                    o2 = outputStream;
                    httpURLConnection = httpURLConnection4;
                    o3 = inputStream;
                    o4 = outputStream;
                    httpURLConnection2 = httpURLConnection4;
                    o5 = inputStream;
                    o6 = outputStream;
                    final StringBuilder sb2 = new StringBuilder("http://");
                    httpURLConnection3 = httpURLConnection4;
                    o = inputStream;
                    o2 = outputStream;
                    httpURLConnection = httpURLConnection4;
                    o3 = inputStream;
                    o4 = outputStream;
                    httpURLConnection2 = httpURLConnection4;
                    o5 = inputStream;
                    o6 = outputStream;
                    final String string2 = sb2.append(uri.getHost()).toString();
                    httpURLConnection3 = httpURLConnection4;
                    o = inputStream;
                    o2 = outputStream;
                    httpURLConnection = httpURLConnection4;
                    o3 = inputStream;
                    o4 = outputStream;
                    httpURLConnection2 = httpURLConnection4;
                    o5 = inputStream;
                    o6 = outputStream;
                    httpURLConnection3 = httpURLConnection4;
                    o = inputStream;
                    o2 = outputStream;
                    httpURLConnection = httpURLConnection4;
                    o3 = inputStream;
                    o4 = outputStream;
                    httpURLConnection2 = httpURLConnection4;
                    o5 = inputStream;
                    o6 = outputStream;
                    final StringBuilder sb3 = new StringBuilder("http://");
                    httpURLConnection3 = httpURLConnection4;
                    o = inputStream;
                    o2 = outputStream;
                    httpURLConnection = httpURLConnection4;
                    o3 = inputStream;
                    o4 = outputStream;
                    httpURLConnection2 = httpURLConnection4;
                    o5 = inputStream;
                    o6 = outputStream;
                    mWebView.loadDataWithBaseURL(string2, string, "text/html", "UTF-8", sb3.append(uri.getHost()).toString());
                    o5 = outputStream;
                    o6 = inputStream;
                }
                else {
                    o6 = inputStream;
                    o5 = outputStream;
                    if (b) {
                        httpURLConnection3 = httpURLConnection4;
                        o = inputStream;
                        o2 = outputStream;
                        httpURLConnection = httpURLConnection4;
                        o3 = inputStream;
                        o4 = outputStream;
                        httpURLConnection2 = httpURLConnection4;
                        o5 = inputStream;
                        o6 = outputStream;
                        this.loadURL((String)ex, requestMethod, map, map2, false);
                        o6 = inputStream;
                        o5 = outputStream;
                    }
                }
            }
        }
        catch (final URISyntaxException ex) {
            httpURLConnection2 = httpURLConnection3;
            o5 = o;
            o6 = o2;
            Log.e(FBDialog.LOG, "Error on url format", (Throwable)ex);
        }
        catch (final IOException ex2) {
            httpURLConnection2 = httpURLConnection;
            o5 = o3;
            o6 = o4;
            Log.e(FBDialog.LOG, "Error while opening page", (Throwable)ex2);
            if (b) {
                httpURLConnection2 = httpURLConnection;
                o5 = o3;
                o6 = o4;
                this.loadURL((String)ex, requestMethod, map, map2, false);
            }
        }
        finally {
            CcUtil.close((Closeable)o5);
            CcUtil.close((Closeable)o6);
            CcUtil.disconnect(httpURLConnection2);
        }
    }
    
    protected void onDraw(final Canvas canvas) {
        super.onDraw(canvas);
        final Rect rect = new Rect(new Rect(canvas.getClipBounds()));
        rect.inset(10, 10);
        this.drawRect(canvas, rect, FBDialog.BORDER_GRAY, 10.0f);
    }
    
    public void setDelegate(final IDialogDelegate mDelegate) {
        this.mDelegate = mDelegate;
    }
    
    public void setSession(final FBSession mSession) {
        this.mSession = mSession;
    }
    
    public void setTitle(final String text) {
        this.mTitleLabel.setText((CharSequence)text);
    }
    
    public void show() {
        this.load();
    }
    
    public abstract static class FBDialogDelegate implements IDialogDelegate
    {
        @Override
        public void dialogDidCancel(final FBDialog fbDialog) {
        }
        
        @Override
        public void dialogDidFailWithError(final FBDialog fbDialog, final Throwable t) {
        }
        
        @Override
        public void dialogDidSucceed(final FBDialog fbDialog) {
        }
        
        @Override
        public boolean dialogShouldOpenUrlInExternalBrowser(final FBDialog fbDialog, final URL url) {
            return false;
        }
    }
    
    private final class WebViewClientImpl extends WebViewClient
    {
        private Dialog dialog;
        final FBDialog this$0;
        
        private WebViewClientImpl(final FBDialog this$0) {
            this.this$0 = this$0;
            this.dialog = null;
        }
        
        public void onPageFinished(final WebView webView, final String s) {
            super.onPageFinished(webView, s);
            webView.loadUrl("javascript:(function() { document.getElementById('cancel').onclick = function onclick(event) { window.location.href = 'fbconnect:cancel'; } })()");
            webView.loadUrl("javascript:(function() { document.getElementById('okay').onclick = function onclick(event) { window.location.href = 'fbconnect:cancel'; } })()");
            webView.loadUrl("javascript:(function() { document.getElementsByName('feedform_user_message')[0].style.display = 'none' })()");
            FBProgressDialog.hide(this.this$0.getContext());
        }
        
        public void onPageStarted(final WebView webView, final String s, final Bitmap bitmap) {
            super.onPageStarted(webView, s, bitmap);
            FBProgressDialog.show(this.this$0.getContext(), null);
        }
        
        public boolean shouldOverrideUrlLoading(final WebView webView, final String s) {
            try {
                final URI uri = new URI(s);
                Log.d("FBDialog", "Web view URL = " + s);
                if (!uri.isAbsolute()) {
                    Log.e(FBDialog.LOG, "Something went wrong. You probably forgot to specify API key and secret?");
                }
                if (uri.getScheme() != null && s.contains((CharSequence)"fbconnect:")) {
                    if (s.contains((CharSequence)"fbconnect://cancel") || s.contains((CharSequence)"fbconnect:cancel")) {
                        this.this$0.dismissWithSuccess(false, true);
                    }
                    else {
                        this.this$0.dialogDidSucceed(uri);
                    }
                    return true;
                }
                goto Label_0120;
            }
            catch (final URISyntaxException ex) {
                ex.printStackTrace();
            }
            catch (final MalformedURLException ex2) {
                ex2.printStackTrace();
                goto Label_0115;
            }
        }
    }
}
