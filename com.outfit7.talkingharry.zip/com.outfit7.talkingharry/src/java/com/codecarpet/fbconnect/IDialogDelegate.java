package com.codecarpet.fbconnect;

import java.net.URL;

public interface IDialogDelegate
{
    void dialogDidCancel(final FBDialog p0);
    
    void dialogDidFailWithError(final FBDialog p0, final Throwable p1);
    
    void dialogDidSucceed(final FBDialog p0);
    
    boolean dialogShouldOpenUrlInExternalBrowser(final FBDialog p0, final URL p1);
}
