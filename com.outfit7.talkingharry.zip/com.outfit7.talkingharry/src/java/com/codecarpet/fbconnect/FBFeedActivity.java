package com.codecarpet.fbconnect;

import android.view.View;
import java.net.URL;
import android.content.Intent;
import android.util.Log;
import android.os.Bundle;
import android.app.Activity;

public class FBFeedActivity extends Activity
{
    public static final String LOG = "FBFeedDialog";
    
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        final Bundle extras = this.getIntent().getExtras();
        final FBFeedDialog contentView = new FBFeedDialog(this, FBSession.getSession(), extras.getString("userMessagePrompt"), extras.getString("attachment"), extras.getString("actionLinks"), extras.getString("targetId"));
        contentView.setDelegate(new IDialogDelegate(this, extras) {
            final FBFeedActivity this$0;
            private final Bundle val$extras;
            
            @Override
            public void dialogDidCancel(final FBDialog fbDialog) {
                this.this$0.setResult(0);
            }
            
            @Override
            public void dialogDidFailWithError(final FBDialog fbDialog, final Throwable t) {
                Log.e("FBFeedDialog", "Feed activity dialog failed", t);
            }
            
            @Override
            public void dialogDidSucceed(FBDialog fbDialog) {
                fbDialog = (FBDialog)new Intent();
                while (true) {
                    try {
                        ((Intent)fbDialog).putExtra("targetId", this.val$extras.getString("targetId"));
                        ((Intent)fbDialog).putExtra("custom", this.val$extras.getStringArray("custom"));
                        this.this$0.setResult(1, (Intent)fbDialog);
                    }
                    catch (final Exception ex) {
                        continue;
                    }
                    break;
                }
            }
            
            @Override
            public boolean dialogShouldOpenUrlInExternalBrowser(final FBDialog fbDialog, final URL url) {
                return false;
            }
        });
        this.setContentView((View)contentView);
        contentView.show();
    }
}
