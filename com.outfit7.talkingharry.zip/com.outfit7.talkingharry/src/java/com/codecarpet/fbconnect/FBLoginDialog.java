package com.codecarpet.fbconnect;

import org.json.JSONException;
import android.content.Context;
import java.util.Date;
import org.json.JSONObject;
import android.util.Log;
import java.net.URI;
import java.net.MalformedURLException;
import java.util.Map;
import java.util.HashMap;
import android.app.Activity;

public class FBLoginDialog extends FBDialog
{
    private static final String LOG;
    private static final String LOGIN_URL = "http://www.facebook.com/login.php";
    private FBRequest mGetSessionRequest;
    private FBRequest.FBRequestDelegate mRequestDelegate;
    
    static {
        LOG = FBLoginDialog.class.getSimpleName();
    }
    
    public FBLoginDialog(final Activity activity, final FBSession fbSession) {
        super(activity, fbSession);
        this.mRequestDelegate = new FBRequestDelegateImpl((FBRequestDelegateImpl)null);
    }
    
    static /* synthetic */ void access$0(final FBLoginDialog fbLoginDialog, final FBRequest mGetSessionRequest) {
        fbLoginDialog.mGetSessionRequest = mGetSessionRequest;
    }
    
    private void connectToGetSession(final String s) {
        this.mGetSessionRequest = FBRequest.requestWithSession(this.mSession, this.mRequestDelegate);
        final HashMap hashMap = new HashMap();
        ((Map)hashMap).put((Object)"auth_token", (Object)s);
        if (this.mSession.getApiSecret() != null) {
            ((Map)hashMap).put((Object)"generate_session_secret", (Object)"1");
        }
        if (this.mSession.getGetSessionProxy() != null) {
            this.mGetSessionRequest.post(this.mSession.getGetSessionProxy(), (Map<String, String>)hashMap);
        }
        else {
            this.mGetSessionRequest.call("facebook.auth.getSession", (Map<String, String>)hashMap);
        }
    }
    
    private void loadLoginPage() {
        final HashMap hashMap = new HashMap();
        ((Map)hashMap).put((Object)"fbconnect", (Object)"1");
        ((Map)hashMap).put((Object)"connect_display", (Object)"touch");
        ((Map)hashMap).put((Object)"api_key", (Object)this.mSession.getApiKey());
        ((Map)hashMap).put((Object)"next", (Object)"fbconnect://success");
        try {
            this.loadURL("http://www.facebook.com/login.php", "GET", (Map<String, String>)hashMap, null);
        }
        catch (final MalformedURLException ex) {
            ex.printStackTrace();
        }
    }
    
    @Override
    protected void dialogDidSucceed(final URI uri) {
        final String query = uri.getQuery();
        final int index = query.indexOf("auth_token=");
        if (index != -1) {
            final int index2 = query.indexOf("&");
            final int n = index + "auth_token=".length();
            String s;
            if (index2 == -1) {
                s = query.substring(n);
            }
            else {
                s = query.substring(n, index2 - n);
            }
            if (s != null) {
                this.connectToGetSession(s);
            }
        }
    }
    
    @Override
    protected void dialogWillDisappear() {
        if (this.mGetSessionRequest == null) {
            Log.w(FBLoginDialog.LOG, "This should not be null, at least on iPhone it is not...");
        }
        else {
            this.mGetSessionRequest.cancel();
        }
    }
    
    @Override
    protected void load() {
        this.loadLoginPage();
    }
    
    private class FBRequestDelegateImpl extends FBRequestDelegate
    {
        final FBLoginDialog this$0;
        
        private FBRequestDelegateImpl(final FBLoginDialog this$0) {
            this.this$0 = this$0;
        }
        
        @Override
        public void requestDidFailWithError(final FBRequest fbRequest, final Throwable t) {
            FBLoginDialog.access$0(this.this$0, null);
            this.this$0.dismissWithError(t, true);
        }
        
        @Override
        public void requestDidLoad(final FBRequest fbRequest, final Object o) {
            try {
                final JSONObject jsonObject = (JSONObject)o;
                final long long1 = jsonObject.getLong("uid");
                final String string = jsonObject.getString("session_key");
                final String string2 = jsonObject.getString("secret");
                final Long value = jsonObject.getLong("expires");
                Date date = null;
                if (value != null) {
                    date = new Date((long)value);
                }
                FBLoginDialog.access$0(this.this$0, null);
                this.this$0.mSession.begin((Context)this.this$0.mContext, long1, string, string2, date);
                this.this$0.mSession.resume((Context)this.this$0.mContext);
                this.this$0.dismissWithSuccess(true, true);
            }
            catch (final JSONException ex) {
                ex.printStackTrace();
            }
        }
    }
}
