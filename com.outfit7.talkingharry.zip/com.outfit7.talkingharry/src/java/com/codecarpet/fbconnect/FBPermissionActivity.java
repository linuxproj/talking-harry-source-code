package com.codecarpet.fbconnect;

import android.view.View;
import android.os.Bundle;
import android.app.Activity;

public class FBPermissionActivity extends Activity
{
    private FBPermissionDialog fbDialog;
    
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        (this.fbDialog = new FBPermissionDialog(this, FBSession.getSession(), (String[])this.getIntent().getExtras().get("permissions"))).setDelegate(new FBPermissionDialogDelegate((FBPermissionDialogDelegate)null));
        this.setContentView((View)this.fbDialog);
        this.fbDialog.show();
    }
    
    protected void onDestroy() {
        super.onDestroy();
        try {
            this.fbDialog.mWebView.destroy();
        }
        catch (final Exception ex) {
            ex.printStackTrace();
        }
    }
    
    private class FBPermissionDialogDelegate extends FBDialogDelegate
    {
        final FBPermissionActivity this$0;
        
        private FBPermissionDialogDelegate(final FBPermissionActivity this$0) {
            this.this$0 = this$0;
        }
        
        @Override
        public void dialogDidCancel(final FBDialog fbDialog) {
            super.dialogDidCancel(fbDialog);
            this.this$0.setResult(0);
        }
        
        @Override
        public void dialogDidSucceed(final FBDialog fbDialog) {
            super.dialogDidSucceed(fbDialog);
            this.this$0.setResult(1);
        }
    }
}
