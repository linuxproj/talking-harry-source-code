package com.codecarpet.fbconnect;

import android.content.SharedPreferences$Editor;
import android.content.SharedPreferences;
import android.util.Log;
import java.util.Iterator;
import android.content.Context;
import temporary.CcDate;
import java.io.IOException;
import java.util.ArrayList;
import java.util.TimerTask;
import java.util.Timer;
import java.util.Date;
import java.util.List;

public class FBSession
{
    private static final String APIRESTSECUREURL = "https://api.facebook.com/restserver.php";
    private static final String APIRESTURL = "http://api.facebook.com/restserver.php";
    private static final long BURSTDURATION = 2L;
    private static final int MAXBURSTREQUESTS = 3;
    private static final String PREFS_NAME = "FBSessionPreferences";
    private static FBSession mSharedSession;
    private String mApiKey;
    private String mApiSecret;
    private List<FBSessionDelegate> mDelegates;
    private Date mExpirationDate;
    private String mGetSessionProxy;
    private Date mLastRequestTime;
    private int mRequestBurstCount;
    private List<FBRequest> mRequestQueue;
    private Timer mRequestTimer;
    private String mSessionKey;
    private String mSessionSecret;
    private Long mUid;
    private TimerTask requestTimerReady;
    
    private FBSession(final String mApiKey, final String mApiSecret, final String mGetSessionProxy) {
        this.requestTimerReady = new TimerTask() {
            final FBSession this$0;
            
            public void run() {
                FBSession.access$0(this.this$0, null);
                this.this$0.flushRequestQueue();
            }
        };
        this.mDelegates = (List<FBSessionDelegate>)new ArrayList();
        this.mApiKey = mApiKey;
        this.mApiSecret = mApiSecret;
        this.mGetSessionProxy = mGetSessionProxy;
        this.mUid = 0L;
        this.mSessionKey = null;
        this.mSessionSecret = null;
        this.mExpirationDate = null;
        this.mRequestQueue = (List<FBRequest>)new ArrayList();
        this.mLastRequestTime = new Date();
        this.mRequestBurstCount = 0;
        this.mRequestTimer = null;
    }
    
    static /* synthetic */ void access$0(final FBSession fbSession, final Timer mRequestTimer) {
        fbSession.mRequestTimer = mRequestTimer;
    }
    
    private void enqueueRequest(final FBRequest fbRequest) {
        this.mRequestQueue.add((Object)fbRequest);
        this.startFlushTimer();
    }
    
    private void flushRequestQueue() {
        while (this.mRequestQueue.size() > 0) {
            if (!this.performRequest((FBRequest)this.mRequestQueue.get(0), false)) {
                this.startFlushTimer();
                break;
            }
            this.mRequestQueue.remove(0);
        }
    }
    
    public static FBSession getSession() {
        return FBSession.mSharedSession;
    }
    
    public static FBSession getSessionForApplication_getSessionProxy(final String s, final String s2, final FBSessionDelegate fbSessionDelegate) {
        final FBSession initWithKey = initWithKey(s, null, s2);
        initWithKey.getDelegates().add((Object)fbSessionDelegate);
        return initWithKey;
    }
    
    public static FBSession getSessionForApplication_secret(final String s, final String s2, final FBSessionDelegate fbSessionDelegate) {
        final FBSession initWithKey = initWithKey(s, s2, null);
        initWithKey.getDelegates().add((Object)fbSessionDelegate);
        return initWithKey;
    }
    
    private static FBSession initWithKey(final String s, final String s2, final String s3) {
        final FBSession mSharedSession = new FBSession(s, s2, s3);
        if (FBSession.mSharedSession == null) {
            FBSession.mSharedSession = mSharedSession;
        }
        return mSharedSession;
    }
    
    private boolean performRequest(final FBRequest fbRequest, final boolean b) {
        boolean b2 = false;
        if (this.mLastRequestTime != null) {
            if (new Date().getTime() - this.mLastRequestTime.getTime() < 2L) {
                b2 = true;
            }
            else {
                b2 = false;
            }
        }
        boolean b3;
        if (this.mLastRequestTime != null && b2 && ++this.mRequestBurstCount > 3) {
            if (b) {
                this.enqueueRequest(fbRequest);
            }
            b3 = false;
        }
        else {
            while (true) {
                try {
                    fbRequest.connect();
                    if (!b2) {
                        this.mRequestBurstCount = 0;
                        this.mLastRequestTime = fbRequest.getTimestamp();
                    }
                    b3 = true;
                }
                catch (final IOException ex) {
                    ex.printStackTrace();
                    continue;
                }
                break;
            }
        }
        return b3;
    }
    
    public static void setSession(final FBSession mSharedSession) {
        FBSession.mSharedSession = mSharedSession;
    }
    
    private void startFlushTimer() {
        if (this.mRequestTimer == null) {
            (this.mRequestTimer = new Timer()).schedule(this.requestTimerReady, 1000L * (2L + CcDate.timeIntervalSinceNow(this.mLastRequestTime)));
        }
    }
    
    public void begin(final Context context, final Long mUid, final String mSessionKey, final String mSessionSecret, final Date date) {
        this.mUid = mUid;
        this.mSessionKey = mSessionKey;
        this.mSessionSecret = mSessionSecret;
        this.mExpirationDate = (Date)date.clone();
        this.save(context);
    }
    
    public String getApiKey() {
        return this.mApiKey;
    }
    
    public String getApiSecret() {
        return this.mApiSecret;
    }
    
    public String getApiSecureURL() {
        return "https://api.facebook.com/restserver.php";
    }
    
    public String getApiURL() {
        return "http://api.facebook.com/restserver.php";
    }
    
    public List<FBSessionDelegate> getDelegates() {
        return this.mDelegates;
    }
    
    public Date getExpirationDate() {
        return this.mExpirationDate;
    }
    
    public String getGetSessionProxy() {
        return this.mGetSessionProxy;
    }
    
    public String getSessionKey() {
        return this.mSessionKey;
    }
    
    public String getSessionSecret() {
        return this.mSessionSecret;
    }
    
    public Long getUid() {
        return this.mUid;
    }
    
    public boolean isConnected() {
        return this.mSessionKey != null;
    }
    
    public void logout(final Context context) {
        if (this.mSessionKey != null) {
            final Iterator iterator = this.mDelegates.iterator();
            while (iterator.hasNext()) {
                ((FBSessionDelegate)iterator.next()).sessionWillLogout(this, this.mUid);
            }
            this.mUid = 0L;
            this.mSessionKey = null;
            this.mSessionSecret = null;
            this.mExpirationDate = null;
            this.unsave(context);
            final Iterator iterator2 = this.mDelegates.iterator();
            while (iterator2.hasNext()) {
                ((FBSessionDelegate)iterator2.next()).sessionDidLogout(this);
            }
        }
        else {
            this.unsave(context);
        }
    }
    
    public boolean resume(final Context context) {
        final SharedPreferences sharedPreferences = context.getSharedPreferences("FBSessionPreferences", 0);
        final Long value = sharedPreferences.getLong("FBUserId", 0L);
        Log.d("FBSession", "FBUserId = " + (Object)value);
        if (value == 0L) {
            return false;
        }
        int n = 0;
        final long long1 = sharedPreferences.getLong("FBSessionExpires", 0L);
        if (long1 > 0L) {
            final Date date = new Date(long1);
            String localeString;
            if ("expirationDate = " + (Object)date != null) {
                localeString = date.toLocaleString();
            }
            else {
                localeString = "null";
            }
            Log.d("FBSession", localeString);
            final long timeIntervalSinceNow = CcDate.timeIntervalSinceNow(date);
            Log.d("FBSession", "Time interval since now = " + timeIntervalSinceNow);
            if (date == null || timeIntervalSinceNow <= 0L) {
                n = 1;
            }
        }
        else {
            Log.d("FBSession", "FBSessionExpires does not exist.  Loading session...");
            n = 1;
        }
        if (n == 0) {
            return false;
        }
        Log.d("FBSession", "Session can be loaded.  Loading...");
        this.mUid = value;
        this.mSessionKey = sharedPreferences.getString("FBSessionKey", (String)null);
        this.mSessionSecret = sharedPreferences.getString("FBSessionSecret", (String)null);
        final Iterator iterator = this.mDelegates.iterator();
        while (iterator.hasNext()) {
            ((FBSessionDelegate)iterator.next()).sessionDidLogin(this, value);
        }
        return true;
        b = false;
        return b;
    }
    
    public void save(final Context context) {
        final SharedPreferences$Editor edit = context.getSharedPreferences("FBSessionPreferences", 0).edit();
        if (this.mUid != null) {
            edit.putLong("FBUserId", (long)this.mUid);
        }
        else {
            edit.remove("FBUserId");
        }
        if (this.mSessionKey != null) {
            edit.putString("FBSessionKey", this.mSessionKey);
        }
        else {
            edit.remove("FBSessionKey");
        }
        if (this.mSessionSecret != null) {
            edit.putString("FBSessionSecret", this.mSessionSecret);
        }
        else {
            edit.remove("FBSessionSecret");
        }
        if (this.mExpirationDate != null) {
            edit.putLong("FBSessionExpires", this.mExpirationDate.getTime());
        }
        else {
            edit.remove("FBSessionExpires");
        }
        edit.commit();
    }
    
    public void send(final FBRequest fbRequest) {
        this.performRequest(fbRequest, true);
    }
    
    public void unsave(final Context context) {
        final SharedPreferences$Editor edit = context.getSharedPreferences("FBSessionPreferences", 0).edit();
        edit.remove("FBUserId");
        edit.remove("FBSessionKey");
        edit.remove("FBSessionSecret");
        edit.remove("FBSessionExpires");
        edit.commit();
    }
    
    public abstract static class FBSessionDelegate implements ISessionDelegate
    {
        @Override
        public void sessionDidLogin(final FBSession fbSession, final Long n) {
        }
        
        @Override
        public void sessionDidLogout(final FBSession fbSession) {
        }
        
        @Override
        public void sessionWillLogout(final FBSession fbSession, final Long n) {
        }
    }
}
