package com.codecarpet.fbconnect;

import android.util.StateSet;
import android.content.Intent;
import android.app.Activity;
import android.view.View;
import android.view.View$OnClickListener;
import temporary.CcUtil;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.os.Handler;
import android.content.Context;
import android.widget.ImageButton;

public class FBLoginButton extends ImageButton
{
    private Context mContext;
    private Handler mHandler;
    private FBSession mSession;
    private FBSession.FBSessionDelegate mSessionDelegate;
    private FBLoginButtonStyle mStyle;
    
    public FBLoginButton(final Context context) {
        super(context);
        this.initButton(context);
    }
    
    public FBLoginButton(final Context context, final AttributeSet set) {
        super(context, set);
        this.initButton(context);
    }
    
    public FBLoginButton(final Context context, final AttributeSet set, final int n) {
        super(context, set, n);
        this.initButton(context);
    }
    
    private Drawable buttonHighlightedImage() {
        Drawable drawable;
        if (this.mSession.isConnected()) {
            drawable = CcUtil.getDrawable(this.getClass(), "com/codecarpet/fbconnect/resources/logout_down.png");
        }
        else if (this.mStyle == FBLoginButtonStyle.FBLoginButtonStyleNormal) {
            drawable = CcUtil.getDrawable(this.getClass(), "com/codecarpet/fbconnect/resources/login_down.png");
        }
        else if (this.mStyle == FBLoginButtonStyle.FBLoginButtonStyleWide) {
            drawable = CcUtil.getDrawable(this.getClass(), "com/codecarpet/fbconnect/resources/login2_down.png");
        }
        else {
            drawable = null;
        }
        return drawable;
    }
    
    private Drawable buttonImage() {
        Drawable drawable;
        if (this.mSession.isConnected()) {
            drawable = CcUtil.getDrawable(this.getClass(), "com/codecarpet/fbconnect/resources/logout.png");
        }
        else if (this.mStyle == FBLoginButtonStyle.FBLoginButtonStyleNormal) {
            drawable = CcUtil.getDrawable(this.getClass(), "com/codecarpet/fbconnect/resources/login.png");
        }
        else if (this.mStyle == FBLoginButtonStyle.FBLoginButtonStyleWide) {
            drawable = CcUtil.getDrawable(this.getClass(), "com/codecarpet/fbconnect/resources/login2.png");
        }
        else {
            drawable = null;
        }
        return drawable;
    }
    
    private void initButton(final Context mContext) {
        this.setBackgroundColor(0);
        this.setAdjustViewBounds(true);
        this.mStyle = FBLoginButtonStyle.FBLoginButtonStyleNormal;
        this.setOnClickListener((View$OnClickListener)new View$OnClickListener(this) {
            final FBLoginButton this$0;
            
            public void onClick(final View view) {
                new Thread(this) {
                    final FBLoginButton$1 this$1;
                    
                    public void run() {
                        this.this$1.this$0.touchUpInside();
                    }
                }.start();
            }
        });
        this.mSession = FBSession.getSession();
        this.mSessionDelegate = new FBSessionDelegateImpl((FBSessionDelegateImpl)null);
        this.mSession.getDelegates().add((Object)this.mSessionDelegate);
        this.mContext = mContext;
        this.mHandler = new Handler();
        this.updateImage();
    }
    
    private void touchUpInside() {
        if (this.mSession.isConnected()) {
            this.mSession.logout(this.mContext);
        }
        else {
            ((Activity)this.mContext).startActivityForResult(new Intent(this.mContext, (Class)FBLoginActivity.class), 55);
        }
    }
    
    private void updateImage() {
        this.drawableStateChanged();
    }
    
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        final int[] drawableState = this.getDrawableState();
        Drawable imageDrawable;
        if (StateSet.stateSetMatches(new int[] { 16842919 }, drawableState) || StateSet.stateSetMatches(new int[] { 16842908 }, drawableState)) {
            imageDrawable = this.buttonHighlightedImage();
        }
        else {
            imageDrawable = this.buttonImage();
        }
        this.setImageDrawable(imageDrawable);
    }
    
    public void setSession(final FBSession mSession) {
        if (mSession != this.mSession) {
            this.mSession.getDelegates().remove((Object)this.mSessionDelegate);
            this.mSession = mSession;
            this.mSession.getDelegates().add((Object)this.mSessionDelegate);
            this.updateImage();
        }
    }
    
    public void setStyle(final FBLoginButtonStyle mStyle) {
        this.mStyle = mStyle;
        this.updateImage();
    }
    
    public enum FBLoginButtonStyle
    {
        private static final FBLoginButtonStyle[] ENUM$VALUES;
        
        FBLoginButtonStyleNormal("FBLoginButtonStyleNormal", 0), 
        FBLoginButtonStyleWide("FBLoginButtonStyleWide", 1);
        
        static {
            ENUM$VALUES = new FBLoginButtonStyle[] { FBLoginButtonStyle.FBLoginButtonStyleNormal, FBLoginButtonStyle.FBLoginButtonStyleWide };
        }
        
        private FBLoginButtonStyle(final String s, final int n) {
        }
    }
    
    private class FBSessionDelegateImpl extends FBSessionDelegate
    {
        final FBLoginButton this$0;
        
        private FBSessionDelegateImpl(final FBLoginButton this$0) {
            this.this$0 = this$0;
        }
        
        @Override
        public void sessionDidLogin(final FBSession fbSession, final Long n) {
            this.this$0.mHandler.post((Runnable)new Runnable(this) {
                final FBSessionDelegateImpl this$1;
                
                public void run() {
                    this.this$1.this$0.updateImage();
                }
            });
        }
        
        @Override
        public void sessionDidLogout(final FBSession fbSession) {
            this.this$0.mHandler.post((Runnable)new Runnable(this) {
                final FBSessionDelegateImpl this$1;
                
                public void run() {
                    this.this$1.this$0.updateImage();
                }
            });
        }
    }
}
