package com.codecarpet.fbconnect;

import android.view.View;
import android.os.Bundle;
import android.app.Activity;

public class FBLoginActivity extends Activity
{
    private FBLoginDialog fbDialog;
    
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.getWindow().setSoftInputMode(32);
        this.setContentView((View)(this.fbDialog = new FBLoginDialog(this, FBSession.getSession())));
        this.fbDialog.show();
    }
    
    protected void onDestroy() {
        super.onDestroy();
        try {
            this.fbDialog.mWebView.destroy();
        }
        catch (final Exception ex) {
            ex.printStackTrace();
        }
    }
}
