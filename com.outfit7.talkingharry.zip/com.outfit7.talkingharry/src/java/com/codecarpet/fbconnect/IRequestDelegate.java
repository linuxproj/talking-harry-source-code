package com.codecarpet.fbconnect;

public interface IRequestDelegate
{
    void requestDidFailWithError(final FBRequest p0, final Throwable p1);
    
    void requestDidLoad(final FBRequest p0, final Object p1);
    
    void requestLoading(final FBRequest p0);
    
    void requestWasCancelled(final FBRequest p0);
}
