package com.codecarpet.fbconnect;

import java.net.MalformedURLException;
import java.util.Map;
import java.util.HashMap;
import android.app.Activity;

public class FBPermissionDialog extends FBDialog
{
    private static final String PERMISSION_URL = "http://www.facebook.com/connect/prompt_permissions.php";
    private String[] mPermissions;
    
    public FBPermissionDialog(final Activity activity, final FBSession fbSession, final String[] mPermissions) {
        super(activity, fbSession);
        this.mPermissions = mPermissions;
    }
    
    private void loadExtendedPermissionPage() {
        final HashMap hashMap = new HashMap();
        ((Map)hashMap).put((Object)"fbconnect", (Object)"1");
        ((Map)hashMap).put((Object)"connect_display", (Object)"touch");
        ((Map)hashMap).put((Object)"api_key", (Object)this.mSession.getApiKey());
        ((Map)hashMap).put((Object)"next", (Object)"fbconnect://success");
        ((Map)hashMap).put((Object)"cancel", (Object)"fbconnect://cancel");
        String string = "";
        final int length = this.mPermissions.length;
        int n = 0;
        while (true) {
            Label_0113: {
                if (n < length) {
                    break Label_0113;
                }
                ((Map)hashMap).put((Object)"ext_perm", (Object)string);
                try {
                    this.loadURL("http://www.facebook.com/connect/prompt_permissions.php", "GET", (Map<String, String>)hashMap, null);
                    return;
                    final StringBuilder append = new StringBuilder(String.valueOf((Object)string)).append(this.mPermissions[n]);
                    iftrue(Label_0161:)(n != length - 1);
                    String s = null;
                    Label_0145: {
                        Block_4: {
                            break Block_4;
                            Label_0161: {
                                s = ",";
                            }
                            break Label_0145;
                        }
                        s = "";
                    }
                    string = append.append(s).toString();
                    ++n;
                }
                catch (final MalformedURLException ex) {
                    ex.printStackTrace();
                }
            }
        }
    }
    
    @Override
    protected void load() {
        this.loadExtendedPermissionPage();
    }
}
