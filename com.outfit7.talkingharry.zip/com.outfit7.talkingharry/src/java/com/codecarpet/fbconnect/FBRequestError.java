package com.codecarpet.fbconnect;

import java.util.Map;

public class FBRequestError extends Exception
{
    private Map<String, String> args;
    private int code;
    private String message;
    
    public FBRequestError(final int code, final String message, final Map<String, String> args) {
        this.code = code;
        this.message = message;
        this.args = args;
    }
    
    public int getCode() {
        return this.code;
    }
    
    public String getMessage() {
        return this.message;
    }
    
    public Map<String, String> getRequestArgs() {
        return this.args;
    }
    
    public String toString() {
        return "FBRequestError (" + this.code + "): " + this.message;
    }
}
