package com.codecarpet.fbconnect;

import java.net.MalformedURLException;
import java.util.Map;
import java.util.HashMap;
import android.app.Activity;

public class FBFeedDialog extends FBDialog
{
    private static final String PUBLISH_URL = "http://www.facebook.com/connect/prompt_feed.php";
    private String mActionLinks;
    private String mAttachment;
    private String mMessagePrompt;
    private String mTargetId;
    
    public FBFeedDialog(final Activity activity, final FBSession fbSession, final String mMessagePrompt, final String mAttachment, final String mActionLinks, final String mTargetId) {
        super(activity, fbSession);
        this.mMessagePrompt = mMessagePrompt;
        this.mAttachment = mAttachment;
        this.mActionLinks = mActionLinks;
        this.mTargetId = mTargetId;
    }
    
    private void loadStreamPublishPage() {
        final HashMap hashMap = new HashMap();
        ((Map)hashMap).put((Object)"display", (Object)"touch");
        ((Map)hashMap).put((Object)"callback", (Object)"fbconnect://success");
        ((Map)hashMap).put((Object)"cancel", (Object)"fbconnect://cancel");
        final HashMap hashMap2 = new HashMap();
        ((Map)hashMap2).put((Object)"api_key", (Object)this.mSession.getApiKey());
        ((Map)hashMap2).put((Object)"session_key", (Object)this.mSession.getSessionKey());
        ((Map)hashMap2).put((Object)"preview", (Object)"1");
        ((Map)hashMap2).put((Object)"attachment", (Object)this.mAttachment);
        ((Map)hashMap2).put((Object)"action_links", (Object)this.mActionLinks);
        ((Map)hashMap2).put((Object)"target_id", (Object)this.mTargetId);
        ((Map)hashMap2).put((Object)"user_message_prompt", (Object)this.mMessagePrompt);
        try {
            this.loadURL("http://www.facebook.com/connect/prompt_feed.php", "POST", (Map<String, String>)hashMap, (Map<String, String>)hashMap2);
        }
        catch (final MalformedURLException ex) {
            ex.printStackTrace();
        }
    }
    
    @Override
    protected void load() {
        this.loadStreamPublishPage();
    }
}
