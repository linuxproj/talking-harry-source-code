package com.tapjoy;

import java.net.URLConnection;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.io.BufferedInputStream;
import java.net.URL;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import java.io.IOException;
import org.xml.sax.SAXException;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Element;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.InputStream;
import android.content.SharedPreferences$Editor;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.telephony.TelephonyManager;
import android.content.pm.PackageManager$NameNotFoundException;
import java.util.Locale;
import android.os.Build$VERSION;
import android.os.Build;
import android.util.Log;
import android.content.Context;

public final class a
{
    private static a b;
    private b a;
    private Context c;
    private String d;
    private String e;
    private String f;
    private String g;
    private String h;
    private String i;
    private String j;
    private String k;
    private String l;
    private String m;
    private String n;
    private String o;
    
    static {
        a.b = null;
    }
    
    private a(final Context c) {
        this.a = null;
        this.c = null;
        this.d = "";
        this.e = "";
        this.f = "";
        this.g = "";
        this.h = "";
        this.i = "";
        this.j = "";
        this.k = "";
        this.l = "";
        this.m = "";
        this.n = "";
        this.o = "";
        this.c = c;
        this.a();
        this.n = this.n + "udid=" + this.d + "&";
        this.n = this.n + "device_name=" + this.e + "&";
        this.n = this.n + "device_type=" + this.f + "&";
        this.n = this.n + "os_version=" + this.g + "&";
        this.n = this.n + "country_code=" + this.h + "&";
        this.n = this.n + "language=" + this.i + "&";
        this.n = this.n + "app_id=" + this.j + "&";
        this.n = this.n + "app_version=" + this.k + "&";
        this.n = this.n + "library_version=" + this.l;
        Log.i("TapjoyConnect", "URL parameters: " + this.n);
        (this.a = new b(this)).execute((Object[])new Void[0]);
    }
    
    public static a a(final Context context) {
        if (a.b == null) {
            a.b = new a(context);
        }
        return a.b;
    }
    
    private void a() {
        while (true) {
            final PackageManager packageManager = this.c.getPackageManager();
        Label_0865:
            while (true) {
                SharedPreferences sharedPreferences = null;
                Label_0653: {
                    Label_0642: {
                        try {
                            final ApplicationInfo applicationInfo = packageManager.getApplicationInfo(this.c.getPackageName(), 128);
                            if (applicationInfo != null && applicationInfo.metaData != null) {
                                final String string = applicationInfo.metaData.getString("APP_ID");
                                if (string != null && !string.equals((Object)"")) {
                                    this.j = string;
                                    final String string2 = applicationInfo.metaData.getString("CLIENT_PACKAGE");
                                    if (string2 == null || string2.equals((Object)"")) {
                                        break Label_0642;
                                    }
                                    this.m = string2;
                                    this.k = packageManager.getPackageInfo(this.c.getPackageName(), 0).versionName;
                                    this.f = "android";
                                    this.e = Build.MODEL;
                                    this.g = Build$VERSION.RELEASE;
                                    this.h = Locale.getDefault().getCountry();
                                    this.i = Locale.getDefault().getLanguage();
                                    this.l = "7.0.0";
                                    sharedPreferences = this.c.getSharedPreferences("tjcPrefrences", 0);
                                    final String string3 = applicationInfo.metaData.getString("DEVICE_ID");
                                    if (string3 == null || string3.equals((Object)"")) {
                                        break Label_0653;
                                    }
                                    this.d = string3;
                                    Log.i("TapjoyConnect", "Using manifest device id = " + this.d);
                                    final String string4 = sharedPreferences.getString("InstallReferral", (String)null);
                                    if (string4 != null && !string4.equals((Object)"")) {
                                        this.o = string4;
                                    }
                                    Log.i("TapjoyConnect", "Metadata successfully loaded");
                                    Log.i("TapjoyConnect", "APP_ID = [" + this.j + "]");
                                    Log.i("TapjoyConnect", "CLIENT_PACKAGE = [" + this.m + "]");
                                    Log.i("TapjoyConnect", "deviceID: [" + this.d + "]");
                                    Log.i("TapjoyConnect", "deviceName: [" + this.e + "]");
                                    Log.i("TapjoyConnect", "deviceType: [" + this.f + "]");
                                    Log.i("TapjoyConnect", "libraryVersion: [" + this.l + "]");
                                    Log.i("TapjoyConnect", "deviceOSVersion: [" + this.g + "]");
                                    Log.i("TapjoyConnect", "COUNTRY_CODE: [" + this.h + "]");
                                    Log.i("TapjoyConnect", "LANGUAGE_CODE: [" + this.i + "]");
                                    Log.i("TapjoyConnect", "referralURL: [" + this.o + "]");
                                }
                                else {
                                    Log.e("TapjoyConnect", "APP_ID can't be empty.");
                                }
                                return;
                            }
                            break Label_0865;
                        }
                        catch (final PackageManager$NameNotFoundException ex) {
                            Log.e("TapjoyConnect", "Add APP_ID to AndroidManifest.xml file. For more detail integration document.");
                            return;
                        }
                        return;
                    }
                    Log.e("TapjoyConnect", "CLIENT_PACKAGE is missing.");
                    return;
                }
                final TelephonyManager telephonyManager = (TelephonyManager)this.c.getSystemService("phone");
                if (telephonyManager == null) {
                    this.d = null;
                    continue;
                }
                this.d = telephonyManager.getDeviceId();
                if (this.d == null || this.d.length() == 0) {
                    Log.e("TapjoyConnect", "Device id is null or empty.");
                    continue;
                }
                StringBuffer sb = null;
                Label_0780: {
                    try {
                        final int int1 = Integer.parseInt(this.d);
                        sb = new StringBuffer();
                        sb.append("EMULATOR");
                        if (int1 != 0) {
                            continue;
                        }
                        final String string5 = sharedPreferences.getString("emulatorDeviceId", (String)null);
                        if (string5 != null && !string5.equals((Object)"")) {
                            this.d = string5;
                            continue;
                        }
                        break Label_0780;
                    }
                    catch (final NumberFormatException ex2) {
                        continue;
                    }
                    continue;
                }
                for (int i = 0; i < 32; ++i) {
                    sb.append("1234567890abcdefghijklmnopqrstuvw".charAt((int)(Math.random() * 100.0) % 30));
                }
                this.d = sb.toString();
                final SharedPreferences$Editor edit = sharedPreferences.edit();
                edit.putString("emulatorDeviceId", this.d);
                edit.commit();
                continue;
            }
            Log.e("TapjoyConnect", "Add APP_ID to AndroidManifest.xml file. For more detail integration document.");
        }
    }
    
    private static boolean a(final InputStream inputStream) {
        final DocumentBuilderFactory instance = DocumentBuilderFactory.newInstance();
        while (true) {
            try {
                final Element element = (Element)instance.newDocumentBuilder().parse(inputStream).getElementsByTagName("Success").item(0);
                String trim;
                if (element != null) {
                    final NodeList childNodes = element.getChildNodes();
                    final int length = childNodes.getLength();
                    String s = "";
                    String string;
                    for (int i = 0; i < length; ++i, s = string) {
                        final Node item = childNodes.item(i);
                        string = s;
                        if (item != null) {
                            string = s + item.getNodeValue();
                        }
                    }
                    if (s != null && !s.equals((Object)"")) {
                        trim = s.trim();
                    }
                    else {
                        trim = null;
                    }
                }
                else {
                    trim = null;
                }
                boolean b;
                if (trim != null && trim.equals((Object)"true")) {
                    Log.i("TapjoyConnect", "Successfully connected to tapjoy site.");
                    b = true;
                }
                else {
                    Log.i("TapjoyConnect", "Fail to connect to tapjoy site.");
                    b = false;
                }
                return b;
            }
            catch (final ParserConfigurationException ex) {
                Log.e("TapjoyConnect", "Connect Handler fail to parse invalid xml.");
                continue;
            }
            catch (final SAXException ex2) {
                Log.e("TapjoyConnect", "Connect Handler fail to parse invalid xml.");
                continue;
            }
            catch (final IOException ex3) {
                Log.e("TapjoyConnect", "Connect Handler fails.");
                continue;
            }
            break;
        }
    }
    
    private boolean b() {
        if (!this.o.equals((Object)"")) {
            this.n = this.n + "&" + this.o;
        }
        while (true) {
            final String s = null;
            Object o;
            final String s2 = (String)(o = "http://ws.tapjoyads.com/connect?" + this.n);
            while (true) {
                try {
                    final String s3 = (String)(o = s2.replaceAll(" ", "%20"));
                    Log.i("TapjoyConnect", s3);
                    o = s3;
                    o = s3;
                    final URL url = new URL(s3);
                    o = s3;
                    final URLConnection openConnection = url.openConnection();
                    o = s3;
                    openConnection.setConnectTimeout(15000);
                    o = s3;
                    openConnection.setReadTimeout(30000);
                    o = s3;
                    final InputStream inputStream = openConnection.getInputStream();
                    o = s3;
                    o = s3;
                    o = new BufferedInputStream(inputStream);
                    if (o != null) {
                        return a((InputStream)o);
                    }
                }
                catch (final SocketTimeoutException ex) {
                    Log.e("TapjoyConnect", "Network requuest time out.");
                    o = s;
                    continue;
                }
                catch (final MalformedURLException ex2) {
                    Log.e("TapjoyConnect", "Fail to access URL [" + (String)o + "]");
                    o = s;
                    continue;
                }
                catch (final IOException ex3) {
                    Log.e("TapjoyConnect", "Fail duering IO operation");
                    o = s;
                    continue;
                }
                break;
            }
            Log.e("TapjoyConnect", "Fail to connect to tapjoy site.");
            return false;
        }
    }
    
    public final void finalize() {
        com.tapjoy.a.b = null;
        Log.i("TapjoyConnect", "Cleaning resources.");
    }
}
