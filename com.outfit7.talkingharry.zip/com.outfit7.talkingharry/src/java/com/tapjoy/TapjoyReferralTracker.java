package com.tapjoy;

import android.content.SharedPreferences$Editor;
import android.util.Log;
import android.content.Intent;
import android.content.Context;
import android.content.BroadcastReceiver;

public class TapjoyReferralTracker extends BroadcastReceiver
{
    public void onReceive(final Context context, final Intent intent) {
        Log.i("TapjoyReferralTracker", "Traversing TapjoyReferralTracker Broadcast Receiver intent's info.......");
        final String uri = intent.toURI();
        if (uri != null && uri.length() > 0) {
            final int index = uri.indexOf("referrer=");
            if (index >= 0) {
                final String substring = uri.substring(index, uri.length() - 4);
                Log.i("TapjoyReferralTracker", "Referral URI: " + substring);
                final SharedPreferences$Editor edit = context.getSharedPreferences("tjcPrefrences", 0).edit();
                edit.putString("InstallReferral", substring);
                edit.commit();
                Log.i("TapjoyReferralTracker", "Cached Referral URI: " + substring);
            }
            else {
                Log.i("TapjoyReferralTracker", "No Referral URL.");
            }
        }
        Log.i("TapjoyReferralTracker", "End");
    }
}
