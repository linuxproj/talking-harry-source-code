package com.tapjoy;

import android.os.AsyncTask;

final class b extends AsyncTask
{
    private a a;
    
    private b(final a a, final byte b) {
        this.a = a;
    }
}
