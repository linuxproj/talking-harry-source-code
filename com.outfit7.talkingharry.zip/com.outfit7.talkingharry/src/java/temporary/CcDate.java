package temporary;

import java.util.Date;

public class CcDate
{
    public static long timeIntervalSinceNow(final Date date) {
        long n;
        if (date == null) {
            n = 0L;
        }
        else {
            n = (System.currentTimeMillis() - date.getTime()) / 1000L;
        }
        return n;
    }
}
