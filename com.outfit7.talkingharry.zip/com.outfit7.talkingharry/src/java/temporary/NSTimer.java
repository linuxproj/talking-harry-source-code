package temporary;

public class NSTimer
{
    public static NSTimer scheduledTimerWithTimeInterval(final long n, final Runnable runnable, final Object o, final boolean b) {
        return null;
    }
}
