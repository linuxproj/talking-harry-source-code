package temporary;

import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.InputStream;
import android.graphics.Picture;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.BitmapDrawable;
import java.security.NoSuchAlgorithmException;
import java.security.MessageDigest;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.net.HttpURLConnection;
import java.util.List;
import java.io.IOException;
import java.io.Closeable;
import java.util.Comparator;

public class CcUtil
{
    public static final Comparator<String> CASE_INSENSITIVE_COMPARATOR;
    
    static {
        CASE_INSENSITIVE_COMPARATOR = (Comparator)new Comparator<String>() {
            public int compare(final String s, final String s2) {
                return s.compareToIgnoreCase(s2);
            }
        };
    }
    
    public static void close(final Closeable closeable) {
        if (closeable == null) {
            return;
        }
        try {
            closeable.close();
        }
        catch (final IOException ex) {
            ex.printStackTrace();
        }
    }
    
    public static String componentsJoinedByString(final List<String> list, final String s) {
        final StringBuilder sb = new StringBuilder();
        sb.append((String)list.get(0));
        for (int size = list.size(), i = 1; i < size; ++i) {
            sb.append(s).append((String)list.get(i));
        }
        return sb.toString();
    }
    
    public static void disconnect(final HttpURLConnection httpURLConnection) {
        if (httpURLConnection != null) {
            httpURLConnection.disconnect();
        }
    }
    
    public static String encode(CharSequence charSequence) {
        if (charSequence == null) {
            charSequence = (CharSequence)"";
        }
        else {
            charSequence = (CharSequence)charSequence.toString();
            try {
                charSequence = (CharSequence)URLEncoder.encode((String)charSequence, "UTF8");
            }
            catch (final UnsupportedEncodingException ex) {
                ex.printStackTrace();
            }
        }
        return (String)charSequence;
    }
    
    public static String generateMD5(String s) {
        try {
            while (true) {
                final MessageDigest instance = MessageDigest.getInstance("MD5");
                StringBuilder sb;
                int n;
                while (true) {
                    try {
                        s = (String)(Object)s.getBytes("UTF-8");
                        sb = new StringBuilder();
                        s = (String)(Object)instance.digest((byte[])(Object)s);
                        final int length = s.length;
                        n = 0;
                        if (n >= length) {
                            return sb.toString();
                        }
                    }
                    catch (final UnsupportedEncodingException ex) {
                        s = (String)(Object)s.getBytes();
                        continue;
                    }
                    break;
                }
                try {
                    final int n2 = s[n];
                    sb.append(Integer.toHexString((n2 & 0xF0) >>> 4));
                    sb.append(Integer.toHexString(n2 & 0xF));
                    ++n;
                }
                catch (final NoSuchAlgorithmException ex2) {
                    throw new RuntimeException((Throwable)ex2);
                }
            }
        }
        catch (final NoSuchAlgorithmException ex3) {}
    }
    
    public static BitmapDrawable getBitmapDrawable(final Class clazz, final String s) {
        return (BitmapDrawable)BitmapDrawable.createFromStream(clazz.getClassLoader().getResourceAsStream(s), s);
    }
    
    public static Drawable getDrawable(final Class clazz, final String s) {
        return Drawable.createFromStream(clazz.getClassLoader().getResourceAsStream(s), s);
    }
    
    public static Picture getPicture(final Class clazz, final String s) {
        return Picture.createFromStream(clazz.getClassLoader().getResourceAsStream(s));
    }
    
    public static StringBuilder getResponse(final InputStream inputStream) throws IOException {
        final BufferedReader bufferedReader = new BufferedReader((Reader)new InputStreamReader(inputStream, "UTF-8"));
        final StringBuilder sb = new StringBuilder();
        final char[] array = new char[1000];
        for (int i = 0; i >= 0; i = ((Reader)bufferedReader).read(array)) {
            sb.append(array, 0, i);
        }
        return sb;
    }
    
    public static int rgbFloatToInt(final float n, final float n2, final float n3, final float n4) {
        return ((int)(n4 * 255.0f + 0.5) & 0xFF) << 24 | ((int)(n * 255.0f + 0.5) & 0xFF) << 16 | ((int)(n2 * 255.0f + 0.5) & 0xFF) << 8 | ((int)(n3 * 255.0f + 0.5) & 0xFF) << 0;
    }
}
