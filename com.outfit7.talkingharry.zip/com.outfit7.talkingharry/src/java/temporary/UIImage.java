package temporary;

public class UIImage
{
}
