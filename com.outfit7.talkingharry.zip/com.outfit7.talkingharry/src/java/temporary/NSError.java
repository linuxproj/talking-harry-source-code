package temporary;

public class NSError
{
}
